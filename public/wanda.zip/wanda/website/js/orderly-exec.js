import { renderData } from './tableRender.js';
export class botAi {

    // This class would handle the random execution

    constructor() {
        console.log(" Random launcher initiated ;")
        // Initialize state variables
        this.botList = "inActive";
        this.botStatus = {
            runningBots: ['notUpdated'],
            offBots: ['notUpdated']
        };
        this.apiKey = null;
        this.personalities = 'notLoaded';
        this.executables = 'notLoaded';

        // renderEngine
        this.renderEngine = new renderData({
            currentPage: 1,
            itemsPerPage: 12,
            botEngine: this
        });

        this.isPaid = true;

        this.filterConfig = {};
        this.filteredList = null;
        this.checkedList = [];

        this.proxyChain = null;
        this.randomEngine = "off";
        // generate an ID for this session
        this.botNetID = `${this.getTimeStamp()}`;

        this.jqxhr = null; // Variable to store the jqXHR objectß

        this.refinedLubricant;

        this.alarmOn = false; // turn off alarm

        // initaite this object,load the necessary data
        this.init()
        this.updateTitle() // always update location on title

    }

    async updateTitle(){
        // This method sets an interval to keep updating the title of the page

        let self = this;
        setInterval(function () {
            let location = $('#proxyChain').find('option:selected').text();
            $('title').text(location);

            if( typeof(self.refinedLubricant) == "object"){
                $("#execHash").text(JSON.stringify(self.refinedLubricant))
            }
        },1000)
    }

    async isBotOff() {
        /*
            Thius section of the bot checks of the power button has been off
            if it has it resolves there by terminating anyProcess going On
            This is a mechanism to halt pinging a bot while the loadingBot screen keeps showing, there by slow us down
        */


    }

    getProxyChain() {
        // This method returns a null or a proxy depending on the location value

        let locationValue = $("#proxyChain").val();

        if (locationValue == "null") {
            // This means the user is at null
            console.log("no proxyChain selected")
            return null
        }

        // since we didnt return above, lets procceed into sending the proxy

        let proxy = JSON.parse(this.proxyChain[locationValue]['data']);

        //console.log(proxy, " <== proxy");
        proxy = proxy[(Object.keys(proxy)[this.getRandomInt(0, (Object.keys(proxy).length - 1))])]

        //console.log(proxy, " ==> proxy");

        return proxy;

    }

    async setProxyChain() {
        /*
         *  This method would set the proxyChain
        */

        let self = this;

        await $.ajax({
            method: "POST",
            url: `https://okecbot.com/api/index.php?key=${self.apiKey}&showLocations`,
            contentType: "application/json",
            dataType: "json",
            success: function (response) {
                if (response.status == "success") {

                    let records = response.json;

                    //save it in memory here
                    self.proxyChain = records;
                    //console.log("proxyChain saved in memory", records)

                    records.forEach((element, index) => {
                        try {

                            let obj = JSON.parse(element.data);

                            $("#proxyChain").append(`<option value="${index}" > ${element.chainName}  </option>`)
                        } catch (e) { }
                    });


                } else {

                    // disable theproxyChain button because something is wrong.


                }
            },
            error: function (error) {
                console.log(" Couldnt send ! ")
            }
        });
    }


    async upgradePopup() {
        // This method is used to prompt a user to upgrade there APIkey access so as to gain access tot this feature

        let Okectimer = 12;

        let timeInt = setInterval(() => {

            let timer = document.getElementById("timer");
            timer.innerHTML = Okectimer;
            // reduce the timer by 1;
            --Okectimer;

            if (Okectimer < 0) {
                clearInterval(timeInt)
            }

        }, 1000)
//
        $("#error_Msg").html(`
                   4No active orderly executor subscription. click access 5/ limitation to subscribe and unlock5.
                     `)

        $("#popError").css("display", "flex")
        await this.sleep(10000);
        $("#popError").css("display", "none")

    }

    async getExecutablePath(deviceBrand) {
        // This method would provide us with the path to the browser we would use for launching

        // for iphone browser pop up
        if (deviceBrand == "iphone") {

            let iphone_browser = $("#iphone_browser").val();
            if (iphone_browser.trim().length < 10) return null


            console.log(iphone_browser, " <== ", deviceBrand)

            return iphone_browser;

        }

        // for android browser pop up
        if (deviceBrand == "android") {

            let android_browser = $("#android_browser").val();
            if (android_browser.trim().length < 10) return null

            console.log(android_browser, " <== ")
            return android_browser;

        }

        // for windows browser pop up
        if (deviceBrand == "Win") {

            let win_browser = $("#win_browser").val();
            if (win_browser.trim().length < 10) return null

            console.log(win_browser, " <== ")

            return win_browser;

        }

        // for mac browser pop up
        if (deviceBrand == "mac") {

            let mac_browser = $("#mac_browser").val();
            if (mac_browser.trim().length < 10) return null

            console.log(mac_browser, " <== ")

            return mac_browser;

        }

    }

    isRange(min, max) {
        // Check if min and max are both numbers
        if (typeof min !== 'number' || typeof max !== 'number') {
            return false;
        }

        // Check if min and max are both integers or floats
        if (!Number.isInteger(min) || !Number.isInteger(max)) {
            return false;
        }

        // Check if min is less than max
        return min < max;
    }

    async pickRandomDevice(number_of_picks, deviceBrand) {
        // This method returns a number of switched off devices from a device brand in an array

        // create a new set to store unique devices
        let devices = new Set();

        while (devices.size < number_of_picks) {

            let generatedDevice = deviceBrand[this.getRandomInt(0, (deviceBrand.length - 1))];
            let deviceName = JSON.parse(generatedDevice).Account.fullname;

            // check if the device generated is not on the list of running bots, and add it else ignore
            if (this.botStatus.runningBots.includes(deviceName)) {
                // The bot generated is already running so we would look away 
            } else {
                // The bot generated is offline so we can switch it on

                devices.add(generatedDevice);
            }

        }

        return [...devices];
    }

    pickRandomTask(number_of_picks, executableChain) {
        // This method returns a number of randomly picked task in an array

        // create an array to store random task
        let task = [];

        while (task.length < number_of_picks) {


            let generatedTask = executableChain[(Object.keys(executableChain)[this.getRandomInt(0, (Object.keys(executableChain).length - 1))])]

            // add the task to the array

            task.push(generatedTask)

        }

        return [...task];
    }

    isAllNum(array) {
        // Loop through each element of the array
        for (let i = 0; i < array.length; i++) {
            // Check if the element is not a positive integer
            if (!(/^\d+$/.test(array[i])) || parseInt(array[i]) <= 0) {
                return false; // If it's not a positive integer, return false
            }
        }
        // If all elements are positive integers, return true
        return true;
    }

    renderTodoTask() {

        // This method renders the task(executables) to be executed so users can specify the max number of executions


        var executableChain = JSON.parse(this.executables[$("#executables").val()].data);
        $("#adsClick").empty(); // clear previous first

        let index = 0;

        console.log(executableChain)

        if (Object.keys(executableChain).length < 1) return;

        // prepare the template that shows the task to be executed
        let task_displayed = [];

        let count = 0;
        for (const act in executableChain) {
            if (executableChain.hasOwnProperty(act)) {

                let indx = count;
                count = count + 1;

                //console.log("Rendering the history of the executable list", act);

                let obj = executableChain[act];

                // build a div card for the action
                let tool = Object.keys(obj)[0];
                let actions = obj[tool].requirement;
                let secondaryActions = obj[tool].secondary;
                let memo = "";
                let memoSecondary = "";

                for (const key in actions) {
                    if (actions.hasOwnProperty(key)) {
                        memo += `<div class="mb-2">  <span class="text-light p-1 bg-dark"> ${key}   </span> : <span class="text-light">  ${actions[key]} </span> </div>`;

                    }
                }

                for (const key in secondaryActions) {
                    if (secondaryActions.hasOwnProperty(key)) {
                            memoSecondary += `<div class="mb-2">  <span class="text-light p-1 bg-dark">  ${key}  :</span>  <span class="text-light"> ${JSON.stringify(secondaryActions[key])} </span> </div>`;
                    }
                }


                let template = `
                                <div id="${act}" style="width:500px;" class="card  cardAct bg-secondary mx-auto">

                                        <div class="d-flex bg-dark card-title justify-content-between" >
                                            <h6 class="text-white ml-3 mt-2 text-capitalize"> Task (${count}) :: ${tool} Tool -->>> ${obj[tool].name} </h6>
                                        </div>
                                        
                                        <div class="card-body ">
                                       
                                                <div>
                                                    <div class="small" > ${memo} </div>
                                                </div>


                                                <div class="mt-4">
                                                    <hr>
                                                    <div class="small" > ${memoSecondary} </div>
                                                </div>
                     
                                        </div>

                                </div>
            
                                `;

                // clear the inputs by rendering the primary and secondary again
                task_displayed.push(template)

            }
        };

        for (let items in executableChain) {

            // render the list
            let li = `
                        <tr class="taskTodo" taskIndex="${index}"  >
                        <td class="col-6" style="vertical-align: middle;" scope="row">
                            <div class="my-5"> <small> ${task_displayed[index]} </small> </div>
                        </td>
                        <td class="col-3 " style="vertical-align: middle;" >
                            <input type="number" id="task_Exec_${index}" value="1" input_category="execution_Limit" class=" my-5 form-control w-50" style=" display: inline;" min="0" max="1000">
                        </td>
                        <td class="col-3 " style="vertical-align: middle;" >
                            <input type="number" id="task_Repeat_${index}" value="1" input_category="repeat_Limit" class=" my-5 form-control w-50" style=" display: inline;" min="0" max="1000">
                        </td>
                    </tr>
                    `;

            $("#adsClick").append(li)

            index++; //increment the index

        }

    }

    async depatchTask(botName, botTask, timeBeforeTask) {
        // This method would assign task to the bot

        //await this.sleep(timeBeforeTask)

        console.log("send task was engaged")


        await $.ajax({
            url: `http://localhost:3000/execute_botName`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                botName: botName, action: "task", compliment_data: {
                    task: botTask,
                    timeBeforeTask: timeBeforeTask
                }
            }),
        });

        console.log("send task was dispatched ")

        return "task dispatched";

    }

    async registerBotNet() {
        // this method registers a botnet to the server so it can keep track of it 

        await $.ajax({
            url: `/botAI`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                action: "add-botNet",
                networkID: this.botNetID
            })
        });

    }

    // Method to abort the AJAX request
    abortRequest() {
        if (this.jqxhr) {
            this.jqxhr.abort();
            console.log("request aborted")
        }
    }

    async launchBot(botInfo, botTask, timeBeforeTask, deviceBrand) {
        // This method switches on a bot

        let botName = JSON.parse(botInfo).Account.fullname;

        if (this.randomEngine == "off") {
            console.log("The engine has been turned off and so no need to be running");
            return;// return and end lauch because this engine has been stopped and no need to on further
        }

        this.jqxhr = $.ajax({
            url: `/power_botName`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                botName: botName, action: "activate", compliment_data: {
                    personality: JSON.parse(botInfo),
                    headless: "false",
                    proxyChain: this.getProxyChain(),
                    browserPath: await this.getExecutablePath(deviceBrand),
                    botNet: this.botNetID
                }
            }),
            error: function (jqXHR, textStatus, errorThrown) {
                if (textStatus === 'abort') {
                    console.log('Request aborted');
                } else {
                    console.log('Request failed:', textStatus, errorThrown);
                }
            }
        });

        // Await the request completion
        await this.jqxhr;

        await this.updateStatusBots(false);

        this.depatchTask(botName, botTask, timeBeforeTask)

        return "turned on";
    }

    async cycle(deviceBrand, Stat, executableChain, userAgent_brand, botFamily_Device_Brands) {

        // This method starts a cycle of turning bots on and giving them task. 

        // inquire how many devices to spawn
        let spawn = await this.device_Spawn_Range(Stat[3], userAgent_brand);

        if (spawn < 1) return "No devices to spawn";

        //pick devices to launch and the task to assign
        let bot = await this.pickRandomDevice(spawn, botFamily_Device_Brands[deviceBrand]);
        let task = (this.pickRandomTask(spawn, executableChain));



        let taskSecMin = Stat[0] * 1000;
        let taskSecMax = Stat[1] * 1000;

        let sleepTime = this.getRandomInt(taskSecMin, taskSecMax);

        // run them bot and asssign task to them automatedly
        for (let i = 0; i < spawn; i++) {
            await this.launchBot(bot[i], task[i], sleepTime, deviceBrand);
        }

        return "done";
    }

    async pickExecution(xTimes, deviceBrand) {

        let launchData = {
            bot: [],
            task: [],
            taskID: [],
            reach: 0
        };

        // this method would pick an execution in a this.refinedLubricant

        //while (launchData["reach"] < xTimes) {

        let botName;
        for (let taskId in this.refinedLubricant[deviceBrand]) {
            botName = this.refinedLubricant[deviceBrand][taskId].botName

            if (launchData["reach"] < xTimes) {
                // check if is not online and add it to the list and increment otherwise move to the next
                if (this.botStatus.runningBots.includes(botName) || launchData["bot"].includes(botName)) {
                    // The bot generated is already running so we would look away 
                } else {
                    // The bot generated is offline so we can switch it on

                    launchData["bot"].push(this.refinedLubricant[deviceBrand][taskId].personality);
                    launchData["task"].push(this.refinedLubricant[deviceBrand][taskId].task);
                    launchData["taskID"].push(taskId);
                    launchData["reach"] += 1;

                    console.log(launchData, "===>")
                }

            } else {
                break;
            }
        }

        //}

        console.log("this.refinedLubricant[deviceBrand] ==>> ", this.refinedLubricant[deviceBrand], "launch data ==> ", launchData);

        return launchData;

    }

    async SoundAlarm() {
        // If the task has all been executed sound an alarm, and pop up a screen
    
        if (this.alarmOn == false) return "Alarm mode is turned off";
        console.log("lets proceed to play the sound now")
    
        const playSound = async () => {
            let taskKeys = Object.keys(this.refinedLubricant);
    
            if (taskKeys.length < 1) {
                // All tasks have been executed
                console.log("No other task to be executed");
    
                // Play a sound to notify the user that the task has been completed
                let shouldInotify = true; // await $("#soundBar").attr("playAudio");
    
                if (shouldInotify) {
                    let soundUrl = "http://localhost:3000/sound/accomplished.mp3";
    
                    // Play the sound
                    console.log("play sound now");
    
                    // Create an audio object and play the sound
                    let audio = new Audio(soundUrl);
    
                    // Loop the sound
                    audio.addEventListener('ended', () => {
                        audio.currentTime = 0;
                        audio.play().catch(error => console.error('Error replaying sound:', error));
                    });
    
                    audio.play().catch(error => console.error('Error playing sound:', error));
                }
    
                await this.sleep(3000);
    
            } else {
                // recheck
                setTimeout(() => playSound.call(this), 1000);
            }
        };
    
        playSound.call(this); // Ensure the correct context is used
    }

    async orderlyCycle(deviceBrand, deviceMaxRange, userAgent_brand) {

        // This method receives a referrence [obj] stream line and picks executable

        // inquire how many devices to spawn
        let spawn = await this.device_Spawn_Range(deviceMaxRange, userAgent_brand);

        if (spawn < 1) return "No devices to spawn";


        let sleepTime = this.getRandomInt(1000, 5000);
        // run them bot and asssign task to them automatedly
        for (let i = 0; i < spawn; i++) {
            let validExecution = await this.pickExecution(spawn, deviceBrand)
            console.log("valid execution ==>> ", validExecution)
            await this.launchBot(validExecution["bot"][i], validExecution["task"][i], sleepTime, deviceBrand);
            delete this.refinedLubricant[deviceBrand][validExecution["taskID"][i]];
        }

        return "done";
    }

    async Active_deviceBrand(brand) {
        // This method returns the number of running devices in a device brand

        let devices = [];

        await this.updateStatusBots(false); // Update the bot list before we start checking the active list

        for (const item of this.botStatus.runningBots) {
            const userAgent = JSON.parse(item.personality).Device.userAgent;
            const botName = JSON.parse(item.personality).Account.fullname;

            if (userAgent.includes(brand)) {
                devices.push(botName);
            }
        }

        return [...devices]; // Return the count of running devices
    }

    async device_Spawn_Range(maxBrowsers, userAgent_brand) {
        /*
            This method would be used to get the number of stringified personality object that needs to be launched.
            This method would first get the length of this.active_Devices[device_brand] and minus the value from the minimum number and maximum number of active devices.
            The value of the substraction for the minimum and maximum number of active devices would be used to generate a random number.
            The random number would be returned as the range of devices to be spawned.
        */

        let active_Devices = (await this.Active_deviceBrand(userAgent_brand)).length;

        let range = this.getRandomInt(0, (maxBrowsers - active_Devices));

        return range;

    }

    disableOff() {
        var engineStatus = this.randomEngine; // Assuming this.randomEngine holds the value of the engine status

        // Disable or enable inputs based on engine status
        if (engineStatus == "on") {
            $("#botFamily, #executables, #iphone_min_taskTime, #iphone_max_taskTime, #iphone_active_min, #iphone_active_max, #android_min_taskTime, #android_max_taskTime, #android_active_min, #android_active_max, #mac_min_taskTime, #mac_max_taskTime, #mac_active_min, #mac_active_max, #win_min_taskTime, #win_max_taskTime, #win_active_min, #win_active_max").prop('disabled', true);
        } else {
            $("#botFamily, #executables, #iphone_min_taskTime, #iphone_max_taskTime, #iphone_active_min, #iphone_active_max, #android_min_taskTime, #android_max_taskTime, #android_active_min, #android_active_max, #mac_min_taskTime, #mac_max_taskTime, #mac_active_min, #mac_active_max, #win_min_taskTime, #win_max_taskTime, #win_active_min, #win_active_max").prop('disabled', false);
        }
    }

    countOccurrences(array, item) {
        return array.filter(currentItem => currentItem === item).length;
    }

    async shutDown_allBot() {

        let response = await $.ajax({
            url: `/botAI`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                action: "terminate-botNet",
                networkID: this.botNetID
            })
        });

        this.abortRequest()

        //further disable the bot for running again
        this.randomEngine = "off"

        $("#post-botNet").attr("category", "activate")
        $("#post-botNet").attr("src", "./images/power-on.png")
        this.disableOff()
        console.log("engine OFF")

        // off alarm
        this.alarmOn = false;

        return response;
    }

    getTimeStamp() {
        return new Date().getTime();
    }

    async isOperationPossible(self) {
        // To know if the operatin is possible or not

        var botFamily = await $("#botFamily").val();
        let botFamily_Device_Brands = this.classifyDevices();

        // devices count
        let iphoneCount = botFamily_Device_Brands.iphone.length;
        let androidCount = botFamily_Device_Brands.android.length;
        let winCount = botFamily_Device_Brands.windows.length;
        let macCount = botFamily_Device_Brands.mac.length;

        let deviceSum = (iphoneCount + androidCount + winCount + macCount);

        // Iphone department
        let iphone_min_taskTime = 1;
        let iphone_max_taskTime = 2;
        let iphone_active_min = parseInt($("#iphone_active_min").val());
        let iphone_active_max = parseInt($("#iphone_active_max").val());
        let iphoneExecStat = [iphone_min_taskTime, iphone_max_taskTime, iphone_active_min, iphone_active_max];

        // Android department
        let android_min_taskTime = 1;
        let android_max_taskTime = 2;
        let android_active_min = parseInt($("#android_active_min").val());
        let android_active_max = parseInt($("#android_active_max").val());
        let androidExecStat = [android_min_taskTime, android_max_taskTime, android_active_min, android_active_max];

        // Mac department
        let mac_min_taskTime = 1;
        let mac_max_taskTime = 2;
        let mac_active_min = parseInt($("#mac_active_min").val());
        let mac_active_max = parseInt($("#mac_active_max").val());
        let macExecStat = [mac_min_taskTime, mac_max_taskTime, mac_active_min, mac_active_max];

        // Windows department
        let win_min_taskTime = 1;
        let win_max_taskTime = 2;
        let win_active_min = parseInt($("#win_active_min").val());
        let win_active_max = parseInt($("#win_active_max").val());
        let winExecStat = [win_min_taskTime, win_max_taskTime, win_active_min, win_active_max];


        function valid_runInfo(self) {
            // Check if at least one device is valid

            if (
                self.isAllNum(iphoneExecStat) && self.isRange(iphone_min_taskTime, iphone_max_taskTime) && self.isRange(iphone_active_min, iphone_active_max) && iphoneCount > iphone_active_max ||
                self.isAllNum(androidExecStat) && self.isRange(android_min_taskTime, android_max_taskTime) && self.isRange(android_active_min, android_active_max) && androidCount > android_active_max ||
                self.isAllNum(macExecStat) && self.isRange(mac_min_taskTime, mac_max_taskTime) && self.isRange(mac_active_min, mac_active_max) && macCount > mac_active_max ||
                self.isAllNum(winExecStat) && self.isRange(win_min_taskTime, win_max_taskTime) && self.isRange(win_active_min, win_active_max) && winCount > win_active_max
            ) {
                return true; // At least one device is valid
            }
            return false; // No valid device
        }

        // Iphone control center
        if (this.isAllNum(iphoneExecStat)) {
            if (this.isRange(iphone_min_taskTime, iphone_max_taskTime) && this.isRange(iphone_active_min, iphone_active_max)) {

                //lets check if the execution is logically doable

                if (iphoneCount < iphone_active_max) {

                    return {
                        error: {
                            title: "Invalid Execution",
                            message: `The number of iphone devices in this bot family ==>> (${botFamily}) is below the maximum active devices you set which is ${iphone_active_max}`
                        }
                    }
                }

            } else {
                return {
                    error: {
                        title: "Invalid Iphone Execution",
                        message: `One of the min - max range is invalid, check the iphone section for a quick fix`
                    }
                }
            }
        }


        // Android control center
        if (this.isAllNum(androidExecStat)) {
            if (this.isRange(android_min_taskTime, android_max_taskTime) && this.isRange(android_active_min, android_active_max)) {

                //lets check if the execution is logically doable

                if (androidCount < android_active_max) {

                    return {
                        error: {
                            title: "Invalid Android Execution",
                            message: `The number of android devices in this bot family ==>> (${botFamily}) is below the maximum active devices you set which is ${android_active_max}`
                        }
                    }
                }

            } else {
                return {
                    error: {
                        title: "Invalid Android Execution",
                        message: `One of the min - max range is invalid, check the android section for a quick fix`
                    }
                }
            }
        }


        // Mac control center
        if (this.isAllNum(macExecStat)) {
            if (this.isRange(mac_min_taskTime, mac_max_taskTime) && this.isRange(mac_active_min, mac_active_max)) {

                //lets check if the execution is logically doable

                if (macCount < mac_active_max) {

                    return {
                        error: {
                            title: "Invalid Mac Execution",
                            message: `The number of mac devices in this bot family ==>>  (${botFamily}) is below the maximum active devices you set which is ${mac_active_max}`
                        }
                    }
                }

            } else {
                return {
                    error: {
                        title: "Invalid Mac Execution",
                        message: `One of the min - max range is invalid, check the mac section for a quick fix`
                    }
                }
            }
        }




        // Windows control center
        if (this.isAllNum(winExecStat)) {
            if (this.isRange(win_min_taskTime, win_max_taskTime) && this.isRange(win_active_min, win_active_max)) {

                //lets check if the execution is logically doable
                console.log("win:::", botFamily_Device_Brands)
                if (winCount < win_active_max) {

                    return {
                        error: {
                            title: "Invalid Windows Execution",
                            message: `The number of windows devices in this bot family ==>>  (${botFamily}) is below the maximum active devices you set which is ${win_active_max}`
                        }
                    }
                }

            } else {
                return {
                    error: {
                        title: "Invalid Windows Execution",
                        message: `One of the min - max range is invalid, check the windows section for a quick fix`
                    }
                }
            }
        }


        if (valid_runInfo(self) == false) {
            return {
                error: {
                    title: "Empty Execution instructions",
                    message: `No valid device range was specified. recheck your settings`
                }
            }
        }

        // lets loop through the executable and see if if all task can be executed at the max repeat specified

        let error = [];

        $('.taskTodo').each(function () {

            let taskIndex = parseInt($(this).attr('taskIndex'));
            let executeLimit = parseInt($(`#task_Exec_${taskIndex}`).val());    // Get the id of the element
            let repeatLimit = $(`#task_Repeat_${taskIndex}`).val(); // Get the name of the element
            let maxPossibleLimit = parseInt(deviceSum * repeatLimit);

            //check if any execution limit specified is greater than the maximum possible number of execution
            if (maxPossibleLimit < executeLimit) {
                error.push({
                    error: {
                        title: "Possibility Exceeds Specifications",
                        message: ` <ul>
                         <li> You have a total number of (${deviceSum}) bots in the botFamily ==> [${botFamily}]. </li>
                        <li> Task (${taskIndex + 1}) can not be executed (${executeLimit}) xTimes </li>
                        <li> Total device in botFamily (${deviceSum}) X maximum repeat of task by individual bot (${repeatLimit}) is ==> ${maxPossibleLimit} </li> 
                        
                        </ul> `
                    }
                })

                return false;
            }


        });

        if (error.length > 0) {
            return error[0]; // return the task with errors
        } else {
            return {
                success: true
            }
        }

    }

    async compileExecutionBorad() {
        // This method would prepare a map for the execution of activities

        let executionBoard = {
            iphone: {},
            android: {},
            mac: {},
            windows: {}
        }

        let executableChain = JSON.parse(this.executables[$("#executables").val()].data);

        let botFamily_Device_Brands = this.classifyDevices();

        // track devices that have a range
        let iphone_active_max = parseInt($("#iphone_active_max").val());
        let android_active_max = parseInt($("#android_active_max").val());
        let mac_active_max = parseInt($("#mac_active_max").val());
        let win_active_max = parseInt($("#win_active_max").val())

        //set self so jquery can use it on the tdo
        let self = this;

        $('.taskTodo').each(function () {

            let taskIndex = parseInt($(this).attr('taskIndex'));
            let executeLimit = parseInt($(`#task_Exec_${taskIndex}`).val());    // Get the id of the element
            let repeatLimit = $(`#task_Repeat_${taskIndex}`).val(); // Get the name of the element

            let taskTag = `task_${taskIndex}`;

            let taskKey = Object.keys(executableChain)[taskIndex]

            // track task executions
            let taskMapLength = 0;

            executionBoard["iphone"][taskTag] = {
                taskID: taskTag,
                task: executableChain[taskKey],
                executors: [],
            }

            executionBoard["android"][taskTag] = {
                taskID: taskTag,
                task: executableChain[taskKey],
                executors: [],
            }

            executionBoard["mac"][taskTag] = {
                taskID: taskTag,
                task: executableChain[taskKey],
                executors: [],
            }

            executionBoard["windows"][taskTag] = {
                taskID: taskTag,
                task: executableChain[taskKey],
                executors: [],
            }

            while (taskMapLength < executeLimit) {

                //generate order of execution

                if (iphone_active_max > 0 && taskMapLength < executeLimit) { // iphone needs to be popped up


                    // pick random iphone 
                    let generatedDevice = botFamily_Device_Brands["iphone"][self.getRandomInt(0, (botFamily_Device_Brands["iphone"].length - 1))];

                    if (self.countOccurrences(executionBoard["iphone"][taskTag]["executors"], generatedDevice) < repeatLimit) {
                        // This means we can add this device limit left for it

                        executionBoard["iphone"][taskTag]["executors"].push(generatedDevice);
                        taskMapLength += 1;
                    }
                }
                if (android_active_max > 0 && taskMapLength < executeLimit) { // android needs to be popped up


                    // pick random android 
                    let generatedDevice = botFamily_Device_Brands["android"][self.getRandomInt(0, (botFamily_Device_Brands["android"].length - 1))];

                    if (self.countOccurrences(executionBoard["android"][taskTag]["executors"], generatedDevice) < repeatLimit) {
                        // This means we can add this device limit left for it

                        executionBoard["android"][taskTag]["executors"].push(generatedDevice);
                        taskMapLength += 1;
                    }
                }
                if (mac_active_max > 0 && taskMapLength < executeLimit) { // mac needs to be popped up


                    // pick random mac 
                    let generatedDevice = botFamily_Device_Brands["mac"][self.getRandomInt(0, (botFamily_Device_Brands["mac"].length - 1))];

                    if (self.countOccurrences(executionBoard["mac"][taskTag]["executors"], generatedDevice) < repeatLimit) {
                        // This means we can add this device limit left for it

                        executionBoard["mac"][taskTag]["executors"].push(generatedDevice);
                        taskMapLength += 1;
                    }
                }
                if (win_active_max > 0 && taskMapLength < executeLimit) { // win needs to be popped up


                    // pick random win 
                    let generatedDevice = botFamily_Device_Brands["windows"][self.getRandomInt(0, (botFamily_Device_Brands["windows"].length - 1))];

                    if (self.countOccurrences(executionBoard["windows"][taskTag]["executors"], generatedDevice) < repeatLimit) {
                        // This means we can add this device limit left for it

                        executionBoard["windows"][taskTag]["executors"].push(generatedDevice);
                        taskMapLength += 1;
                    }
                }

            }

        });

        //now lets refine the data in a way it can be executed at a goal with no issues 
        let refinedExecutionBoard = {
            iphone: {},
            android: {},
            mac: {},
            windows: {},
        };


        executionBoard;

        //refine iphone
        for (let device in executionBoard) {

            for (let task in executionBoard[device]) {
                let executorsHere = executionBoard[device][task]["executors"];
                let taskHere = executionBoard[device][task]["task"]

                for (let i = 0; i < executorsHere.length; i++) {

                    let botName = JSON.parse(executorsHere[i]).Account.fullname;
                    let botObj = executorsHere[i];
                    // now add it

                    refinedExecutionBoard[device][`${task}_${botName}_${i}`] = {
                        botName: botName,
                        task: taskHere,
                        personality: botObj
                    }
                }

            }

        }


        this.refinedLubricant = refinedExecutionBoard;
        return this.refinedLubricant;

    }

    async startEngine() {


        if (this.randomEngine == "off") { return "Engine has been shutDown" }


        // This method would prepare a botNet for activation

        let botFamily_Device_Brands = this.classifyDevices();

        // devices count
        let iphoneCount = botFamily_Device_Brands.iphone.length;
        let androidCount = botFamily_Device_Brands.android.length;
        let winCount = botFamily_Device_Brands.windows.length;
        let macCount = botFamily_Device_Brands.mac.length;

        // Iphone department
        var iphone_active_max = parseInt($("#iphone_active_max").val());

        // Android department
        var android_active_max = parseInt($("#android_active_max").val());

        // Mac department
        var mac_active_max = parseInt($("#mac_active_max").val());

        // Windows department
        var win_active_max = parseInt($("#win_active_max").val());

        let executionList = []; // storage to hold all devices to run executable on

        try {


            if (iphoneCount > iphone_active_max && Object.keys(this.refinedLubricant["iphone"]).length > 0) {

                executionList.push(this.orderlyCycle("iphone", iphone_active_max, "iPhone"))

            }


            if (androidCount > android_active_max && Object.keys(this.refinedLubricant["android"]).length > 0) {

                executionList.push(this.orderlyCycle("android", android_active_max, "Android"))

            }

            if (macCount > mac_active_max && Object.keys(this.refinedLubricant["mac"]).length > 0) {

                executionList.push(this.orderlyCycle("mac", mac_active_max, "Mac"))

            }

            if (winCount > win_active_max && Object.keys(this.refinedLubricant["windows"]).length > 0) {

                executionList.push(this.orderlyCycle("windows", win_active_max, "Win"))

            }


            if (executionList.length > 0) {

                // This means we have something to execute, time to atmnosphere

                $("#post-botNet").attr("category", "deactivate")
                $("#post-botNet").attr("src", "./images/power-off.png")

                //start loading modal with a loading bot
                $("#loadingBot").modal({
                    backdrop: 'static',
                    keyboard: false
                })

                this.disableOff();

                await Promise.allSettled(executionList).then(async () => {
                    await this.sleep(1000);
                    $("#loadingBot").modal("hide");
                })


            }


            console.log("I am done with execution all available devices", executionList)


        } catch (e) {

            console.log("An error occured", e)

        } finally {
            let allFinished = true;

            // for( let device in this.refinedLubricant){
            //     if(Object.keys(this.refinedLubricant[device]))
            // }

            console.log(this.refinedLubricant)

            if ((this.randomEngine == "on") && ($("#post-botNet").attr("category") == "deactivate") ) {

                await this.sleep(3000);
                console.log("running this again!",this.refinedLubricant)
                this.startEngine(this.refinedLubricant);

            }else{
                this.refinedLubricant = null;
            }
        }

    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }


    getBotInfo(botName) {

        let personality = [];
        // run a lopp across the personality and return an object containing the details on personality
        this.personalities.forEach(function (item) {
            if (item.fullname == botName) {
                personality = item.personality
            }
        })

        return JSON.parse(personality).Device;
    }

    async renderFilter() {
        //console.log(" rendering table with the filter applied",this.filterConfig)
        // Get the selected option
        let selectedBotName = $("#botFamily").val();

        let rawData = [...this.botStatus.offBots];

        // Create a regular expression to match the selected bot name with any numeric suffix
        const regex = new RegExp(`^${selectedBotName}(-\\d+)?$`);

        // Filter rawData to include only items that match the regex
        let filtered = rawData.filter(item => regex.test(item.fullname));

        $.each(this.filterConfig[selectedBotName], (key, index) => {

            if (this.filterConfig[selectedBotName][key] == false) {

                $(`[catalogue='${key}']`).addClass('false')

                filtered = filtered.filter(item => {
                    let check = JSON.parse(item.personality).Device.userAgent.includes(key);
                    if (check) { return false } else { return true }
                })
            }

        });

        if (this.botList != "active") {

            this.filteredList = filtered.sort((a, b) => a.fullname.localeCompare(b.fullname)); // sort the array by names
            this.renderEngine.listBotTable(this.filteredList);
            await this.renderEngine.renderPagination(this.filteredList);
            this.countDevices(this.filteredList, false)
        } else {

            this.renderEngine.listBotTable(this.botStatus.runningBots);
            await this.renderEngine.renderPagination(this.botStatus.runningBots);
            this.countDevices(this.botStatus.runningBots, false)

        }


    }


    async setupFilter() {
        await this.filterBotName().then((names) => {

            names.forEach(item => {

                $("#botFamily").append(`<option value="${item}" > ${item} </option>`)
                this.filterConfig[item] = {
                    iPhone: true,
                    Android: true,
                    Windows: true,
                    Mac: true
                }
            })

        })

        // now the option has been loaded, now count the devices and display them.
        // lets listen to the devices
        $("#botFamily").change(() => {
            $("#discipline").remove();
            this.renderEngine.currentPage = 1; //reset the page so it doesnt disturb our new selection
            $(".filterOs").removeClass("false")
            this.renderFilter();
        })

    }

    filterBotName() {
        // this function would filter the names of the personalities
        // it will remove the 001,002,003... and push all the names into an array and then 
        // remake a new array with only unique names meaning repitition of names are not done on the new array
        // this unique names array would then saved in the filterConfig object followed by the allowed operatinng systems
        let rawData = [...this.botStatus.offBots];

        // Use a Set to store unique names
        let uniqueNamesSet = new Set();

        // Regular expression to match the numeric suffix
        const regex = /-\d+$/;

        // Iterate over rawData to extract and clean names
        rawData.forEach(item => {
            const cleanName = item.fullname.replace(regex, ""); // Remove the numeric suffix
            uniqueNamesSet.add(cleanName); // Add to the set, which keeps only unique values
        });

        // Convert the set back to an array
        let uniqueNames = Array.from(uniqueNamesSet);

        return Promise.resolve(uniqueNames)
    }

    async init() {
        await this.loadData();
        await this.updateStatusBots(false)
        this.botList == "inActive" ? this.render(this.botStatus.offBots) : this.render(this.botStatus.runningBots)
        await this.setupFilter()

        let executables = [];

        // load the executables
        await $.post(`https://okecbot.com/api/index.php?key=${this.apiKey}&showActivities`).then(async function (data) {

            $("#execute-container").append(`<select category="secondary" class="custom-select mt-3" id="executable" ></select>`);
            // lets make a select option for it
            data["json"].forEach((element, index) => {
                $("#executables").append(`<option value="${index}" > ${element.title} </option>`)
            });

            // update executable
            executables = data["json"];


        })

        this.executables = executables;

        this.renderTodoTask(); // render the executable first 
        $("#loadingData").modal('hide');

        await this.setProxyChain(); // load the proxyChain


    }

    async loadData() {
        return new Promise(async (resolve) => {
            this.apiKey = (await $.get("login/key.json")).apiKey;
            try {
                let response = await $.ajax({ url: `https://okecbot.com/api/index.php?key=${this.apiKey}&request=personality`, method: "GET", dataType: "json" });
                this.personalities = response;
                resolve();

            } catch (error) {
                console.error("Error loading data:", error);
            }
        });
    }


    countDevices(filtered, target) {
        let deviceCounts = { iPhone: 0, Android: 0, Windows: 0, Mac: 0 };


        filtered.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                deviceCounts.iPhone++;
            } else if (userAgent.includes("Android")) {
                deviceCounts.Android++;
            }
            else if (userAgent.includes("Win")) {
                deviceCounts.Windows++;

            } else if (userAgent.includes("Mac")) {
                deviceCounts.Mac++;
            }
        });

        let sum = Object.values(deviceCounts).reduce((a, b) => a + b);

        if (target == undefined) {
            $('#iphoneCount').text(deviceCounts.iPhone)
            $('#androidCount').text(deviceCounts.Android)
            $('#winCount').text(deviceCounts.Windows)
            $('#macCount').text(deviceCounts.Mac)
            $('#activeBrowsers').text(sum)
        } else {
            $('#filteredIphoneCount').text(deviceCounts.iPhone)
            $('#filteredAndroidCount').text(deviceCounts.Android)
            $('#filteredWinCount').text(deviceCounts.Windows)
            $('#filteredMacCount').text(deviceCounts.Mac)
        }
    }

    classifyDevices() {
        let devices = { iphone: [], android: [], windows: [], mac: [] };

        this.filteredList.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                devices.iphone.push(item.personality);
            } else if (userAgent.includes("Android")) {
                devices.android.push(item.personality);
            } else if (userAgent.includes("Win")) {
                devices.windows.push(item.personality);
            } else if (userAgent.includes("Mac")) {
                devices.mac.push(item.personality);
            }


        });

        return devices;


    }

    async updateStatusBots(loader = true) {
        if (loader) {
            $("#loadingData").modal("show");
        }
        return new Promise(async resolve => {
            let fullData = [...this.personalities];
            let fileNames = fullData.map(value => value.fullname);
            let on = [];
            let off = [];

            for (let i = 0; i < fileNames.length; i++) {
                try {
                    const response = await $.ajax({
                        url: `http://localhost:3000/isRunning`,
                        method: "POST",
                        dataType: "json",
                        contentType: 'application/json',
                        data: JSON.stringify({ botName: fileNames[i] }),
                    });

                    if (response.status === 'running') {
                        on.push(fullData[i]);
                    } else {
                        off.push(fullData[i]);
                    }
                } catch (error) {
                    console.error('Error checking if the bot file is running:', error);
                }

            }

            this.botStatus.runningBots = [...on];
            this.botStatus.offBots = [...off];
            // hide loading Modal
            if (loader) {
                await this.sleep(1000); // some fast computers might load this fast in less than a sec making loader hang
                $("#loadingData").modal("hide");
            }
            resolve();
        });
    }

    async render(filtered) {

        return new Promise(async (resolve) => {


            await this.updateStatusBots(false);
            this.renderEngine.listBotTable(filtered);

            await this.renderEngine.renderPagination(filtered);
            this.countDevices(filtered)
            this.renderFilter();
            resolve();
        })
    }



}