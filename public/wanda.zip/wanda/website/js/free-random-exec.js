import { renderData } from './tableRender.js';
export class botAi {

    // This class would handle the random execution

    constructor() {
        console.log(" Random launcher initiated ;")
        // Initialize state variables
        this.botList = "inActive";
        this.botStatus = {
            runningBots: ['notUpdated'],
            offBots: ['notUpdated']
        };
        this.apiKey = null;
        this.personalities = 'notLoaded';
        this.executables = 'notLoaded';

        // renderEngine
        this.renderEngine = new renderData({
            currentPage: 1,
            itemsPerPage: 12,
            botEngine: this
        });


        this.isPaid = true;

        this.filterConfig = {};
        this.filteredList = null;
        this.checkedList = [];

        this.proxyChain = null;
        this.randomEngine = "off";
        // generate an ID for this session
        this.botNetID = `${this.getTimeStamp()}`;

        this.jqxhr = null; // Variable to store the jqXHR objectß

        // initaite this object,load the necessary data
        this.init()

        this.updateTitle() // always update location on title

    }

    async updateTitle() {
        // This method sets an interval to keep updating the title of the page

        let self = this;
        setInterval(function () {
            let location = $('#proxyChain').find('option:selected').text();
            $('title').text(location);

        }, 1000)
    }

    async isBotOff() {
        /*
            Thius section of the bot checks of the power button has been off
            if it has it resolves there by terminating anyProcess going On
            This is a mechanism to halt pinging a bot while the loadingBot screen keeps showing, there by slow us down
        */


    }

    getProxyChain() {
        // This method returns a null or a proxy depending on the location value

        let locationValue = $("#proxyChain").val();

        if (locationValue == "null") {
            // This means the user is at null
            console.log("no proxyChain selected")
            return null
        }

        // since we didnt return above, lets procceed into sending the proxy

        let proxy = JSON.parse(this.proxyChain[locationValue]['data']);

        //console.log(proxy, " <== proxy");
        proxy = proxy[(Object.keys(proxy)[this.getRandomInt(0, (Object.keys(proxy).length - 1))])]

        //console.log(proxy, " ==> proxy");

        return proxy;

    }

    async setProxyChain() {
        /*
         *  This method would set the proxyChain
        */

        let self = this;

        await $.ajax({
            method: "POST",
            url: `https://okecbot.com/api/index.php?key=${self.apiKey}&showLocations`,
            contentType: "application/json",
            dataType: "json",
            success: function (response) {
                if (response.status == "success") {

                    let records = response.json;

                    //save it in memory here
                    self.proxyChain = records;
                    //console.log("proxyChain saved in memory", records)

                    records.forEach((element, index) => {
                        try {

                            let obj = JSON.parse(element.data);

                            $("#proxyChain").append(`<option value="${index}" > ${element.chainName}  </option>`)
                        } catch (e) { }
                    });


                } else {

                    // disable theproxyChain button because something is wrong.


                }
            },
            error: function (error) {
                console.log(" Couldnt send ! ")
            }
        });
    }


    async upgradePopup() {
        // This method is used to prompt a user to upgrade there APIkey access so as to gain access tot this feature

        let Okectimer = 9;

        let timeInt = setInterval(() => {

            let timer = document.getElementById("timer");
            timer.innerHTML = Okectimer;
            // reduce the timer by 1;
            --Okectimer;

            if (Okectimer < 0) {
                clearInterval(timeInt)
            }

        }, 1000)

        $("#error_Msg").html(`
                   2Nno active random executor subscription. click access / limitation to subscribe and unlock.
                     `)

        $("#popError").css("display", "flex")
        await this.sleep(10000);
        $("#popError").css("display", "none")

    }

    async getExecutablePath(deviceBrand) {
        // This method would provide us with the path to the browser we would use for launching

        // for iphone browser pop up
        if (deviceBrand == "iphone") {

            let iphone_browser = $("#iphone_browser").val();
            if (iphone_browser.trim().length < 10) return null


            console.log(iphone_browser, " <== ", deviceBrand)

            return iphone_browser;

        }

        // for android browser pop up
        if (deviceBrand == "android") {

            let android_browser = $("#android_browser").val();
            if (android_browser.trim().length < 10) return null

            console.log(android_browser, " <== ")
            return android_browser;

        }

        // for windows browser pop up
        if (deviceBrand == "Win") {

            let win_browser = $("#win_browser").val();
            if (win_browser.trim().length < 10) return null

            console.log(win_browser, " <== ")

            return win_browser;

        }

        // for mac browser pop up
        if (deviceBrand == "mac") {

            let mac_browser = $("#mac_browser").val();
            if (mac_browser.trim().length < 10) return null

            console.log(mac_browser, " <== ")

            return mac_browser;

        }

    }

    isRange(min, max) {
        // Check if min and max are both numbers
        if (typeof min !== 'number' || typeof max !== 'number') {
            return false;
        }

        // Check if min and max are both integers or floats
        if (!Number.isInteger(min) || !Number.isInteger(max)) {
            return false;
        }

        // Check if min is less than max
        return min < max;
    }

    async pickRandomDevice(number_of_picks, deviceBrand) {
        // This method returns a number of switched off devices from a device brand in an array

        // create a new set to store unique devices
        let devices = new Set();

        while (devices.size < number_of_picks) {

            let generatedDevice = deviceBrand[this.getRandomInt(1, (deviceBrand.length - 1))];
            let deviceName = JSON.parse(generatedDevice).Account.fullname;

            // check if the device generated is not on the list of running bots, and add it else ignore
            if (this.botStatus.runningBots.includes(deviceName)) {
                // The bot generated is already running so we would look away 
            } else {
                // The bot generated is offline so we can switch it on

                devices.add(generatedDevice);
            }

        }

        return [...devices];
    }

    pickRandomTask(number_of_picks, executableChain) {
        // This method returns a number of randomly picked task in an array

        // create an array to store random task
        let task = [];

        while (task.length < number_of_picks) {


            let generatedTask = executableChain[(Object.keys(executableChain)[this.getRandomInt(0, (Object.keys(executableChain).length - 1))])]

            // add the task to the array

            task.push(generatedTask)

        }

        return [...task];
    }

    isAllNum(array) {
        // Loop through each element of the array
        for (let i = 0; i < array.length; i++) {
            // Check if the element is not a positive integer
            if (!(/^\d+$/.test(array[i])) || parseInt(array[i]) <= 0) {
                return false; // If it's not a positive integer, return false
            }
        }
        // If all elements are positive integers, return true
        return true;
    }

    async depatchTask(botName, botTask, timeBeforeTask) {
        // This method would assign task to the bot

        //await this.sleep(timeBeforeTask)

        console.log("send task was engaged")


        await $.ajax({
            url: `http://localhost:3000/execute_botName`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                botName: botName, action: "task", compliment_data: {
                    task: botTask,
                    timeBeforeTask: timeBeforeTask
                }
            }),
        });

        console.log("send task was dispatched ")

        return "task dispatched";

    }

    async registerBotNet() {
        // this method registers a botnet to the server so it can keep track of it 

        await $.ajax({
            url: `/botAI`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                action: "add-botNet",
                networkID: this.botNetID
            })
        });

    }

    // Method to abort the AJAX request
    abortRequest() {
        if (this.jqxhr) {
            this.jqxhr.abort();
            console.log("request aborted")
        }
    }

    async launchBot(botInfo, botTask, timeBeforeTask, deviceBrand) {
        // This method switches on a bot

        let botName = JSON.parse(botInfo).Account.fullname;

        if (this.randomEngine == "off") {
            console.log("The engine has been turned off and so no need to be running");
            return;// return and end lauch because this engine has been stopped and no need to on further
        }

        this.jqxhr = $.ajax({
            url: `/power_botName`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                botName: botName, action: "activate", compliment_data: {
                    personality: JSON.parse(botInfo),
                    headless: "false",
                    proxyChain: this.getProxyChain(),
                    browserPath: await this.getExecutablePath(deviceBrand),
                    botNet: this.botNetID,
                    noCookie:true, // this would disable cookie and bot state
                }
            }),
            error: function (jqXHR, textStatus, errorThrown) {
                if (textStatus === 'abort') {
                    console.log('Request aborted');
                } else {
                    console.log('Request failed:', textStatus, errorThrown);
                }
            }
        });

        // Await the request completion
        await this.jqxhr;

        await this.updateStatusBots(false);

        this.depatchTask(botName, botTask, timeBeforeTask)

        return "turned on";
    }

    async cycle(deviceBrand, Stat, executableChain, userAgent_brand, botFamily_Device_Brands) {

        // This method starts a cycle of turning bots on and giving them task. 

        // inquire how many devices to spawn
        let spawn = await this.device_Spawn_Range(Stat[3], userAgent_brand);

        if (spawn < 1) return "No devices to spawn";

        //pick devices to launch and the task to assign
        let bot = await this.pickRandomDevice(spawn, botFamily_Device_Brands[deviceBrand]);
        let task = (this.pickRandomTask(spawn, executableChain));



        let taskSecMin = Stat[0] * 1000;
        let taskSecMax = Stat[1] * 1000;

        let sleepTime = this.getRandomInt(taskSecMin, taskSecMax);

        // run them bot and asssign task to them automatedly
        for (let i = 0; i < spawn; i++) {
            await this.launchBot(bot[i], task[i], sleepTime, deviceBrand);
        }

        return "done";
    }
    async Active_deviceBrand(brand) {
        // This method returns the number of running devices in a device brand

        let devices = [];

        await this.updateStatusBots(false); // Update the bot list before we start checking the active list

        for (const item of this.botStatus.runningBots) {
            const userAgent = JSON.parse(item.personality).Device.userAgent;
            const botName = JSON.parse(item.personality).Account.fullname;

            if (userAgent.includes(brand)) {
                devices.push(botName);
            }
        }

        return [...devices]; // Return the count of running devices
    }

    async device_Spawn_Range(maxBrowsers, userAgent_brand) {
        /*
            This method would be used to get the number of stringified personality object that needs to be launched.
            This method would first get the length of this.active_Devices[device_brand] and minus the value from the minimum number and maximum number of active devices.
            The value of the substraction for the minimum and maximum number of active devices would be used to generate a random number.
            The random number would be returned as the range of devices to be spawned.
        */

        let active_Devices = (await this.Active_deviceBrand(userAgent_brand)).length;

        let range = this.getRandomInt(0, (maxBrowsers - active_Devices));

        return range;

    }

    disableOff() {
        var engineStatus = this.randomEngine; // Assuming this.randomEngine holds the value of the engine status

        // Disable or enable inputs based on engine status
        if (engineStatus == "on") {
            $("#botFamily, #executables, #iphone_min_taskTime, #iphone_max_taskTime, #iphone_active_min, #iphone_active_max, #android_min_taskTime, #android_max_taskTime, #android_active_min, #android_active_max, #mac_min_taskTime, #mac_max_taskTime, #mac_active_min, #mac_active_max, #win_min_taskTime, #win_max_taskTime, #win_active_min, #win_active_max").prop('disabled', true);
        } else {
            $("#botFamily, #executables, #iphone_min_taskTime, #iphone_max_taskTime, #iphone_active_min, #iphone_active_max, #android_min_taskTime, #android_max_taskTime, #android_active_min, #android_active_max, #mac_min_taskTime, #mac_max_taskTime, #mac_active_min, #mac_active_max, #win_min_taskTime, #win_max_taskTime, #win_active_min, #win_active_max").prop('disabled', false);
        }
    }

    async shutDown_allBot() {

        let response = await $.ajax({
            url: `/botAI`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                action: "terminate-botNet",
                networkID: this.botNetID
            })
        });

        this.abortRequest()

        //further disable the bot for running again
        this.randomEngine = "off"

        $("#post-botNet").attr("category", "activate")
        $("#post-botNet").attr("src", "./images/power-on.png")
        this.disableOff()
        console.log("engine OFF")

        return response;
    }

    getTimeStamp() {
        return new Date().getTime();
    }

    async isOperationPossible(self) {
        // To know if the operatin is possible or not

        let botFamily_Device_Brands = this.classifyDevices();

        // devices count
        let iphoneCount = botFamily_Device_Brands.iphone.length;
        let androidCount = botFamily_Device_Brands.android.length;
        let winCount = botFamily_Device_Brands.windows.length;
        let macCount = botFamily_Device_Brands.mac.length;

        // Iphone department
        let iphone_min_taskTime = 1;
        let iphone_max_taskTime = 2;
        let iphone_active_min = parseInt($("#iphone_active_min").val());
        let iphone_active_max = parseInt($("#iphone_active_max").val());
        let iphoneExecStat = [iphone_min_taskTime, iphone_max_taskTime, iphone_active_min, iphone_active_max];

        // Android department
        let android_min_taskTime = 1;
        let android_max_taskTime = 2;
        let android_active_min = parseInt($("#android_active_min").val());
        let android_active_max = parseInt($("#android_active_max").val());
        let androidExecStat = [android_min_taskTime, android_max_taskTime, android_active_min, android_active_max];

        // Mac department
        let mac_min_taskTime = 1;
        let mac_max_taskTime = 2;
        let mac_active_min = parseInt($("#mac_active_min").val());
        let mac_active_max = parseInt($("#mac_active_max").val());
        let macExecStat = [mac_min_taskTime, mac_max_taskTime, mac_active_min, mac_active_max];

        // Windows department
        let win_min_taskTime = 1;
        let win_max_taskTime = 2;
        let win_active_min = parseInt($("#win_active_min").val());
        let win_active_max = parseInt($("#win_active_max").val());
        let winExecStat = [win_min_taskTime, win_max_taskTime, win_active_min, win_active_max];

        function valid_runInfo(self) {
            // Check if at least one device is valid

            if (
                self.isAllNum(iphoneExecStat) && self.isRange(iphone_min_taskTime, iphone_max_taskTime) && self.isRange(iphone_active_min, iphone_active_max) && iphoneCount > iphone_active_max ||
                self.isAllNum(androidExecStat) && self.isRange(android_min_taskTime, android_max_taskTime) && self.isRange(android_active_min, android_active_max) && androidCount > android_active_max ||
                self.isAllNum(macExecStat) && self.isRange(mac_min_taskTime, mac_max_taskTime) && self.isRange(mac_active_min, mac_active_max) && macCount > mac_active_max ||
                self.isAllNum(winExecStat) && self.isRange(win_min_taskTime, win_max_taskTime) && self.isRange(win_active_min, win_active_max) && winCount > win_active_max
            ) {
                return true; // At least one device is valid
            }
            return false; // No valid device
        }

        // return if the operation is possible
        return valid_runInfo(self);
    }

    async startEngine() {


        if (this.randomEngine == "off") { return "Engine has been shutDown" }

        if (this.isPaid == false) { await this.upgradePopup(); return; }

        //register the botnet 
        await this.registerBotNet();


        // This method would prepare a botNet for activation

        var botFamily = await $("#botFamily").val();
        let botFamily_Device_Brands = this.classifyDevices();

        // devices count
        let iphoneCount = botFamily_Device_Brands.iphone.length;
        let androidCount = botFamily_Device_Brands.android.length;
        let winCount = botFamily_Device_Brands.windows.length;
        let macCount = botFamily_Device_Brands.mac.length;

        var executableChain = JSON.parse(this.executables[$("#executables").val()].data);


        // Iphone department
        var iphone_min_taskTime = 1;
        var iphone_max_taskTime = 2;
        var iphone_active_min = parseInt($("#iphone_active_min").val());
        var iphone_active_max = parseInt($("#iphone_active_max").val());
        let iphoneExecStat = [iphone_min_taskTime, iphone_max_taskTime, iphone_active_min, iphone_active_max];

        // Android department
        var android_min_taskTime = 1;
        var android_max_taskTime = 2;
        var android_active_min = parseInt($("#android_active_min").val());
        var android_active_max = parseInt($("#android_active_max").val());
        let androidExecStat = [android_min_taskTime, android_max_taskTime, android_active_min, android_active_max];

        // Mac department
        var mac_min_taskTime = 1;
        var mac_max_taskTime = 2;
        var mac_active_min = parseInt($("#mac_active_min").val());
        var mac_active_max = parseInt($("#mac_active_max").val());
        let macExecStat = [mac_min_taskTime, mac_max_taskTime, mac_active_min, mac_active_max];

        // Windows department
        var win_min_taskTime = 1;
        var win_max_taskTime = 2;
        var win_active_min = parseInt($("#win_active_min").val());
        var win_active_max = parseInt($("#win_active_max").val());
        let winExecStat = [win_min_taskTime, win_max_taskTime, win_active_min, win_active_max];

        let executionList = []; // storage to hold all devices to run executable on

        function valid_runInfo(self) {
            // Check if at least one device is valid

            if (
                self.isAllNum(iphoneExecStat) && self.isRange(iphone_min_taskTime, iphone_max_taskTime) && self.isRange(iphone_active_min, iphone_active_max) && iphoneCount > iphone_active_max ||
                self.isAllNum(androidExecStat) && self.isRange(android_min_taskTime, android_max_taskTime) && self.isRange(android_active_min, android_active_max) && androidCount > android_active_max ||
                self.isAllNum(macExecStat) && self.isRange(mac_min_taskTime, mac_max_taskTime) && self.isRange(mac_active_min, mac_active_max) && macCount > mac_active_max ||
                self.isAllNum(winExecStat) && self.isRange(win_min_taskTime, win_max_taskTime) && self.isRange(win_active_min, win_active_max) && winCount > win_active_max
            ) {
                return true; // At least one device is valid
            }
            return false; // No valid device
        }

        try {

            // Iphone control center
            if (this.isAllNum(iphoneExecStat)) {
                if (this.isRange(iphone_min_taskTime, iphone_max_taskTime) && this.isRange(iphone_active_min, iphone_active_max)) {

                    //lets check if the execution is logically doable

                    if (iphoneCount > iphone_active_max) {

                        executionList.push(this.cycle("iphone", iphoneExecStat, executableChain, "iPhone", botFamily_Device_Brands))

                    } else {
                        this.renderEngine.popInfo({
                            title: "Invalid Execution",
                            message: `The number of iphone devices in this bot family (${botFamily}) is below the maximum active devices you set which is ${iphone_active_max}`
                        });

                        // should a process be running shut it down
                        this.shutDown_allBot();
                    }

                } else {
                    this.renderEngine.popInfo({
                        title: "Invalid Iphone Execution",
                        message: `One of the min - max range is invalid, check the iphone section for a quick fix`
                    })
                    // should a process be running shut it down
                    this.shutDown_allBot();
                }
            }


            // Android control center
            if (this.isAllNum(androidExecStat)) {
                if (this.isRange(android_min_taskTime, android_max_taskTime) && this.isRange(android_active_min, android_active_max)) {

                    //lets check if the execution is logically doable

                    if (androidCount > android_active_max) {

                        executionList.push(this.cycle("android", androidExecStat, executableChain, "Android", botFamily_Device_Brands))

                    } else {
                        this.renderEngine.popInfo({
                            title: "Invalid Android Execution",
                            message: `The number of android devices in this bot family (${botFamily}) is below the maximum active devices you set which is ${android_active_max}`
                        })

                        // should a process be running shut it down
                        this.shutDown_allBot();
                    }

                } else {
                    this.renderEngine.popInfo({
                        title: "Invalid Android Execution",
                        message: `One of the min - max range is invalid, check the android section for a quick fix`
                    })

                    // should a process be running shut it down
                    this.shutDown_allBot();
                }
            }


            // Mac control center
            if (this.isAllNum(macExecStat)) {
                if (this.isRange(mac_min_taskTime, mac_max_taskTime) && this.isRange(mac_active_min, mac_active_max)) {

                    //lets check if the execution is logically doable

                    if (macCount > mac_active_max) {

                        executionList.push(this.cycle("mac", macExecStat, executableChain, "Mac", botFamily_Device_Brands))

                    } else {
                        this.renderEngine.popInfo({
                            title: "Invalid Mac Execution",
                            message: `The number of mac devices in this bot family (${botFamily}) is below the maximum active devices you set which is ${mac_active_max}`
                        })
                        // should a process be running shut it down
                        this.shutDown_allBot();
                    }

                } else {
                    this.renderEngine.popInfo({
                        title: "Invalid Mac Execution",
                        message: `One of the min - max range is invalid, check the mac section for a quick fix`
                    })
                    // should a process be running shut it down
                    this.shutDown_allBot();
                }
            }




            // Windows control center
            if (this.isAllNum(winExecStat)) {
                if (this.isRange(win_min_taskTime, win_max_taskTime) && this.isRange(win_active_min, win_active_max)) {

                    //lets check if the execution is logically doable
                    console.log("win:::", botFamily_Device_Brands)
                    if (winCount > win_active_max) {

                        executionList.push(this.cycle("windows", winExecStat, executableChain, "Win", botFamily_Device_Brands))

                    } else {
                        this.renderEngine.popInfo({
                            title: "Invalid Windows Execution",
                            message: `The number of windows devices in this bot family (${botFamily}) is below the maximum active devices you set which is ${win_active_max}`
                        })
                        // should a process be running shut it down
                        this.shutDown_allBot();
                    }

                } else {
                    this.renderEngine.popInfo({
                        title: "Invalid Windows Execution",
                        message: `One of the min - max range is invalid, check the windows section for a quick fix`
                    })
                    // should a process be running shut it down
                    this.shutDown_allBot();
                }
            }


            if (executionList.length > 0) {

                // This means we have something to execute, time to atmnosphere

                $("#post-botNet").attr("category", "deactivate")
                $("#post-botNet").attr("src", "./images/power-off.png")

                //start loading modal with a loading bot
                $("#loadingBot").modal({
                    backdrop: 'static',
                    keyboard: false
                })

                this.disableOff();

                await Promise.allSettled(executionList).then(async () => {
                    await this.sleep(1000);
                    $("#loadingBot").modal("hide");
                })


            }


            console.log("I am done with execution all available devices", executionList)


        } catch (e) {

            console.log("An error occured", e)

        } finally {
            if ((this.randomEngine == "on") && (valid_runInfo(this) == true) && ($("#post-botNet").attr("category") == "deactivate")) {

                await this.sleep(3000);
                this.startEngine();

            }
        }

    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }


    getBotInfo(botName) {

        let personality = [];
        // run a lopp across the personality and return an object containing the details on personality
        this.personalities.forEach(function (item) {
            if (item.fullname == botName) {
                personality = item.personality
            }
        })

        return JSON.parse(personality).Device;
    }

    async renderFilter() {
        //console.log(" rendering table with the filter applied",this.filterConfig)
        // Get the selected option
        let selectedBotName = $("#botFamily").val();

        let rawData = [...this.botStatus.offBots];

        // Create a regular expression to match the selected bot name with any numeric suffix
        const regex = new RegExp(`^${selectedBotName}(-\\d+)?$`);

        // Filter rawData to include only items that match the regex
        let filtered = rawData.filter(item => regex.test(item.fullname));

        $.each(this.filterConfig[selectedBotName], (key, index) => {

            if (this.filterConfig[selectedBotName][key] == false) {

                $(`[catalogue='${key}']`).addClass('false')

                filtered = filtered.filter(item => {
                    let check = JSON.parse(item.personality).Device.userAgent.includes(key);
                    if (check) { return false } else { return true }
                })
            }

        });

        if (this.botList != "active") {

            this.filteredList = filtered.sort((a, b) => a.fullname.localeCompare(b.fullname)); // sort the array by names
            this.renderEngine.listBotTable(this.filteredList);
            await this.renderEngine.renderPagination(this.filteredList);
            this.countDevices(this.filteredList, false)
        } else {

            this.renderEngine.listBotTable(this.botStatus.runningBots);
            await this.renderEngine.renderPagination(this.botStatus.runningBots);
            this.countDevices(this.botStatus.runningBots, false)

        }


    }


    async setupFilter() {
        await this.filterBotName().then((names) => {

            names.forEach(item => {

                $("#botFamily").append(`<option value="${item}" > ${item} </option>`)
                this.filterConfig[item] = {
                    iPhone: true,
                    Android: true,
                    Windows: true,
                    Mac: true
                }
            })

        })

        // now the option has been loaded, now count the devices and display them.
        // lets listen to the devices
        $("#botFamily").change(() => {
            $("#discipline").remove();
            this.renderEngine.currentPage = 1; //reset the page so it doesnt disturb our new selection
            $(".filterOs").removeClass("false")
            this.renderFilter();
        })

    }

    filterBotName() {
        // this function would filter the names of the personalities
        // it will remove the 001,002,003... and push all the names into an array and then 
        // remake a new array with only unique names meaning repitition of names are not done on the new array
        // this unique names array would then saved in the filterConfig object followed by the allowed operatinng systems
        let rawData = [...this.botStatus.offBots];

        // Use a Set to store unique names
        let uniqueNamesSet = new Set();

        // Regular expression to match the numeric suffix
        const regex = /-\d+$/;

        // Iterate over rawData to extract and clean names
        rawData.forEach(item => {
            const cleanName = item.fullname.replace(regex, ""); // Remove the numeric suffix
            uniqueNamesSet.add(cleanName); // Add to the set, which keeps only unique values
        });

        // Convert the set back to an array
        let uniqueNames = Array.from(uniqueNamesSet);

        return Promise.resolve(uniqueNames)
    }

    async init() {
        await this.loadData();
        await this.updateStatusBots(false)
        this.botList == "inActive" ? this.render(this.botStatus.offBots) : this.render(this.botStatus.runningBots)
        await this.setupFilter()

        let executables = [];

        // load the executables
        await $.post(`https://okecbot.com/api/index.php?key=${this.apiKey}&showActivities`).then(async function (data) {

            $("#execute-container").append(`<select category="secondary" class="custom-select mt-3" id="executable" ></select>`);
            // lets make a select option for it
            data["json"].forEach((element, index) => {
                $("#executables").append(`<option value="${index}" > ${element.title} </option>`)
            });

            // update executable
            executables = data["json"];


        })

        this.executables = executables;

        $("#loadingData").modal('hide');

        await this.setProxyChain(); // load the proxyChain

    }

    async loadData() {
        return new Promise(async (resolve) => {
            this.apiKey = (await $.get("login/key.json")).apiKey;
            try {
                let response = await $.ajax({ url: `https://okecbot.com/api/index.php?key=${this.apiKey}&request=personality`, method: "GET", dataType: "json" });
                this.personalities = response;
                resolve();

            } catch (error) {
                console.error("Error loading data:", error);
            }
        });
    }


    countDevices(filtered, target) {
        let deviceCounts = { iPhone: 0, Android: 0, Windows: 0, Mac: 0 };


        filtered.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                deviceCounts.iPhone++;
            } else if (userAgent.includes("Android")) {
                deviceCounts.Android++;
            }
            else if (userAgent.includes("Win")) {
                deviceCounts.Windows++;

            } else if (userAgent.includes("Mac")) {
                deviceCounts.Mac++;
            }
        });

        let sum = Object.values(deviceCounts).reduce((a, b) => a + b);

        if (target == undefined) {
            $('#iphoneCount').text(deviceCounts.iPhone)
            $('#androidCount').text(deviceCounts.Android)
            $('#winCount').text(deviceCounts.Windows)
            $('#macCount').text(deviceCounts.Mac)
            $('#activeBrowsers').text(sum)
        } else {
            $('#filteredIphoneCount').text(deviceCounts.iPhone)
            $('#filteredAndroidCount').text(deviceCounts.Android)
            $('#filteredWinCount').text(deviceCounts.Windows)
            $('#filteredMacCount').text(deviceCounts.Mac)
        }
    }

    classifyDevices() {
        let devices = { iphone: [], android: [], windows: [], mac: [] };

        this.filteredList.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                devices.iphone.push(item.personality);
            } else if (userAgent.includes("Android")) {
                devices.android.push(item.personality);
            } else if (userAgent.includes("Win")) {
                devices.windows.push(item.personality);
            } else if (userAgent.includes("Mac")) {
                devices.mac.push(item.personality);
            }


        });

        return devices;


    }

    async updateStatusBots(loader = true) {
        if (loader) {
            $("#loadingData").modal("show");
        }
        return new Promise(async resolve => {
            let fullData = [...this.personalities];
            let fileNames = fullData.map(value => value.fullname);
            let on = [];
            let off = [];

            for (let i = 0; i < fileNames.length; i++) {
                try {
                    const response = await $.ajax({
                        url: `http://localhost:3000/isRunning`,
                        method: "POST",
                        dataType: "json",
                        contentType: 'application/json',
                        data: JSON.stringify({ botName: fileNames[i] }),
                    });

                    if (response.status === 'running') {
                        on.push(fullData[i]);
                    } else {
                        off.push(fullData[i]);
                    }
                } catch (error) {
                    console.error('Error checking if the bot file is running:', error);
                }

            }

            this.botStatus.runningBots = [...on];
            this.botStatus.offBots = [...off];
            // hide loading Modal
            if (loader) {
                await this.sleep(1000); // some fast computers might load this fast in less than a sec making loader hang
                $("#loadingData").modal("hide");
            }
            resolve();
        });
    }

    async render(filtered) {

        return new Promise(async (resolve) => {


            await this.updateStatusBots(false);
            this.renderEngine.listBotTable(filtered);

            await this.renderEngine.renderPagination(filtered);
            this.countDevices(filtered)
            this.renderFilter();
            resolve();
        })
    }



}