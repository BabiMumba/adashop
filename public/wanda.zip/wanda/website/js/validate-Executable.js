/*
    This class would be use to validate the input provided by the user and send back response to the user.
    We would validate everything from a valid url to dataTypes entered vs what is expected
*/

export class validateExecutable {

    constructor(renderExecutable) {
        console.log("validateExecutable class created")
        this.renderExecManager = renderExecutable;
    }

    async validate(obj) {

        let received = { ...obj };

        // block to validate the provided object before saending it to the server
        if (this.validate_Duration(received) !== true) {
            this.renderExecManager.executableManager.renderEngine.popInfo({
                title: "Invalid Task",
                message: `${this.validate_Duration(received)}`
            })
            return false;
        } else if (this.validate_URL(received) !== true) {
            this.renderExecManager.executableManager.renderEngine.popInfo({
                title: "Invalid Task",
                message: `${this.validate_URL(received)}`
            })
            return false;
        }
        else {

            // now package and send to okecbot server for final validation
            received["mission"] = "validate-input";
            //sending the data received! so as to know if it has been validated or
            let inputFeedback = await $.ajax({
                url: `http://localhost:3000/controller`,
                method: "POST",
                dataType: "json",
                contentType: 'application/json',
                data: JSON.stringify(received),
            });

            if (inputFeedback.status == false) {
                this.renderExecManager.executableManager.renderEngine.popInfo({
                    title: "Validation Failed",
                    message: `${inputFeedback.message}`
                })
                return false;
            } else {
                return true;
            }

        }


    }

    return_Not_Mission(obj) {
        let data = { ...obj };

        if (data.hasOwnProperty("mission")) {
            //This means the obj has mission key in it lets remove it

            delete data["mission"]
        }

        //  we would return an array the first key is the object, the second key is the 

        return [{ ...data }, Object.keys(data)];

    }


    tobeValidated(obj) {
        let missionLess = this.return_Not_Mission(obj)
        let object = missionLess[0];
        let objKey = missionLess[1];
        return object[objKey];
    }


    validate_Duration(obj) {
        // This method would validate the minimum - maximum seconds entered by the user
        // The method would scan the object for both the primary and secondary insearch for a key called duration
        // This key value which is expected to be a string is then converted into an array whose values are index 0: minimum seconds, index 1: maximum



        let primary = this.tobeValidated(obj).requirement;
        let secondary = this.tobeValidated(obj).secondary;

        // lets scan this for the duration key
        if (primary && primary["duration"]) {
            let duration = primary["duration"]
            // convert the string into the array
            let [min, max] = this.renderExecManager.extractNumbersFromString(duration)

            // lets check if the min is less than max
            console.log("p min ", min, "p max ", max)
            if ((typeof min == "undefined") || (typeof max == "undefined") || (typeof min == undefined) || (typeof max == undefined)) { return "Invalid minimum or maximum input. Only whole numbers are allowed. Kindly fix the time range on the primary task and try again" }
            if (min >= max) { return "Invalid time range. Inputted minimum seconds must be less than the maximum seconds. kindly fix the time range on the primary task and try again" }
        }

        if (secondary && secondary["duration"] ) {
            let duration = secondary["duration"]
            // convert the string into the array
            let [min, max] = this.renderExecManager.extractNumbersFromString(duration)

            // lets check if the min is less than max
            console.log("s min ", min, "s max ", typeof (max))
            if ((typeof min == "undefined") || (typeof max == "undefined") || (typeof min == undefined) || (typeof max == undefined)) { return "Invalid minimum or maximum input. Only whole numbers are allowed. Kindly fix  the time range on the secondary task and try again" }
            if (min >= max) { return "Invalid time range. Inputted minimum seconds must be less than the maximum seconds. kindly fix the time range on the secondary task and try again" }
        }



        return true;
    }

    validate_URL(obj) {
        // This method would check the url provided to make sure the user doesnt submit a url that is not https
        //This method would scan both the primary and secondary task in search of the url key

        let primary = this.tobeValidated(obj).requirement;
        let secondary = this.tobeValidated(obj).secondary;

        if (primary["url"]) {
            let url = primary["url"]

            // regex pattern to match a valid https url
            let check = /^https:\/\//.test(url);

            // lets check if the min is less than max
            if (!check) { return "Invalid URL. The link is not https. Only valid https links are allowed. Kindly fix url on the primary task  and try again" }
        }


        if ( secondary && secondary["url"]) {
            let url = secondary["url"]

            // regex pattern to match a valid https url
            let check = /^https:\/\//.test(url);

            // lets check if the min is less than max
            if (!check) { return "Invalid URL. The link is not https. Only valid https links are allowed. Kindly fix url on the secondary task  and try again" }
        }

        return true;
    }



}