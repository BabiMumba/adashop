import { botManager } from './botManager.js';
import { renderExecutable } from './render-Executable.js';
/*

    This class would be used on the create executable page to assit users in making executable activities.
    This class would validate the inputs and also make the necessary calls to the server to create the executable activities.
    This class would also be responsible for rendering the data on the page.

*/

export class executableManager {

    constructor() {
        this.executableHistory = new renderExecutable(this);
        this.apiKey = null;
        this.serverProcessTxt = '<div class="p-3 text-center"> Processing your request with okecbot servers... <img src="images/loading.gif" /> </div>';

        // botManaging tools
        this.botEngine = new botManager(false);
        this.renderEngine = this.botEngine.renderEngine;

        // Executable capabilities and tools
        this.toolPack = [];

        // activity history
        this.serverExecutables = [];

        this.secondaryTask = [];
        // render Executable

        this.main();

        this.secIndex = null;
    }

    async main() {
        this.apiKey = (await $.get("login/key.json")).apiKey;
        this.toolIcons = await $.getJSON("component/json/icons.json");
        this.control_Button();
        await this.loadToolPack();
        await this.update_Tool_Box_Img();
        this.load_Primary_Actions();
        this.load_Primary_Inputs();
        this.load_Secondary_Input();
        await this.reListen();
        this.executableHistory.relisten();
    }

    async update_Tool_Box_Img() {

        // we check the tool pack active and then state the image
        let toolPack = $("#tool-box").val();
        let imgSrc = await this.toolIcons[toolPack];
        $("#tool-box-img").attr("src", imgSrc);
    }

    async reListen() {
        /*
            This method would be use to unset all event listeners and re-listen to the events. 
            This is because new items might have been added to tbe dom.
        */
        let self = this;

        await self.update_Tool_Box_Img(); // sync Image of tool box 

        await $("#tool-box").off("change").on("change", async function () {



            // we also need to render the tools for the selected tool pack
            self.load_Primary_Actions();
            self.load_Primary_Inputs();
            self.load_Secondary_Input();

            self.update_Tool_Box_Img(); // sync Image of tool box 

            // relisten to the new inputs on the history side
            self.executableHistory.relisten();
            self.secondaryTask = [];
            $("#taskHistory").remove();

        })

        await $("#tool-action").off("change").on("change", async function () {
            self.load_Primary_Inputs();
            self.load_Secondary_Input();

            // relisten to the new inputs on the history side
            self.executableHistory.relisten();

        })
    }

    async render_Secondary_Task() {
        let self = this;

        $("#taskDetails").hide()
        $("#taskHistory").remove();

        //populate and append the task history
        $("#secondary-action").append(`
            <div id="taskHistory" style="max-height: 350px; overflow-y: scroll;" class=" text-white" >
                    
            </div>
            `)

        // loop through and generate the log of task
        let indx = 0;
        for (let object of self.secondaryTask) {
            let memo = "";

            for (let key in object) {
                memo += `<div class="mb-2 wrap-my-text">  <span class=" p-1 bg-secondary"> ${key}   </span> : <span > ${object[key]} </span> </div>`;

            }

            $("#taskHistory").append(`
                <div id="task${indx}" index="${indx}" class="bg-light text-dark taskBox border border-secondary mt-3">

                    <h6 class=" p-2"> <img style="width:25px;" index="${indx}" class="deleteSec" src="images/delete-bot2.png" /> ${object.task} </h6> <hr>
                    <ul class=" small"> 
                        ${memo}
                    </ul>
                </div>
                `)


            indx += 1;
        }

        $(".deleteSec").off("click").on("click", async function () {
            let indx = $(this).attr("index")
            // remove from the array 
            self.secondaryTask.splice(indx, 1)
            $(`#task${indx}`).remove();
        })


        $(".taskBox").off("click").on("click", function () {
            // Remove the class 'bg-secondary' from all elements with the 'taskBox' class
            $(".taskBox").removeClass("bg-dark");
            $(".taskBox").removeClass("text-white");
            $(".taskBox").addClass("text-dark");
            $(".taskBox").addClass("bg-light");

            // Add the class 'bg-secondary' to the clicked element
            $(this).addClass("bg-dark");
            $(this).removeClass("bg-light")
            $(this).addClass("text-white");
            $(this).removeClass("text-dark");
        });

        $(".taskBox").off("dblclick").on("dblclick", async function () {
            let indx = $(this).attr("index");
            // Remove from the array
            // self.secondaryTask.splice(indx, 1);
            // $(`#task${indx}`).remove();

            let toInput = self.secondaryTask[indx];
            let done = await $("#secondary-tools").val(toInput.task).change()

            //run loop and set the input to what are on the data
            for (let object of Object.keys(toInput)) {

                if (object != "duration" && object != "task") {
                    let ele = `.tool-input[category="secondary"][name="${object}"]`
                    let elem = await self.executableHistory.waitForElement(ele)
                    console.log("elem:", elem)
                    await $(elem).val(toInput[object])
                }
            }

            //set it for edit mode and change the display

            self.secIndex = indx;
            $("#preview").click()
        });

    }

    control_Button() {
        /*
         Control button class on this system is used to convert any dom element into an action trigger.
         When a dom element with control button class is clicked that element is reviewed and an action is taken.
         */

        let self = this;

        $(".controlBtn").off("click").on("click", async function () {
            let task = $(this).attr("category");
            let query = $(this).attr("name");
            let apiKey = self.apiKey;

            switch (task) {
                case "saveChain":
                    self.renderEngine.popInfo({
                        title: "Save chain of actions as an executable",
                        message: `
                        <div id="saveActDiv" class="d-flex justify-content-between" > 
                            <input id="activityName" type="text" class="form-control w-75 " placeholder="Executable Name">
                            <button id="saveActivity" category="saveActivity" class="bg-secondary btn controlBtn text-white" > Save </button>
                        </div> `
                    })
                    self.control_Button();
                    break;

                case "saveActivity":

                    let executableName = $("#activityName").val();
                    let executableHistory = self.executableHistory.executableHistory;
                    //Store the data on okecbot server
                    $('#buildLogMsg').html(self.serverProcessTxt);
                    await $.ajax({
                        method: "POST",
                        url: `https://okecbot.com/api/index.php?key=${apiKey}&addActivity&activityTitle=${executableName}`,
                        data: JSON.stringify(executableHistory),
                        contentType: "application/json",
                        dataType: "json",
                        success: function (response) {
                            if (response.status == "success") {

                                let template = `   <div class="p-3 text-center">  Successfully saved your activities on okecbot server. </br>
                                                        <img src="images/success.gif" />
                                                    </div> 
                                                `;


                                // lets update the success message 
                                $('#buildLogMsg').html(template);

                            }
                             else {

                                let template = `
                                                <div class="p-3 text-center">
                                                    Error .! couldn's save the activity to okecbot servere:: ${response.body}
                                                    </br>
                                                    <img src="images/failed.gif" />
                                                </div>
                                            `;


                                // lets update the failure message 
                                $('#buildLogMsg').html(template);

                            }
                        },
                        error: function (error) {
                            console.log(" Couldnt send ! ")
                        }
                    });

                    self.control_Button();
                    break;

                case "edit-executable":
                    // we would use the render for this
                    let editExec = JSON.parse(self.serverExecutables[query]["data"]);
                    // overwrite the executableHistory object
                    self.executableHistory.executableHistory = editExec;
                    console.log(" The server exec", editExec)
                    //relisten and render the updated executables
                    self.executableHistory.relisten();

                    //change the icon(img src) into something to show it is been worked on
                    $(this).attr("src", "images/editMode.gif")

                    // now lets relisten the control button
                    self.control_Button();
                    break;

                case "viewChains":
                    $('#buildLog').modal('show');
                    $('#buildLogMsg').html(self.serverProcessTxt);
                    // query okecbot and get the saved activities
                    await $.ajax({
                        method: "POST",
                        url: `https://okecbot.com/api/index.php?key=${apiKey}&showActivities`,
                        contentType: "application/json",
                        dataType: "json",
                        success: function (response) {
                            if (response.status == "success") {

                                let records = response.json;
                                let memo = "";

                                //save it in memory here
                                self.serverExecutables = records;
                                console.log("server executables saved in memory")

                                records.forEach((element, index) => {
                                    memo += ` <tr> <td> <img category="edit-executable" name="${index}" class="controlBtn cursor" width="35" src="images/edit-icon.png" /> </td> <td> ${element.title} </td> <td> ${element.created} </td> <td> ${element.execution_count} </td> <td> <img width="20" class="controlBtn cursor" category="deleteChain" name="${element.title}" src="images/delete.png" /> </td> </tr> `;
                                });

                                self.renderEngine.popInfo({
                                    title: "Saved chained activities",
                                    message: `
                                            <div class="p-3 w-100 text-center">

                                                <table  class="table table-striped mx-auto bg-light ">
                                                    <thead class="thead-dark">
                                                        <tr>
                                                            <th>  </th>
                                                            <th> Executable Name </th>
                                                            <th> Created </th>
                                                            <th> Execution count </th>
                                                            <th>  </th>
                                                        </tr>
                                                    </thead>
                                                    ${memo}

                                                </table>

                                            </div>
                                    `
                                })

                            } else {
                                self.renderEngine.popInfo({
                                    title: "loading activities failed!",
                                    message: `

                                            <div class="p-3 text-center">

                                                Error .! couldn's load the activity on okecbot server, error code:: ${response.error}
                                                </br>
                                                <img src="images/failed.gif" />

                                            </div>

                                            `})


                            }
                        },
                        error: function (error) {
                            console.log(" Couldnt send ! ")
                        }
                    });

                    self.control_Button();
                    break;
                case "deleteChain":
                    // lets send the title of the chain to the server so it deletes it
                    $('#buildLogMsg').html(self.serverProcessTxt);
                    // query okecbot and get the saved activities
                    await $.ajax({
                        method: "POST",
                        url: `https://okecbot.com/api/index.php?key=${apiKey}&deleteActivity&activityTitle=${query}`,
                        contentType: "application/json",
                        dataType: "json",
                        success: function (response) {
                            if (response.status == "success") {

                                self.renderEngine.popInfo({
                                    title: "Deleted",
                                    message: `
                                            <div class="p-3 w-100 text-center">

                                                <p> The activity chain was deleted suucessffully </p>
                                                <p> <img src="images/success.gif" /> </p>

                                            </div>
                                    `
                                })

                            } else {
                                self.renderEngine.popInfo({
                                    title: "loading activities failed!",
                                    message: `

                                            <div class="p-3 text-center">

                                                Error .! couldn's delete the activity on okecbot server:: ${response.error}
                                                </br>
                                                <img src="images/failed.gif" />

                                            </div>

                                            `})


                            }
                        },
                        error: function (error) {
                            console.log(" Couldnt send ! ")
                        }
                    });
                    self.control_Button();
                    break;

                case "preview":
                    // we would use the eyes icon to trak if the history is to be showed or not
                    let eyes = $(this).attr("mode");
                    if (eyes == "hide") {
                        // This means the preview for this task in building isnt visible

                        $("#taskDetails").hide()

                        await self.render_Secondary_Task();

                        // Now we have hidden the others change the mode
                        $(this).attr("mode", "show");
                    } else {
                        $("#taskHistory").remove();
                        $("#taskDetails").show()

                        // Now we have shown the others change the mode
                        $(this).attr("mode", "hide");
                    }
                    break;


                case "addSecondary":
                    let inValidated = []; // to track invalid inputs after running validations on them
                    //get the tool
                    let control = {}
                    let currentToolBox = await $("#tool-box").val()
                    let currentPrimaryTool = await $("#tool-action").val()
                    let currentSecTool = await $("#secondary-tools").val()

                    let expectedInput = self.toolPack[currentToolBox][currentPrimaryTool]["secondary"][currentSecTool];
                    if (expectedInput) {
                        //lets check if all details are been submitted
                        for (let input of Object.keys(expectedInput)) {
                            let providedInput = $(`.control-info[name='${input}'][category='secondary']`).val()

                            if (providedInput.length < 1) {
                                self.renderEngine.popInfo({
                                    title: "Error on secondary task",
                                    message: `
                                    <div  class="d-flex text-danger justify-content-between" > 
                                        Incomplete task data. You are yet to fill in ::: ${input}                                
                                    </div> `
                                })

                                inValidated.push([input, providedInput])
                                break
                            }

                            // validate url and time durations
                            if (input == "duration") {
                                let test = self.executableHistory.validateExecutable.validate_Duration({ "0": { "secondary": { "duration": providedInput } } });

                                if (test !== true) {
                                    self.renderEngine.popInfo({
                                        title: "Error on secondary task",
                                        message: `
                                        <div  class="d-flex text-danger justify-content-between" > 
                                            ${test}                                
                                        </div> `
                                    })

                                    inValidated.push([input, providedInput])
                                    break
                                }
                            }

                            control[input] = providedInput;

                        }
                    }

                    if (inValidated.length < 1 && Object.keys(control).length > 0) {
                        // This means there was no issues so add to secondTask
                        control["task"] = currentSecTool;
                        if (self.secIndex == null) {
                            self.secondaryTask.push(control)
                        } else {
                            self.secondaryTask[self.secIndex] = control;
                        }

                        console.log("Secondary is ", self.secondaryTask)

                        //trigger change so as to reset the input
                        await $("#secondary-tools").change();
                        $("#preview").click()
                    }


                    break;

                case "primary-action":
                    // let us make sure the right button is visible and the right div too!.
                    $("#action").attr("category", "secondary-action");
                    $("#action").attr("src", "images/secondary-action.png")
                    $("#secondary-action").show()
                    $("#primary-action").hide()
                    $(this).attr("mode", "hide");
                    self.control_Button();
                    break;
                case "secondary-action":
                    // let us make sure the right button is visible and the right div too!.
                    $("#action").attr("category", "primary-action");
                    $("#action").attr("src", "images/primary-action.png")
                    $("#primary-action").show()
                    $("#secondary-action").hide()
                    $(this).attr("mode", "hide");
                    self.control_Button();
                    break;
                default:
                    self.control_Button();
                    break;
            }
        })

    }

    async loadToolPack() {
        /*
            This tool renders the tool pack on the page. 
            With this tool pack, the user can select the tools to be used in the executable activity.
        */

        let self = this;

        await $.ajax({
            method: "POST",
            url: `controller`,
            data: JSON.stringify({ mission: "controls-info" }),
            contentType: "application/json",
            dataType: "json",
            success: async function (response) {
                self.toolPack = response;
            }
        });

        // loop through and append the tools to the toll box selection
        for (let key of Object.keys(self.toolPack)) {
            //append the tools to the selectio so users can select of it.
            $('#tool-box').append(`<option value="${key}" > ${key} tools </option> `);
        }

        return "done";

    }

    async load_Primary_Actions() {

        let self = this;

        let tool = await $('#tool-box').val()
        tool = self.toolPack[tool];
        $('#tool-action').empty();
        for (let key of Object.keys(tool)) {
            //append the tools to the selectio so users can select of it.
            $('#tool-action').append(`<option value="${key}" > ${tool[key].name}  </option> `);
        }
    }

    async load_Primary_Inputs() {

        let self = this;

        $("#primary-req").empty();
        let tool = await $('#tool-box').val();
        let toolAction = await $('#tool-action').val()
        let inputs = self.toolPack[tool][toolAction].requirement;

        for (let key of Object.keys(inputs)) {
            let prop = key;
            let dataType = inputs[key];

            $('#primary-req').append(self.return_Input(dataType, prop, "primary"));
        }
    }

    return_Input(dataType, prop, category) {

        switch (dataType[0]) {
            case "input":
                return ` 
                
                <div class="input-group mb-3">
                    <div class="input-group-append">
                    <span class="input-group-text">${prop}</span>
                    </div>
                    <input category="${category}" name="${prop}" type="text" class="form-control tool-input control-info" placeholder="${dataType[1]}">
                </div>`

                break;
            case "selector":

                setTimeout(function () {

                    $(`#addXpath`).off("click").on("click", function () {
                        let currentXpath = $(`#currentXpath`).val().trim();
                        if (currentXpath.length < 1) { return 0; }
                        $("#xpathList").append(`<small> <li class="xpath" style="word-wrap: break-word; margin-bottom:15px;" >${currentXpath}</li> </small> `);

                        // add it to the dummy div kept aside for this 
                        let fmtXpath = `"${currentXpath}",`;
                        $("#mainXpath").val(`${$("#mainXpath").val()}${fmtXpath}`.trim());
                        $(`#currentXpath`).val("");
                    })

                }, 3000)

                return `
                <div class="border mt-3 mb-3 p-3 border-secondary" >
                    <h6 class="text-center"> ${dataType[1]} </h6>
                        <div class="input-group mb-3">
                        <textarea id="currentXpath" rows="2"  type="text" class="form-control " placeholder="${dataType[1]}"> </textarea>
                        <textarea id="mainXpath" rows="2" category="${category}" name="${prop}" type="text" class="form-control d-none tool-input control-info" placeholder="${dataType[1]}"> </textarea>
                        <div class="input-group-append">
                            <button id="addXpath" class="input-group-text btn bg-success text-light"> [+] xpath </button>
                        </div>
                    </div>
                    <ol  id="xpathList" class="d-flex flex-column justify-content-around">                       
                
                    </ol>
                </div>
                `

                break;
            case "time":

                setTimeout(function () {

                    $(`#${category}_${prop}_min`).off("change").on("change", function () {
                        let minVal = $(`#${category}_${prop}_min`).val();
                        let maxVal = $(`#${category}_${prop}_max`).val();

                        // console log the response

                        let duration = ` '${minVal}' to '${maxVal}' seconds`;
                        console.log(duration)

                        $(`#${category}_${prop}_main`).val(duration);
                    })

                    $(`#${category}_${prop}_max`).off("change").on("change", function () {
                        let minVal = $(`#${category}_${prop}_min`).val();
                        let maxVal = $(`#${category}_${prop}_max`).val();

                        // console log the response

                        let duration = ` '${minVal}' to '${maxVal}' seconds`;
                        console.log(duration)

                        $(`#${category}_${prop}_main`).val(duration);
                    })
                }, 3000)

                return `
                <div class="border mt-3 mb-3 pt-3 border-secondary" >

                    <center> <img src="images/clock.png" /> </center>
                    <hr>
                    <h6 class="text-center"> <small> ${dataType[1]} </small> </h6>
                    <ul class="d-flex justify-content-around"> 
                       <input style="width:75px;" id="${category}_${prop}_min" min="1" max="35999" placeholder="Min" class="ask-input text-center " type="number" pattern="\d+" title="Only numbers are allowed" >                    
                       <input style="width:75px;" id="${category}_${prop}_max" min="2" max="36000" placeholder="Max" class="ask-input text-center" type="number" pattern="\d+" title="Only numbers are allowed" >                       
                       <input style="width:75px;" id="${category}_${prop}_main" category="${category}" class="ask-input  text-center d-none tool-input control-info" type="text"  name="${prop}">                       
                        
                    </ul>
                </div>
                `

                break;
            case "ask":
                return `
                <div class="border mt-3 mb-3 pt-3 border-secondary" >
                    
                    <h6 class="text-center"> <small> ${dataType[1]} </small> </h6>
                    <ul> 
                        <li> <input category="${category}" class="ask-input tool-input control-info" type="text"  name="${prop}">  </li>                      
                        
                    </ul>
                </div>
                `;
                break;
            case "option":
                return `
                <div style="background:#093963; color:#fff;" class="border mt-3 mb-3 pt-3 border-secondary" >
                    
                    <h6 class="text-center"> <small> ${dataType[1]} </small> </h6>
                    <select category="${category}" name="${prop}" class="form-control tool-input control-info">               
                        <option  value="no"> NO: do not ${prop} </option> 
                        <option  value="yes"> YES: ${prop} </option>                                 
                    </select>
                </div>
                `;
                break;

            case "gpt":
                return `  <div class="d-flex justify-content-between">
                                <label class="my-auto" for="txt-${prop}"> <img src="images/gpt.png" /> </label>
                                <textarea placeholder="${dataType[1]}" category="${category}" class="form-control tool-input control-info" name="${prop}" id="txt-${prop}" rows="4"></textarea>
                        </div>`;
                break
            case "textarea":
                return `  <div class="d-flex justify-content-between">
                                <label class="" for="txt-${prop}"> <img width="100" src="images/typein.png" />  </label>
                                <textarea placeholder="${dataType[1]}"  category="${category}" class="form-control tool-input control-info" name="${prop}" id="txt-${prop}" rows="4"></textarea>
                        </div>`;
                break
            // You can have any number of case statements
            default:
            // Code to execute if expression doesn't match any case
        }


    }


    async render_Secondary_Input() {
        let self = this;


        $("#secondary-req").empty();
        let tool = await $('#tool-box').val();
        let toolAction = await $('#tool-action').val()
        let secondTool = await $('#secondary-tools').val()
        let object = self.toolPack[tool][toolAction].secondary[secondTool];
        if (typeof (object) != "object") return

        for (let key of Object.keys(object)) {
            let prop = key;
            let dataType = object[key];
            $('#secondary-req').append(self.return_Input(dataType, prop, "secondary"));
        }
    }

    async load_Secondary_Input() {
        let self = this;

        $("#secondary-req").empty();
        $("#secondary-tools").empty();
        let tool = await $('#tool-box').val();
        let toolAction = await $('#tool-action').val()
        let inputs = self.toolPack[tool][toolAction].secondary;

        for (let key of Object.keys(inputs)) {
            let prop = key;
            let dataType = inputs[key];
            // Now lets add this into a selector
            $('#secondary-tools').append(`<option value="${prop}">${prop}</option>`);
        }

        this.render_Secondary_Input()

    }

}