import { renderData } from './tableRender.js';
export class botAi {

    // This class would handle the random execution

    constructor() {
        console.log(" Random launcher initiated ;")
        // Initialize state variables
        this.botList = "inActive";
        this.botStatus = {
            runningBots: ['notUpdated'],
            offBots: ['notUpdated']
        };
        this.apiKey = null;
        this.personalities = 'notLoaded';
        this.executables = 'notLoaded';

        // renderEngine
        this.renderEngine = new renderData({
            currentPage: 1,
            itemsPerPage: 12,
            botEngine: this
        });

        this.isPaid = false;

        this.filterConfig = {};
        this.filteredList = null;
        this.checkedList = [];

        this.randomEngine = "off";

        // initaite this object,load the necessary data
        this.init()


    }

    async upgradePopup(){
        // This method is used to prompt a user to upgrade there APIkey access so as to gain access tot this feature

        let Okectimer = 9;

            let timeInt = setInterval(() => {

                let timer = document.getElementById("timer");
                timer.innerHTML = Okectimer;
                // reduce the timer by 1;
                --Okectimer;

                if (Okectimer < 0) {
                    clearInterval(timeInt)
                }

            }, 1000)

            $("#error_Msg").html(`
                    contact okecbot customer support to
                    unlock this feature where bots are randomly launched and assigned a random task for execution.
                     `)

            $("#popError").css("display", "flex")
            await this.sleep(10000);
            $("#popError").css("display", "none")

    }

    isRange(min, max) {
        // Check if min and max are both numbers
        if (typeof min !== 'number' || typeof max !== 'number') {
            return false;
        }

        // Check if min and max are both integers or floats
        if (!Number.isInteger(min) || !Number.isInteger(max)) {
            return false;
        }

        // Check if min is less than max
        return min < max;
    }

    async pickRandomDevice(number_of_picks, deviceBrand) {
        // This method returns a number of switched off devices from a device brand in an array

        // create a new set to store unique devices
        let devices = new Set();

        while (devices.size < number_of_picks) {

            let generatedDevice = deviceBrand[this.getRandomInt(1, (deviceBrand.length - 1))];
            let deviceName = JSON.parse(generatedDevice).Account.fullname;

            // check if the device generated is not on the list of running bots, and add it else ignore
            if (this.botStatus.runningBots.includes(deviceName)) {
                // The bot generated is already running so we would look away 
            } else {
                // The bot generated is offline so we can switch it on

                devices.add(generatedDevice);
            }

        }

        return [...devices];
    }

    pickRandomTask(number_of_picks, executableChain) {
        // This method returns a number of randomly picked task in an array

        // create an array to store random task
        let task = [];

        while (task.length < number_of_picks) {


            let generatedTask = executableChain[(Object.keys(executableChain)[this.getRandomInt(1, (Object.keys(executableChain).length - 1))])]

            // add the task to the array

            task.push(generatedTask)

        }

        return [...task];
    }

    isAllNum(array) {
        // Loop through each element of the array
        for (let i = 0; i < array.length; i++) {
            // Check if the element is not a positive integer
            if (!(/^\d+$/.test(array[i])) || parseInt(array[i]) <= 0) {
                return false; // If it's not a positive integer, return false
            }
        }
        // If all elements are positive integers, return true
        return true;
    }

    async depatchTask(botName, botTask, timeBeforeTask) {
        // This method would assign task to the bot

        await this.sleep(timeBeforeTask)

        await $.ajax({
            url: `http://localhost:3000/execute_botName`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify({
                botName: botName, action: "task", compliment_data: {
                    task: botTask
                }
            }),
        });

        return "task dispatched";

    }



    renderClickable() {
        // This method renders the urls in the executable and provides a user with option to sent number of clicks


        var executableChain = JSON.parse(this.executables[$("#executables").val()].data);
        $("#adsClick").empty(); // clear previous first

        let index = 1;

        for (let items in executableChain) {
            let url = executableChain[items]["browser"]["requirement"]["url"];

            // render the list
            let li = `
                        <tr>
                        <td scope="row">
                            <div class="my-5"> ${url} </div>
                        </td>
                        <td> <input type="number" class="clicksTobe my-5 form-control w-50" style="display: inline;"
                                min="0" max="1000">
                            << clicks </td>
                        <td>
                            <ul>
                                <li><input type="radio" name="ad${index}" id="cb1_${index}" />
                                    <label for="cb1_${index}"><img style="height: 100px;"
                                            src="images/adsense2.jpeg" /></label>
                                </li>
                                <li><input type="radio" name="ad${index}" id="cb2_${index}" />
                                    <label for="cb2_${index}"><img src="images/adsterra.jpeg" /></label>
                                </li>
                                <li><input type="radio" name="ad${index}" id="cb3_${index}" />
                                    <label for="cb3_${index}"><img src="images/ezoic.png" /></label>
                                </li>
                            </ul>
                        </td>
                    </tr>
                    `;

            $("#adsClick").append(li)

            index++; //increment the index

        }
        let self = this;

        //relisten
        $(".clicksTobe").off("change").on("change", async function (evt) {

            let Okectimer = 9;

            let timeInt = setInterval(() => {

                let timer = document.getElementById("timer");
                timer.innerHTML = Okectimer;
                // reduce the timer by 1;
                --Okectimer;

                if (Okectimer < 0) {
                    clearInterval(timeInt)
                }

            }, 1000)

            $("#error_Msg").html(`<li><input type="radio" name="ad1" id="cb1_1" />
                        <label for="cb1_1"><img style="height: 100px;"
                                src="images/adsense2.jpeg" /></label>
                    </li>
                    <li><input type="radio" name="ad1" id="cb2_1" />
                        <label for="cb2_1"><img src="images/adsterra.jpeg" /></label>
                    </li>
                    <li><input type="radio" name="ad1" id="cb3_1" />
                        <label for="cb3_1"><img src="images/ezoic.png" /></label>
                    </li>
                    contact okecbot customer support to
                    unlock this feature of Automated Advertisement clicking for website powered by Google Adsense,
                    Ezoic and Adx. `)

            $("#popError").css("display", "flex")
            $(this).val("");
            await self.sleep(10000);
            $("#popError").css("display", "none")
        })
    }


    disableOff() {
        var engineStatus = this.randomEngine; // Assuming this.randomEngine holds the value of the engine status

        // Disable or enable inputs based on engine status
        if (engineStatus == "on") {
            $("#botFamily, #executables, #iphone_min_taskTime, #iphone_max_taskTime, #iphone_active_min, #iphone_active_max, #android_min_taskTime, #android_max_taskTime, #android_active_min, #android_active_max, #mac_min_taskTime, #mac_max_taskTime, #mac_active_min, #mac_active_max, #win_min_taskTime, #win_max_taskTime, #win_active_min, #win_active_max").prop('disabled', true);
        } else {
            $("#botFamily, #executables, #iphone_min_taskTime, #iphone_max_taskTime, #iphone_active_min, #iphone_active_max, #android_min_taskTime, #android_max_taskTime, #android_active_min, #android_active_max, #mac_min_taskTime, #mac_max_taskTime, #mac_active_min, #mac_active_max, #win_min_taskTime, #win_max_taskTime, #win_active_min, #win_active_max").prop('disabled', false);
        }
    }

    async shutDown_allBot() {
        let response = await $.ajax({ url: "http://localhost:3000/exitBots", method: "GET", dataType: "json" });
        return response;
    }

    async startEngine() {


        if (this.randomEngine == "off") { return "Engine has been shutDown" }

        if(this.isPaid == false) { await this.upgradePopup(); return; }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }


    getBotInfo(botName) {

        let personality = [];
        // run a lopp across the personality and return an object containing the details on personality
        this.personalities.forEach(function (item) {
            if (item.fullname == botName) {
                personality = item.personality
            }
        })

        return JSON.parse(personality).Device;
    }

    async renderFilter() {
        //console.log(" rendering table with the filter applied",this.filterConfig)
        // Get the selected option
        let selectedBotName = $("#botFamily").val();

        let rawData = [...this.botStatus.offBots];

        // Create a regular expression to match the selected bot name with any numeric suffix
        const regex = new RegExp(`^${selectedBotName}(-\\d+)?$`);

        // Filter rawData to include only items that match the regex
        let filtered = rawData.filter(item => regex.test(item.fullname));

        $.each(this.filterConfig[selectedBotName], (key, index) => {

            if (this.filterConfig[selectedBotName][key] == false) {

                $(`[catalogue='${key}']`).addClass('false')

                filtered = filtered.filter(item => {
                    let check = JSON.parse(item.personality).Device.userAgent.includes(key);
                    if (check) { return false } else { return true }
                })
            }

        });

        if (this.botList != "active") {

            this.filteredList = filtered.sort((a, b) => a.fullname.localeCompare(b.fullname)); // sort the array by names
            this.renderEngine.listBotTable(this.filteredList);
            await this.renderEngine.renderPagination(this.filteredList);
            this.countDevices(this.filteredList, false)
        } else {

            this.renderEngine.listBotTable(this.botStatus.runningBots);
            await this.renderEngine.renderPagination(this.botStatus.runningBots);
            this.countDevices(this.botStatus.runningBots, false)

        }


    }


    async setupFilter() {
        await this.filterBotName().then((names) => {

            names.forEach(item => {

                $("#botFamily").append(`<option value="${item}" > ${item} </option>`)
                this.filterConfig[item] = {
                    iPhone: true,
                    Android: true,
                    Windows: true,
                    Mac: true
                }
            })

        })

        // now the option has been loaded, now count the devices and display them.
        // lets listen to the devices
        $("#botFamily").change(() => {
            $("#discipline").remove();
            this.renderEngine.currentPage = 1; //reset the page so it doesnt disturb our new selection
            $(".filterOs").removeClass("false")
            this.renderFilter();
        })

    }

    filterBotName() {
        // this function would filter the names of the personalities
        // it will remove the 001,002,003... and push all the names into an array and then 
        // remake a new array with only unique names meaning repitition of names are not done on the new array
        // this unique names array would then saved in the filterConfig object followed by the allowed operatinng systems
        let rawData = [...this.botStatus.offBots];

        // Use a Set to store unique names
        let uniqueNamesSet = new Set();

        // Regular expression to match the numeric suffix
        const regex = /-\d+$/;

        // Iterate over rawData to extract and clean names
        rawData.forEach(item => {
            const cleanName = item.fullname.replace(regex, ""); // Remove the numeric suffix
            uniqueNamesSet.add(cleanName); // Add to the set, which keeps only unique values
        });

        // Convert the set back to an array
        let uniqueNames = Array.from(uniqueNamesSet);

        return Promise.resolve(uniqueNames)
    }

    async init() {
        await this.loadData();
        await this.updateStatusBots()
        this.botList == "inActive" ? this.render(this.botStatus.offBots) : this.render(this.botStatus.runningBots)
        await this.setupFilter()

        let executables = [];

        // load the executables
        await $.post(`https://okecbot.com/api/index.php?key=${this.apiKey}&showActivities`).then(async function (data) {

            $("#execute-container").append(`<select category="secondary" class="custom-select mt-3" id="executable" ></select>`);
            // lets make a select option for it
            data["json"].forEach((element, index) => {
                $("#executables").append(`<option value="${index}" > ${element.title} </option>`)
            });

            // update executable
            executables = data["json"];


        })

        this.executables = executables;

        $("#loadingData").modal('hide');

        //render the clickable

        this.renderClickable();

    }

    async loadData() {
        return new Promise(async (resolve) => {
            this.apiKey = (await $.get("login/key.json")).apiKey;
            try {
                let response = await $.ajax({ url: `http://localhost:3000/loadPersonality`, method: "GET", dataType: "json" });
                this.personalities = response;
                resolve();

            } catch (error) {
                console.error("Error loading data:", error);
            }
        });
    }


    countDevices(filtered, target) {
        let deviceCounts = { iPhone: 0, Android: 0, Windows: 0, Mac: 0 };


        filtered.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                deviceCounts.iPhone++;
            } else if (userAgent.includes("Android")) {
                deviceCounts.Android++;
            }
            else if (userAgent.includes("Win")) {
                deviceCounts.Windows++;

            } else if (userAgent.includes("Mac")) {
                deviceCounts.Mac++;
            }
        });

        let sum = Object.values(deviceCounts).reduce((a, b) => a + b);

        if (target == undefined) {
            $('#iphoneCount').text(deviceCounts.iPhone)
            $('#androidCount').text(deviceCounts.Android)
            $('#winCount').text(deviceCounts.Windows)
            $('#macCount').text(deviceCounts.Mac)
            $('#activeBrowsers').text(sum)
        } else {
            $('#filteredIphoneCount').text(deviceCounts.iPhone)
            $('#filteredAndroidCount').text(deviceCounts.Android)
            $('#filteredWinCount').text(deviceCounts.Windows)
            $('#filteredMacCount').text(deviceCounts.Mac)
        }
    }

    classifyDevices() {
        let devices = { iphone: [], android: [], windows: [], mac: [] };

        this.filteredList.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                devices.iphone.push(item.personality);
            } else if (userAgent.includes("Android")) {
                devices.android.push(item.personality);
            } else if (userAgent.includes("Win")) {
                devices.windows.push(item.personality);
            } else if (userAgent.includes("Mac")) {
                devices.mac.push(item.personality);
            }


        });

        return devices;


    }

    async updateStatusBots() {

        return new Promise(async resolve => {

            let fullData = [...this.personalities];
            let fileNames = fullData.map(value => value.fullname);
            let on = [];
            let off = [];

            // Use Promise.all() to wait for all AJAX requests to complete
            await Promise.all(fileNames.map(async (fName, index) => {
                try {
                    // Post the name to the isFilerunning endpoint to check if the fileName is currently running
                    const response = await $.ajax({
                        url: `http://localhost:3000/isRunning`,
                        method: "POST",
                        dataType: "json",
                        contentType: 'application/json',
                        data: JSON.stringify({ botName: fName }),
                    });

                    // Handle the response frotrm the server
                    if (response.status === 'running') {
                        on.push(fullData[index]);
                    } else {
                        off.push(fullData[index]);
                    }
                } catch (error) {
                    // Handle any errors that occur during the request
                    console.error('Error couldnt check if the bot file is running !:', error);
                }
            }));

            // Update statusBots after all requests are complete
            this.botStatus.runningBots = [...on];
            this.botStatus.offBots = [...off];

            resolve();

        });

    }

    async render(filtered) {

        return new Promise(async (resolve) => {


            await this.updateStatusBots();
            this.renderEngine.listBotTable(filtered);

            await this.renderEngine.renderPagination(filtered);
            this.countDevices(filtered)
            this.renderFilter();
            resolve();
        })
    }



}