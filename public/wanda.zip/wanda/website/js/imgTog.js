export class imgTog {

    // Constructor: Initializes the imgTog class.
    // - selector: jQuery selector for the image element.
    // - config: Optional initial configuration object.
    // The constructor sets up the initial image, configuration, and state.
    constructor(selector, config) {
        this.img = $(selector); // jQuery object for the image.
        this.config = []; // Array to hold different configurations.
        this.pos = 0; // Position index for toggling through configurations.
        this.memory = []; // Array to store additional data.

        // If a config object is provided, use it as the first configuration.
        // Otherwise, set up a default configuration.
        this.config[0] = config || {};
        this.config[0]["attr"] = this.returnAttr(); // Store the current image attributes.
    }

    // returnAttr: Retrieves the current attributes of the image.
    // Returns an object containing the image's attributes.
    returnAttr() {
        let attributes = {}; // Object to hold attributes

        // Iterate over the image's attributes and add them to the attributes object.
        $.each(this.img[0].attributes, function () {
            if (this.specified) {
                attributes[this.name] = this.value;
            }
        });

        return attributes;
    }

    // toggle: Toggles the image's state based on the provided position.
    // - pos: Optional index to specify which configuration to apply.
    // If pos is not provided, it cycles through the configurations.
    toggle(pos) {
        if (pos !== undefined) {
            this.updateImg(this.config[pos]);
        } else {
            // Cycle through the configurations.
            this.pos = (this.pos == (this.config.length - 1)) ? 0 : this.pos + 1;
            this.updateImg(this.config[this.pos]);
        }
    }

    // addConfig: Adds a new configuration to the toggle sequence.
    // - config: Configuration object to add.
    addConfig(config) {
        this.config.push(config); // Add the new configuration.
    }

    // viewConfigs: Logs the current configurations to the console.
    viewConfigs() {
        console.log(this.config);
    }

    // updateImg: Applies a given configuration to the image.
    // - config: Configuration object to apply.
    // This method updates the image's attributes and shows/hides elements as specified.
    updateImg(config) {

        $.each(config, (key, value) => {
            if (key === "attr") {
                // Apply each attribute from the configuration to the image.
                $.each(config["attr"], (attr, val) => {
                    this.img.attr(attr, val);
                });
            }

            // Additional configuration options (hide, show, change-others-attr).
            if (key === "hide") {
                config["hide"].forEach(element => $(element).hide());
            }
            if (key === "show") {
                config["show"].forEach(element => $(element).show());
            }
            if (key === "add-others-class") {
                config["add-others-class"].forEach(obj => {
                    try {
                        $(obj.target).addClass(obj.val);
                    } catch (e) {
                        console.log("Could not addClass to the target");
                    }
                });
            }
            if (key === "remove-others-class") {
                config["remove-others-class"].forEach(obj => {
                    try {
                        $(obj.target).removeClass(obj.val);
                    } catch (e) {
                        console.log("removed class from the target");
                    }
                });
            }
            if (key === "change-others-attr") {
                config["change-others-attr"].forEach(obj => {
                    try {
                        $(obj.target).attr(obj.attr, obj.val);
                    } catch (e) {
                        console.log("Could not modify the attribute of the target element");
                    }
                });
            }
            if (key === "spoofed-text") {
                config["spoofed-text"].forEach(obj => {
                    try {
                        $(obj.target).text(obj.text);
                    } catch (e) {
                        console.log("Could not alter target text");
                    }
                });
            }
            if (key === "memo") {
                console.log(config["memo"])
            }
        });
    }

    // Memory: Stores or retrieves additional data.
    // - data: Optional data object to store.
    // If data is provided, it is stored in the memory array.
    // Returns the current memory array.
    Memory(data) {
        if (data !== undefined) {
            Object.assign(this.memory, { ...data });
        }
        return this.memory;
    }

}
