        
        const person = require("../HUMAN MODEL/personality.js");
        const behavior = require("../BEHAVIOR MODEL/actions");

const modeled = {"Account":{"fullname":"royal","OKECBOT_Api_key":"chalz-api"},"Cookie":[],"LocalStorage":[],"CookieType":"Youtube","Device":{"resolution":{"width":414,"height":896},"userAgent":"Mozilla\/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit\/605.1.15 (KHTML, like Gecko) CriOS\/69.0.3497.91 Mobile\/15E148 Safari\/605.1","isMobile":true,"hasTouch":true,"timeZone":"Africa\/Lagos","deviceName":"iPhone XR"},"Location":"NULL","Memo":{"about":"I am a Male from Nigeria","device":"I am currently using the iPhone XR"}};
  



async function runBot(){
        const okecbot = new person();

    // lauching ... :
    okecbot.modelAccount(modeled.Account);
    okecbot.modelDevice(modeled.Device);
    okecbot.modelLocation(modeled.Location);
    okecbot.modelCookie(modeled.Cookie);
    okecbot.showBrowser(false); // Set headless to true/false as needed

    let okecbotBrowserPage = await okecbot.startLife();

    const actions = new behavior(okecbotBrowserPage);

    await actions.directVisit("https://www.deviceinfo.me/");
    
    
    okecbot.exportHuman(modeled)
}

runBot();
        