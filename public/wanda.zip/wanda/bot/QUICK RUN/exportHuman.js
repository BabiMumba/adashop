const person = require("../HUMAN MODEL/personality.js");
const behavior = require("../BEHAVIOR MODEL/actions");

const modeled = {
    Account: {
        fullname: "castel stone",
        OKECBOT_Api_key: "66527615d4461903fcee3cc67aa4886ed60d12e46d6220323032343038313830383231"
    },

    Device: {
        resolution: {width: 1440, height: 2960},
        userAgent: "Mozilla/5.0 (Linux; Android 7.0; SM-G950U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.83 Mobile Safari/537.36",
        isMobile:true,
        hasTouch:true,
        timeZone: "Europe/Rome" ,
        deviceName: "S8"
    },

    Location: NULL,
    Cookie: [],
    LocalStorage: [],
    CookieType: "Google"
};





async function runBot(){
        const daniel = new person();

    // lauching ... :
    daniel.modelAccount(modeled.Account);
    daniel.modelDevice(modeled.Device);
    daniel.modelLocation(modeled.Location);
    daniel.modelCookie(modeled.Cookie);
    daniel.showBrowser(false); // Set headless to true/false as needed

    let danielBrowserPage = await daniel.startLife();

    const actions = new behavior(danielBrowserPage);

    await actions.directVisit("https://m.youtube.com/watch?v=kteCwV0pZsI&pp=ygUJZGFubnlva2Vj");

    daniel.exportHuman(modeled)


}

runBot();