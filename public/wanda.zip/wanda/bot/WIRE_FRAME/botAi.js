const WebSocket = require('ws');
const botFamily = require('./botFamily.js');
/*
    USE CASE DESCRIPTION:

    Goal of this class:
    The botAi class is to process a users request and add/remove a botFamily Object from its botFamilies list.
    The items (object) to be added/removed from the botFamilies are made from processing a users request.
    A user sends a request that could be either to activate (add)  or de-activate (remove) a botFamily object from its botFamilies list.

    
    Intiaition of this class:
    This class (botAi) would be instantiated on the server.js script.
    The server.js script starts a server at port 3000 and the script has lots of end point.
    One of this endPoint on the server is "botNet". The "botNet" endpoint sends an argument to processRequest of this class.
    The processRequest analyzes the users request and decided if to add/remove a botFamily based of the informations on the users request.

    Illustration of a users Request:
    {
        department:or "de-activate" or "activate" ,
        compliment_Data: {
            botFamily_Name: "example: audiomack"}
            
                        }
                            OR
                            
                        {
            botFamily_Name: "example: audiomack"
            botFamily_Executables:  { "activity1" : {object}, "activity2": {object} },
            botFamily_Device_Brands: {
                iphone: ["audiomack-0001", "audiomack-0002", "audiomack-0003"],
                android: ["audiomack-0005", "audiomack-0006", "audiomack-0007"],
                windows: ["audiomack-0031", "audiomack-0032", "audiomack-0043"],
                mac: ["audiomack-0081", "audiomack-0082", "audiomack-0083"],
            }
            botFamily_Device_Brand_Execute_Limit:{
                iphone: 10000,
                android: 30000,
                windows: 15000,
                mac: 12000,
            }
            botFamily_Minimum_Active_Device_Brand:{
                iphone: 5,
                android: 5,
                windows: 5,
                mac: 5,
            }
            botFamily_Maximum_Active_Device_Brand:{
                iphone: 10,
                android: 10,
                windows: 10,
                mac: 10,
            }
        }
    }

    Explanation of the data:
    -   department: This is the action to be taken. It could be either "activate" or "de-activate"
    -   compliment_Data: This is an object that contains all the needed informations to execute the users request. It is an object with the following properties:
        -   botFamily_Name: Value expected is a string. The string is used to name the object instance of the botFamily that would be created.
        -   botFamily_Executables: Value expected is an object. The object keys are used to name a specific executeable. The value of each key is an object to be executed by a device in the family
        -   botFamily_Device_Brands: Value expected is an object. The object contains keys representing a device brand like android, iphone etc.
            the value of each key (device brand) is an array and the items of this array are stringified objects. This stringified object are known to us the developers of this project as "personalities or personality object". 
            By persoanlities, we mean, when the personality stringified object is json parsed it becomes an object with keys representing a browser cookie,view port, user agent and a specific puppeteer configurations to launch the puppeteer as a specific device model.
        
        -   botFamily_Device_Brand_Execute_Limit: Value expected is an objects. The keys of the object represent a device brand like iphone,samsung,windows etc.
            The value of the keys (device brand) is a number (integer). This number represents the maximum number of times a device brand can execute a task at a given time.
        -   botFamily_Minimum_Active_Device_Brand: Value expected is an objects. The keys represent the minimum number of a platicular device brand (device brand personalities) that should be active at a given time.
        -   botFamily_Maximum_Active_Device_Brand: Value expected is an objects. The keys represent the maximum number of a platicular device brand (device brand personalities) that should be active at a given time.


*/

module.exports = class botNet {


    constructor() {

        this.botFamilies = {};
        this.botFamilies_Socket_Connections = {};

        this.start_SocketServer();
    }

    async processRequest(request) { 

        /*
            USE CASE DESCRIPTION:
            -   This method is used to process a request sent to the botNet endPoint.
        */

        let botFamily_Data = request.compliment_Data;


        if ((request != undefined) && request['department'] == "activate") {    

            // this means we would be activating (adding a botFamily) to this.botFamilies
            // we would first check if the botFamily is on our botFamilies object

            let res = await this.startBotFamily(botFamily_Data);  
            return res;

        } else if ((request != undefined) && request['department'] == "de-activate") {
            // If the request is to de-activate a botFamily, we stop it
            return this.stopBotFamily(botFamily_Data.botFamily_Name);
        } else {
            return { status: false, body: "Wrong request format" }
        }
    }

    async startBotFamily(botFamily_Data) { 
        // Check if the botFamily is already running
        if (botFamily_Data["botFamily_Name"] in this.botFamilies) {
            return { status: "failed", body: "botFamily already running" }
        }

        // Check if the botFamily can meet the users execution count
        let can_Execute = new botFamily(botFamily_Data); 
        if (can_Execute.is_Executable().status != "success") return can_Execute.is_Executable()

        // If it can, we list it and start it
        this.list_BotFamily(botFamily_Data);
        return { status: true, body: "botFamily activated" }
    }

    async stopBotFamily(familyName) {
        // Check if the botFamily is running
        if (!(familyName in this.botFamilies)) {
            return { status: "failed", body: "botFamily not running" }
        }
    
        Object.keys(this.botFamilies_Socket_Connections[familyName]).forEach(botName => {
            let ws = this.botFamilies_Socket_Connections[familyName][botName];
    
            ws.send(JSON.stringify({ department: "shutDown" }));
        
        });
    
        // If it is, we unlist it and stop it
        this.unlist_BotFamily(familyName);
        return { status: true, body: "botFamily deactivated" }
    }



    list_BotFamily(botFamily_Data) {
        this.botFamilies[botFamily_Data["botFamily_Name"]] = new botFamily(botFamily_Data);
        this.botFamilies[botFamily_Data["botFamily_Name"]].uphold_Execution();
    }

    unlist_BotFamily(familyName) {

        if (!(familyName in this.botFamilies)) return { status: "failed", body: "botFamily not running" }
        // Remove the botFamily from the botFamilies object
        delete this.botFamilies[familyName];
    }

    sleep(ms) {
        // Majority of our activities such as pinging a bot or waiting for a process requires a delay.
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    start_SocketServer() {

        const wss = new WebSocket.Server({ port: 3002 });

        wss.on('connection', async (ws) => {

            ws.on('message', async (message) => {

                try {

                    const data = JSON.parse(message);
                    console.log('received: %s', message);

                    // Check the type of message received
                    if (data.type === 'botFamily') {

                        // This means the message is from a botName. This message would have other keys like botName, botFamily_Name etc
                        if (!(data.botFamily_Name in this.botFamilies_Socket_Connections)) this.botFamilies_Socket_Connections[data.botFamily_Name] = {};
                        this.botFamilies_Socket_Connections[data.botFamily_Name][data.botFamily_botName] = ws;


                    } else {
                        console.log(" Some random message was received")
                    }


                } catch
                (e) {
                    console.log("invalid message received", e)
                }

            });

            ws.on('close', () => {

                // Remove from botFamily_Socket_Connections
                let keys = this.get_webSocket_key_from_ws(ws);
                delete this.botFamilies_Socket_Connections[keys[0]][keys[1]];
                console.log(` ${keys[0]} has disconnected`);
            });
        });

        console.log('WebSocket server started on port 3002');
    }

    maintain_List(){
        /*
            We would maintain our botFamily list using this method.
            This method would be called every 5 minutes to check if the botFamily has completed its execution.
        */

            try{

                Object.keys(this.botFamilies).forEach(botFamily => {
                    let botFamilyObj = this.botFamilies[botFamily];
                    if (botFamilyObj.mission_Completed().status == "completed") {
                        this.stopBotFamily(botFamily);
                    }
                });

            }catch(e){
                console.log(e)
            }
            finally{
                setTimeout(this.maintain_List, 15000)
            }
    }

    get_webSocket_key_from_ws(ws) {
        /* 
        This method returns the websocket key of a ws
        */
        let extracted_Key1 = null;
        let extracted_Key2 = null;

        Object.keys(this.botFamilies_Socket_Connections).forEach(botFamily => {

            Object.keys(this.botFamilies_Socket_Connections[botFamily]).find(key => {

                if (this.botFamilies_Socket_Connections[botFamily][key] === ws) {
                    extracted_Key1 = botFamily;
                    extracted_Key2 = key;
                }

            });

        });

        return [extracted_Key1, extracted_Key2];

    }

}