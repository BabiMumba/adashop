const fs = require('fs');
const path = require('path');

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const runScripts = async () => {
    // Get the path to the scripts directory
    const scriptsDir = path.join(__dirname, 'humans');

    // Get a list of all files in the scripts directory
    const files = fs.readdirSync(scriptsDir);

    // Filter the files to only include .js files
    const jsFiles = files.filter(file => file.endsWith('.js'));

    // Loop through the .js files and run them using node
    for (const file of jsFiles) {
        const filePath = path.join(scriptsDir, file);
        console.log(`Running script: ${filePath}`);
        
        try {
            require(filePath);
        } catch (error) {
            console.error(`Failed to run ${filePath}:`, error);
        }

        // Wait for n seconds before continuing to the next file
        await delay(2500);
    }
}

runScripts();
