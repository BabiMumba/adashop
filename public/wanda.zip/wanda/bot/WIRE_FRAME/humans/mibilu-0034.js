
const WebSocket = require('ws');
const path = require('path');
const person = require(path.resolve(__dirname,"../../HUMAN MODEL/personality.js"));
const behavior = require(path.resolve(__dirname,"../../BEHAVIOR MODEL/actions"));

function getScriptName() {
    // This function returns the name of the script that is currently running
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();

const modeled =  {
    "Account": {
        "fullname": "mibilu-0034",
        "OKECBOT_Api_key": "642fd5c91d8a3404204377fd134cf55a32473ce554a920323032343039303230393136"
    },
    "Cookie": [],
    "LocalStorage": [],
    "CookieType": "Idle",
    "Device": {
        "resolution": {
            "width": 360,
            "height": 780
        },
        "userAgent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/125.0.6422.80 Mobile/15E148 Safari/604.1",
        "isMobile": true,
        "hasTouch": true,
        "timeZone": "America/Nipigon",
        "deviceName": "Apple iPhone 12 Mini"
    },
    "Location": {
        "proxyType": "http",
        "proxyServer": "http://45.127.248.127:5128",
        "proxyUsername": "babistoneproxy23",
        "proxyPassword": "bebeto243"
    }
};

const proxyChain = null;


async function runBot() {
    const okecbot = new person(modeled);
        
    if(proxyChain != null){

        // this means a proxyServer was attached to this guy
        okecbot.modelLocation({
            "proxyType": "https",
            "proxyServer": "http://"+proxyChain.server+":"+proxyChain.port,
            "proxyUsername": proxyChain.username,
            "proxyPassword": proxyChain.password
        })
        
        // set the timeZone to the new location of proxy chain
        okecbot.Device.timeZone = proxyChain.timeZone

    }

    okecbot.showBrowser(false); // Set headless to true/false as needed

    if ( (null != null) || ("1727466228869" != null) ){
        await okecbot.startLife(null,false);
    }else{
        await okecbot.startLife();
    }

    // set the botNet so it can be remotely controlled my the a botNet executor
    okecbot.botNet_ID = "1727466228869" ;

    // disable cookies and bot state management for request with this key
        
    if( null != null ){
            okecbot.noBotState = true;
    }else{
        //load all state
        await okecbot.browser.loadBotState("mibilu-0034");
    }


    const ws = new WebSocket('ws://localhost:3001');

    ws.on('open', function open() {

        /*         
        Pass the reference of this opened web socket connection to the personality Object that was initiated above.
        ~ The personality method would use this opened socket to a process and exchange json/data with the botEngine
         */

        okecbot.set_Communicator_Socket(ws,botName);

        ws.on('error', function error(err) {
            console.error('WebSocket error:', err);
        });

        ws.on('close', function close() {
            console.log('mibilu-0034 is disconnected from the botEngine');
            process.exit();
        });
    });

    // now the session has been established


    if ( (null != null) || ("1727466228869" != null) ){
        await okecbot.chromeBrowserPage.goto("http://localhost:3000/onboard/blank.html", { waitUntil: 'domcontentloaded' })
      } else {
        
        await okecbot.chromeBrowserPage.goto("https://www.okecbot.com", { waitUntil: 'domcontentloaded' })
      }


    // ^^ This crashes the bot should the bot originator be a botnet that has been terminated 
    okecbot.selfDestructBotNet();



}

runBot();

        
        