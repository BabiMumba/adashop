const fs = require('fs');
const { exec } = require('child_process');
const path = require('path');
const WebSocket = require('ws');
const axios = require('axios');
const os = require('os');
const operatingSystem = os.platform();
module.exports = class botEngine {


    constructor() {
        this.runningBot = [];
        this.runningProcesses = {}; // Store child process objects

        // start the socket server here
        const wss = new WebSocket.Server({ port: 3001 });
        this.clients = {};

        this.botNet = new Set(); // This is used to monitor the botNets currently running

        this.botState = {}; // stores the entire bot State

        this.noBotState = true;

        //cache personality
        this.personality = [];

        wss.on('connection', async (ws) => {

            ws.on('message', async (message) => {

                try {

                    const data = JSON.parse(message);
                    console.log('received: %s', message);

                    // Check the type of message received
                    if (data.type === 'clientName') {
                        this.clients[data.name] = ws;
                        console.log(`bot identified with botName: ${data.name}`)

                        /*
                            check if the botName is already on the runningBot list.
                            If the botName is not on the runningBot list, we would add it to the list.
                        */

                        if (!this.runningBot.includes(data.name)) {
                            this.runningBot.push(data.name)
                        }

                    } else {
                        this.update_user_Interface_With_Memo_From_BotName(data, this.get_Bot_webSocket_value_from_botName(ws))
                        console.log(" The message updated to user Dashboard ")
                    }


                } catch
                (e) {
                    console.log("invalid message received")
                }

            });

            ws.on('close', () => {
                console.log('Client disconnected');
                let botName = `${this.get_Bot_webSocket_value_from_botName(ws)}`;
                // Remove the client from the array
                delete this.clients[botName];

                // remove it as a running bot so bugs dont stay
                this.runningBot = this.runningBot.filter(name => name !== botName);
            });
        });

        // load the botState
        this.BotState()

        //initiate apiKey
        this.apiKey;

        //  initialize botState
        this.executionAccess = 0;

        console.log('WebSocket server started on port 3001');

    }

    async BotState() {
        // This method would keep checking if an Apikey has been set and if it is it would load the botState

        let apiKey_Endpoint = `http://localhost:3000/login/key.json`;

        let res = [];
        await axios.get(apiKey_Endpoint).then(response => {
            res = response.data;
        })

        if (res.apiKey == null) {

            console.log("Apikey not yet set, still waiting")
            await this.sleep(1500);
            this.BotState()
        } else {

            //load apiKey on memory
            this.apiKey = res.apiKey;

            console.log("key found  now load the bot state ")
            await this.cachePersonality();
            await this.loadExecAccess();
            await this.loadBotState()

        }

    }

    async loadExecAccess() {

        let apiKey_Endpoint = `https://okecbot.com/api/index.php?getEaccess&key=${this.apiKey}`;

        let res = {};

        try {

            await axios.get(apiKey_Endpoint).then(response => {
                res = response.data;
            })

        } catch (e) {
            console.log("Couldnt retrieve the users Eaccess!")
        }

        if (res.Eaccess) {
            this.executionAccess = res.Eaccess;
            console.log("executionAccess set to => ", this.executionAccess)
        } else {
            console.log("executionAccess default at 0#")
            this.executionAccess = 0;
        }
    }

    async delete_botNet(networkID) {
        // This method delets a botNet from the list and also shutsDown every offSpring of the botNet

        this.botNet.delete(networkID)
        console.log("botNet deleted now proceeding to shutDown all of its offspring")

        // Loop through each connected bot
        for (const botName of Object.keys(this.clients)) {
            // Shut down the bot
            await this.send_botName_A_Message(botName, { "data": { "department": "botNet", "parent": networkID } });
        }

        console.log(`All offspring of ${networkID} has been informed to shutDown`)
    }

    async getBotState(botName) {

        // This method returns the botState of specific botName if it exist



        if (this.botState[botName]) {
            // it exist so return it
            let suc = { status: "success" }
            suc["state"] = this.botState[botName]["state"];
            suc["localStorage"] = this.botState[botName]["localStorage"];
            return suc; // the botState
        } else {
            //let the user know the bot is a virgin
            return { status: "virgin", body: "No bot state so far " };
        }

    }

    async loadBotState(apiKey = this.apiKey) {
        // This method loads the bot state and saves it in memory from okecbot server


        let okecbot_botState_Endpoint = `https://okecbot.com/api/index.php?getBotState&key=${apiKey}`;

        let res = [];
        await axios.get(okecbot_botState_Endpoint, {
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            timeout: 120000 // Set timeout to 60 seconds
        }).then(response => {
            res = response.data;
        }).catch(e => console.log(e))

        if (res.status == "success") {
            this.botState = { ...res.botState };
            console.log("bot State loaded sucessfully")
            this.noBotState = false;
            return "All state loaded";
        } else {
            this.noBotState = false;
            console.log("No bot state found")
            return { status: "failed", body: "No botState found" }
        }

    }

    async cachePersonality(apiKey = this.apiKey) {
        // This method loads the bot state and saves it in memory from okecbot server


        let okecbot_personality_Endpoint = `https://okecbot.com/api/index.php?key=${apiKey}&request=personality`;

        let res = [];
        await axios.get(okecbot_personality_Endpoint, {
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            timeout: 120000 // Set timeout to 60 seconds
        }).then(response => {
            res = response.data;
        }).catch(e => console.log(e))

        if (!res.status && res.status != "false") {
            this.personality = [...res];
            console.log("cached of personality :::: ")
            //this.noBotState = false;
            //return "All state loaded";
        } else {
            //this.noBotState = false;
            //  console.log("No bot state found")
            //return { status: "failed", body: "No botState found" }
        }

    }

    sleep(ms) {
        // Majority of our activities such as pinging a bot or waiting for a process requires a delay.
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    get_Bot_webSocket_value_from_botName(botName) {
        /* 
        This method returns the websocket reference of a botName, from the clients object
        */
        let extracted_Key = Object.keys(this.clients).find(key => this.clients[key] === botName);
        if (extracted_Key) {
            return extracted_Key;
        } else {
            return false;
        }
    }

    async send_botName_A_Message(receipient, msg) {

        /*
            This method sends a message to client connected to the websocket.
            usually the receipient is a botName. 


            The method takes in the receipient botName and then strigify and send the message
            passed to this method over to the receipient.
        */

        let message = JSON.stringify(msg.data)

        return new Promise(async (resolve, reject) => {

            let bot = this.clients[receipient];
            if (bot && bot.readyState === WebSocket.OPEN) {
                await bot.send(message);
                console.log(`sent a message to the bot ${receipient} `, msg)
                resolve("sent");
            } {
                reject("Bot is not active");
            }

        });

    }

    async update_user_Interface_With_Memo_From_BotName(memo_From_BotName, botName) {

        if (botName == false) return 0;

        if (this.clients["userDashboard_localhost"] == undefined) return 0; // this means the user dashboard is not connected to the botEngine

        /*
            This method processes the message received from a connected BotName.
            The botName can only communicate back to the botEngine through the webSocket connection it opened with the botEngine.
            and the botEngine can update the user interface with the information received from the botName.      
        */


        /*
            this method can be used to send a message to the users Dashbaord
            The user dashboard is also connected to the botEngine through a websocket connection.
            and the botEngine can update the user interface with the information received from the botName in realtime.
        */

        this.clients["userDashboard_localhost"].send(JSON.stringify({ "data": { "department": "update", "data": { "botName": botName, "memo": memo_From_BotName } } }));
    }


    async makeBot(personality, headless, proxyChain, browserPath, botNet = null, noCookie = null) {

        /*
            This method takes in a personality object and creates a bot from it.
            The personality object is a json object that contains the details of the bot to be created.
            The headless argument is a boolean value that determines if the bot would be created in headless mode or not.

        */

        let botName = personality.Account.fullname;

        /*  
            Firstly, we would check if the botName extracted from the received personality is on the list of running bots.
            If the botName is on the running list, we would return a string stating "Already running" and by default returning at this point would just
            exit the method instead of continuing the rest of the method that involves write the received personality into a file and then runing that file with 
            as a new node process (child process).
        */

        if (this.runningBot.includes(botName)) return { status: "failed", body: "Already running" };

        /*
            We would create a new JavaScript file in a specific folder designated for bots. The name of this file will be the same as the bot's name.
            This new file (also known as a "puppeteer script") is a Node.js script that will be executed as a separate process (child process).
            
            The content of this file is a template string, which includes the 'personality' object that this method receives as an argument.
       */


        let personalityString = JSON.stringify(personality, null, 4)

        let scriptTemplate = `
const WebSocket = require('ws');
const path = require('path');
const person = require(path.resolve(__dirname,"../../HUMAN MODEL/personality.js"));
const behavior = require(path.resolve(__dirname,"../../BEHAVIOR MODEL/actions"));

function getScriptName() {
    // This function returns the name of the script that is currently running
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();

const modeled =  ${personalityString};

const proxyChain = ${JSON.stringify(proxyChain, null, 4)};


async function runBot() {
    const okecbot = new person(modeled);
        
    if(proxyChain != null){

        // this means a proxyServer was attached to this guy
        okecbot.modelLocation({
            "proxyType": "https",
            "proxyServer": "http://"+proxyChain.server+":"+proxyChain.port,
            "proxyUsername": proxyChain.username,
            "proxyPassword": proxyChain.password
        })
        
        // set the timeZone to the new location of proxy chain
        okecbot.Device.timeZone = proxyChain.timeZone

    }

    okecbot.showBrowser(${headless}); // Set headless to true/false as needed

    if ( (${JSON.stringify(browserPath, null, 4)} != null) || (${JSON.stringify(botNet, null, 4)} != null) ){
        await okecbot.startLife(${JSON.stringify(browserPath, null, 4)},false);
    }else{
        await okecbot.startLife();
    }

    // set the botNet so it can be remotely controlled my the a botNet executor
    okecbot.botNet_ID = ${JSON.stringify(botNet)} ;

    // disable cookies and bot state management for request with this key
        
    if( ${JSON.stringify(noCookie, null, 4)} != null ){
            okecbot.noBotState = true;
    }else{
        //load all state
        await okecbot.browser.loadBotState("${botName}");
    }


    const ws = new WebSocket('ws://localhost:3001');

    ws.on('open', function open() {

        /*         
        Pass the reference of this opened web socket connection to the personality Object that was initiated above.
        ~ The personality method would use this opened socket to a process and exchange json/data with the botEngine
         */

        okecbot.set_Communicator_Socket(ws,botName);

        ws.on('error', function error(err) {
            console.error('WebSocket error:', err);
        });

        ws.on('close', function close() {
            console.log('${botName} is disconnected from the botEngine');
            process.exit();
        });
    });

    // now the session has been established


    if ( (${JSON.stringify(browserPath, null, 4)} != null) || (${JSON.stringify(botNet, null, 4)} != null) ){
        await okecbot.chromeBrowserPage.goto("http://localhost:3000/onboard/blank.html", { waitUntil: 'domcontentloaded' })
      } else {
        
        await okecbot.chromeBrowserPage.goto("https://www.okecbot.com", { waitUntil: 'domcontentloaded' })
      }


    // ^^ This crashes the bot should the bot originator be a botnet that has been terminated 
    okecbot.selfDestructBotNet();



}

runBot();

        
        `;

        fs.writeFile(`bot/WIRE_FRAME/humans/${personality.Account.fullname}.js`, scriptTemplate, function (err) {
            if (err) {
                console.log(err);
            }
            else {
                console.log(`Bot name: ${personality.Account.fullname} has been created. Next step is to run the bot`);
            }
        });

        return await this.run_Bot_File(personality.Account.fullname)

    }

    async run_Bot_File(botName) {

        /*
            This method takes in the name of a file (botName) and runs it as a child process.
        */

        const nodePath = path.join(__dirname, `../../node-v20/node.exe`);
        const botScriptPath = path.join(__dirname, `humans/${botName}.js`);
        const logPath = path.join(__dirname, `../BOT LOGS/${botName}.log`);

        let command = `node "${botScriptPath}"`;
        if (operatingSystem == "win32") {
            // this is a windows computer so we would use our native nodejs v16 shipped for the bot
            command = ` "${nodePath}" "${botScriptPath}"`;
        }

        const childProcess = exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`Execution error: ${error}`);
                fs.appendFile(logPath, `Execution error: ${error}\n`, (err) => {
                    if (err) console.error(`Failed to write to log file: ${err}`);
                });
            }

            // if (stdout) console.log(`stdout: ${stdout}`);
            // if (stderr) console.error(`stderr: ${stderr}`);

            this.update_Running_Bot_list("off", botName);
            delete this.runningProcesses[botName]; // Remove the reference
        });

        let botName_Active_Status = await this.ping_Bot(botName, 5); // Check if the bot is active

        if (!botName_Active_Status) {
            console.log(`Bot ${botName} timeOut and couldnt be pinged`, botName_Active_Status);
            return { status: "failed", body: "Bot could not be pinged" };
        }

        this.runningProcesses[botName] = childProcess; // Store the child process object
        this.update_Running_Bot_list("on", botName);
        return { status: "success", body: "Bot is running" };
    }

    update_Running_Bot_list(flow, botName) {
        /*
            This method updates the runningBot list (active bot list)

        */

        if (flow == "on") {
            // Add the botName to the array if it's not already present
            if (!this.runningBot.includes(botName)) {
                this.runningBot.push(botName);
                console.log(`updated running Bot list: turned on ${botName}`)
            }
        } else if (flow == "off") {
            // Remove the botName from the array
            this.runningBot = this.runningBot.filter(name => name !== botName);
            console.log(`updated running Bot list: turned OFF:: ${botName}`)
        }
    }

    shuffleObject(obj) {
        // Get the keys of the object
        const keys = Object.keys(obj);

        // Perform Fisher-Yates shuffle algorithm
        for (let i = keys.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [keys[i], keys[j]] = [keys[j], keys[i]];
        }

        // Create a new object with shuffled keys
        const shuffledObj = {};
        keys.forEach(key => {
            shuffledObj[key] = obj[key];
        });

        return shuffledObj;
    }

    async execute_Action_On_BotName(request_from_server3000) {

        /*
            This method receives a request from the endPoint server3000 to execute an action on a botName.
        */

        /*
            This method would be used to send direct message to the open socket connection of a botName.
            The bot has to be running before this method can be used. 
            If the bot is not running, this method would return a failed status. and body of the response would be "not reachable"
            There would be 3 major properties in the request body and we would use them to determine what action to take.

            First: property is the botName. example "audiomack-0001"
            Seond: property is the action to be taken which would be either "save_state", "terminate_Current_Execution" and lastly "execute_activity_chain"
            Third: property is the additional data the second property might need to execute. 
            At the moment, only the "execute_activity_chain" needs additional data. which is the activity chain to be executed.
            If no additional data is needed, the third property should be null.
        */

        let botName = request_from_server3000.botName;
        let action = request_from_server3000.action;
        let compliment_data = request_from_server3000.compliment_data;
        let flow = request_from_server3000.flow;

        if (flow == "randomly") {
            compliment_data = this.shuffleObject(compliment_data)
        }

        try {
            let botBtatus = this.check_BotName_On_RunningBot_List(botName);

            if (botBtatus == "running") {

                let response = await this.send_botName_A_Message(botName, { "data": { "department": action, "compliment_data": compliment_data } });

                if (response == "sent") {
                    return { status: "success", body: "command sent, feedback its on terminal" };
                } else {
                    return { status: "failed", body: "command not sent" };
                }


            } else {
                return { status: "failed", message: "Bot was not reachable" }
            }


        } catch (e) {
            console.log(e)
        }

    }


    async showDown_BotName(botName) {
        /*
            This method takes in a botName and shuts down the bot.
            It first sends a message to the botName to end its process using its identified socket instance.
            We only resolve the promise when the botName is successfully shut down.
            We no this because we would keep pinging the botName to check if it is still active.
            When it is no longer active, we resolve the promise
        */
        const childProcess = await this.runningProcesses[botName];
        if (!childProcess) {
            console.log(`No running bot found with name: ${botName}`);
            return { status: "failed", body: "The bot " + botName + " is in-active" };
        }

        try {
            // send a message to the botName to shutdown bot using is identified socket instance
            await this.send_botName_A_Message(botName, { "data": { "department": "shutDown", "data": null } });
            await this.sleep(3000); // sleep for 3 seconds before checking if the bot is still active
            let status = await this.ping_Bot(botName, 1); // Check if the bot is active
            if (status === true) return { status: "failed", body: "Bot could not be terminated" }; // If the bot is still active

            //else
            console.log(`Bot ${botName} terminated`);
            this.update_Running_Bot_list("off", botName);
            delete this.runningProcesses[botName]; // Remove the reference
            return { status: "success", body: "Bot is terminated" };
        } catch (error) {
            console.error(`Error deactivating bot ${botName}:`, error);
            return { status: "failed", body: "Bot could not be terminated" };
        }
    }

    async shutdownAllBots() {
        // Loop through each connected bot
        for (const botName of Object.keys(this.clients)) {
            // Shut down the bot
            await this.send_botName_A_Message(botName, { "data": { "department": "shutDown", "data": null } });
        }

        return { "status": "success", "message": "All bot has been shutdown!" }
    }

    check_BotName_On_RunningBot_List(botName) {
        /*
            This method checks if the botName is in the runningBot array.
        */

        if (this.runningBot.includes(botName)) {
            return 'running';
        } else {
            return 'off';// 'inactive';
        }

    }

    async botNet_spawnBot(personality, activity) {
        /*
            This method wouldnt return a response because is only used 
            to make a bot and execute an activity at once created
            This method takes in a personality object and creates a bot from it.
            The personality object is a json object that contains the details of the bot to be created.
            The activity argument is a json object that contains the activity chain to be executed on the bot.
        */

        await this.makeBot(personality, false).then(async (response) => {
            if (response.status == "success") {
                await this.execute_Action_On_BotName({ botName: personality.Account.fullname, action: "botNet_execute_activity", compliment_data: activity })

            }
        }).catch((e) => {
            console.log(e)
        })

    }


    async ping_Bot(botName, Check_Times) {
        /*
            This method checks if a bot is active by checking if the bot is connected to the botEngine webSocket server.
            
            Usual scenario:
            When ever a bot is launched, it sends a message to the botEngine with its name so its register webSocket connection with its botName in an object. called clients.

            This method would check if a specified botName is on that client list
            If the botName is in the clients object it returns true and never retrys again. 
            If the botName is not in the clients object, It checks a number of times specified on the (Check_Times) before returning a false value. 
            For each time it checks it sleeps for a second before checking again.
        */

        return new Promise(async (resolve, reject) => {
            //true if bot is active and false if bot is not active or not reachable after specified number of checks

            // since we could ping a new bot that has not yet been added to the clients object, we would check if the botName is in the clients object
            let bot = this.clients[botName];
            if ((bot != undefined) && (bot.readyState === WebSocket.OPEN)) {
                resolve(true);
            } else {
                console.log(`Bot ${botName} is not active, ping again in 3 seconds`)
                if (Check_Times > 0) {
                    await this.sleep(3000);// sleep for a second before running the ping again
                    this.ping_Bot(botName, Check_Times - 1).then(resolve).catch(reject);
                } else {
                    resolve(false);
                }
            }
        });

    }


}