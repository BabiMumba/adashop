// require your node modules
const bot = require("puppeteer-extra");
const os = require('os');
const operatingSystem = os.platform();
// add stealth plugin and use defaults (all evasion techniques) 
const StealthPlugin = require('puppeteer-extra-plugin-stealth')
// StealthPlugin.enabledEvasions = new Set([
//   'navigator.webdriver' // Enable navigator.webdriver evasion
// ]);
//bot.use(StealthPlugin())
var { executablePath } = require('puppeteer')

const { DateTime } = require('luxon');
const readline = require('readline');
const axios = require('axios').default;//perme
const fs = require("fs");
const path = require('path');
const { color, log, red, green, cyan, cyanBright } = require('console-log-colors');

// The platform executables::
const browser = require(path.resolve(__dirname, "../BEHAVIOR MODEL/usage/toolBox/browser"));
const free_loader = require(path.resolve(__dirname, "../BEHAVIOR MODEL/usage/toolBox/free_loader"));
const primary_pro = require(path.resolve(__dirname, "../BEHAVIOR MODEL/usage/toolBox/primary_pro"));
const secondary_pro = require(path.resolve(__dirname, "../BEHAVIOR MODEL/usage/toolBox/secondary_pro"));
const GPT_PRO = require(path.resolve(__dirname, "../BEHAVIOR MODEL/usage/toolBox/GPT_PRO"));

// <== in other to ensure easy usability of okecbot browser we shipped a custom browser for windows

if (operatingSystem == "win32") {
  // this is a windows computer so change executable path to our own browser
  executablePath = () => path.resolve(__dirname, "../../okecbotEngine/bot.exe");
}

module.exports = class Human {


  constructor(modeled) {
    this.Account = null;
    this.Device = null;
    this.Location = null;
    this.Cookies = null;
    this.headless = false;
    this.executeReport = null;
    this.consoleColor = color;

    this.browser = null;
    this.botName = null;

    this.memo = {
      status: "idle",
      logs: []
    };

    this.botName_modeled_personality = modeled;

    this.apiKeyInfo = null;

    // Launch configuration.
    this.modelAccount(this.botName_modeled_personality.Account);
    this.modelDevice(this.botName_modeled_personality.Device);
    this.modelLocation(this.botName_modeled_personality.Location);
    this.modelCookie(this.botName_modeled_personality.Cookie);


    //check device
    this.mobileType = null;

    // botNet originator
    this.botNet_ID = null;
    this.noBotState = null;
  }

  async selfDestructBotNet() {
    // should for any reason the parent is dead exit process


    try {

      let response = await axios.post("http://localhost:3000/botAI",
        {
          action: "query-botNet",
          networkID: this.botNet_ID
        });

      response = response.data;

      //console.log("selfDestruct response", response)

      if (response == "in-Active" & this.botNet_ID != null) {
        process.exit()// exit the bot
      }

    } catch (e) {
      console.log(e)
    } finally {
      await this.sleep(1000);
      this.selfDestructBotNet();
    }




  }

  establish_BotFamily_Socket(ws, botFamily_Name, botFamily_botName) {
    /*
      This method is called  by a botFamily device that has been launched.
      The argument received is the websocket instance of the botFamily device that has been launched.
    */

    this.ws = ws;
    this.botFamily_Name = botFamily_Name;
    this.botName = botFamily_botName;

    const message = {
      type: "botFamily",
      botFamily_Name: this.botFamily_Name,
      botFamily_botName: this.botName
    };

    this.ws.send(JSON.stringify(message));

    this.process_Message_From_BotEngine();


  }


  set_Communicator_Socket(ws, botName) {
    // Pass a reference of the initiated websocket of the bot script to this method 
    // This method can then use the websocket instance to receive and process messages
    // send feedback of task executions to the botEngine and finally execute commands received from
    // bot Engine, such as visit a website, save cookie to okecbot database through an end point
    // & customly iterate the chain of commands / activites receieved by the botEngine
    this.ws = ws;
    this.botName = botName;

    const message = {
      type: 'clientName',
      name: botName,
    };
    this.ws.send(JSON.stringify(message));

    this.process_Message_From_BotEngine();

    this.set_Memo_And_Update_BotEngine("log", this.botName_first_Launch_log)
  }

  async set_Memo_And_Update_BotEngine(type, data) {
    /*
      When ever we are supposed to console log a message, we would instead push the message to the memo object (logs array)
      We would also update the status of the bot to the memo object. after updating the memo object, we would send the memo object to the botEngine
    */

    if (type == "log") {
      this.memo.logs.push(data);
    } else if (type == "status") {
      this.memo.status = data;
    }

    await this.ws.send(JSON.stringify(this.memo));
  }

  async execute_Executable(executable) {
    /*
      When a botFamily makes a bot it gives it an executable to execute.
      This executable is interpreted by the bot and executed.

      Firstly we must interpret the executable and then execute it.
      IF this is a limited version other script needed to launch this activity will not be present and so
      a pop inidcating user can not do the action will be poped up
    */

    let executor_method = Object.keys(executable)[0];

    let executor_name = executable[executor_method]["name"];
    let executor_requirement = JSON.stringify(executable[executor_method]["requirement"]);
    let executor_secondary = JSON.stringify(executable[executor_method]["secondary"]);

    // lets get the owners info
    this.apiKeyInfo = await this.browser.retreiveInfo();
    this.personality_Object = this.browser.personality_Object;

    let javascript_evaluable_string = ` this.${executor_method}.${executor_name}(${executor_requirement},${executor_secondary})`;

    console.log(javascript_evaluable_string);


    try {

      let i = await eval(javascript_evaluable_string);

      console.log(i);

      return "Executable executed successfully!";

    } catch (e) {
      console.log(" Task was'nt executed ")
      console.log(e)
      return
    }



  }

  process_Message_From_BotEngine() {

    /*
    This method is called when the botEngine sends a message to this botName instance.
    This method would first parse the message, interprete it then execute the command interepreted.
    If the command is to execute a chain of activities, this method would call the interprete_Received_Activity_Chain_Object method
    otherwise it would execute the command received such as save State or just shutDown the bot script (process.exit()
    */

    this.ws.on('message', async (message) => {
      const parsed_message = JSON.parse(message);

      try {
        switch (parsed_message.department) {

          case 'shutDown':
            await this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} just received a signal to deactivate now! `);
            await this.set_Memo_And_Update_BotEngine("status", "idle");
            process.exit();
            break;

          case 'botNet':
            // when a Botnet is stopped this bot check if it was its originator and stop if it was
            if (parsed_message.parent == this.botNet_ID) {
              await this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} just received a signal to deactivate now! because botNet parent has been terminated `);
              process.exit();
            }

          case 'terminate_execution':
            /*
              We would terminate the execution of the activity by setting the status of the bot to terminate_now
              But this would work only when the status is at executing. if is not at executing, we would not terminate the execution
            */
            if (this.memo.status != "executing") {
              await this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} Can not terminate because no execution is currently running!`);
              break;
            }
            await this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} just received a signal to terminate execution now! `);
            await this.set_Memo_And_Update_BotEngine("status", "terminate_now");
            break;


          case 'task':
            if (this.memo.status == "executing") {
              console.log(` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}, is currently executing an activity chain, so it would not execute the new activity chain received! `);
              break;
            }
            // set executing task: yes
            await this.set_Memo_And_Update_BotEngine("status", "executing");
            console.log("This activity would be executed in the next", parsed_message.compliment_data.timeBeforeTask, " seconds")
            await this.sleep(parsed_message.compliment_data.timeBeforeTask);
            await this.execute_Executable(parsed_message.compliment_data.task)
            this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} just received a signal to deactivate now! `);
            this.set_Memo_And_Update_BotEngine("status", "idle");
            process.exit()
            break;

          case 'activity_chain':
            /*
              We would first check if the bot is currently executing an activity chain.
              If it is executing an activity chain, we would not execute the new activity chain received.
              If it is not executing an activity chain, we would execute the new activity chain received.
            */
            if (this.memo.status == "executing") {
              await this.browser.popInfo({ timer: 15, title: `Access Denied`, message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}, is currently executing an activity chain, so it would not execute the new activity chain received! ` });
              break;
            }
            await this.set_Memo_And_Update_BotEngine("status", "executing");
            await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} just received a signal to execute a chain of activities now! `);
            await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} are now interpreting the activity chain object received! `);
            let activity_Javascript_Evalable_Array = await this.interprete_Received_Activity_Chain_Object(parsed_message.compliment_data);

            for (let activity of activity_Javascript_Evalable_Array) {

              /* 
                  This is where we try to execute each activity and send back a feedback to the botEngine
                  so it can then update the dashboard if the execution was succesfful or not
  
                  but firstly we would have to set the memo object to set to terminate_now so the bot can stop executing the activity chain if it is break the loop 
                  If it breaks all the loop because terminate_now is the value of this.memo.status, It would at the end of the loop set the this.memo.status back to idle
                  And then newer activities can be executed.
              */

              if (this.memo.status == "terminate_now") {
                break;
              }

              await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} is now executing the activity chain! below `);
              await this.set_Memo_And_Update_BotEngine("log", `activity: ${activity}`);

              console.log(`bot: ${this.botName} is now executing the activity chain! below `);
              console.log(`activity: ${activity}`);

              try {

                let activity_Chain_Execution_response = await eval(activity);
                await this.set_Memo_And_Update_BotEngine("log", "Activity executed successfully! ");

                console.log("Activity executed successfully! ", activity_Chain_Execution_response);

              } catch (e) {
                await this.browser.popInfo({ timer: 15, title: `Access Denied`, message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}, Okecbot.com has not given me the access to perform this action, please contact okecbot support team okecbot.com ` });
                console.log(e)
              }

            }

            // task is done so execute Task
            await this.chromeBrowserPage.goto("https://okecbot.com", { waitUntil: 'domcontentloaded' })

            this.set_Memo_And_Update_BotEngine("status", "idle");
            this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} has finished executing the activity chain!`)
            break;


          default:
            console.log('Unknown department', parsed_message.department);
        }
      } catch (error) {
        console.error('Error executing command:', error);
      }

    });

  }

  async interprete_Received_Activity_Chain_Object(activity, orderly) {

    /*
      This method would interprete the activity chain object received from the botEngine.
      
      How does it acheive this you ask ?:
      The activity is usually an object with keys. each key is an activity to be executed.
      The value of each key is an executor. example of an executor is: youtube,audio mack, google, instagram, facebook, twitter, linkedin, etc.
      We call it executor because it basically a class that has been instantiated at the beginning of the bot script.
      if you look at the require modules you would find a comment under which says " The platform executables " 
      This executables are instantiated at the beginning of the bot script and are used to execute the activities a method in there class
  
      :: To make it easier to understand, each of the executables is a class that has a methods
      this methods taking in parameters in other to execute a task. example of a method is: youtube.search("search query")
  
  
      Now back the where we left of (executables).
      each of the executables has another object with 3 fundamental keys.
      The keys are:
        ***:: name: <= The name property is simply the method to execute within the executable class. (example: find_video, stream_video)
        ***:: requirement: <= The requirement property is simply the parameters to pass to the method to be executed. (example: search query, video url)
        ***:: seconday: <= This are further action that can be executed after the primary action has been executed. (example: video_Link_ToMatch, comment, subscribe, thumbsUp, thumbsDown, etc)
  
      Now that we have understood the structure of the activity chain object, lets now look at how we would interprete it.
      We would first loop through the activity object and get the keys of the object.
      We would then use the keys to get the executor of the activity.
      we would get the first key of the executor.
      We would then use the executor to get the name, requirement and secondary of the activity.
      We would then use the name, requirement and secondary to build a javascript evaluable string.
      We would then push the javascript evaluable string to an array.
      We would then return the array of javascript evaluable string.
      The botEngine would then loop through the array and execute each javascript evaluable string.
      The botEngine would then send a feedback to the dashboard if the execution was succesfful or not.
    */

    let activity_Javascript_Evalable_Array = [];
    let activity_keys = Object.keys(activity);


    activity_keys.forEach(key => {

      let executor = activity[key];

      let executor_method = Object.keys(executor)[0];

      let executor_name = executor[Object.keys(executor)[0]];
      let executor_requirement = JSON.stringify(executor_name.requirement);
      let executor_secondary = JSON.stringify(executor_name.secondary);

      let javascript_evaluable_string = `this.${executor_method}.${executor_name["name"]}(${executor_requirement},${executor_secondary})`;

      activity_Javascript_Evalable_Array.push(javascript_evaluable_string);

    });

    return activity_Javascript_Evalable_Array;
  }

  getCurrentDateTimeInTimezone(timezone) {
    // Set the locale to ensure the month is displayed in English
    const dateTime = DateTime.now().setZone(timezone).setLocale('en-US');

    // Format the date and time
    const formattedDate = dateTime.toFormat("dd'th' LLL yyyy HH:mm a");

    return formattedDate;
  }


  modelAccount(Account) {
    this.Account = Account;
  }

  modelDevice(Device) {
    this.Device = Device;
  }

  modelLocation(Location) {
    this.Location = Location;
  }

  modelCookie(Cookies) {
    this.Cookies = Cookies;
  }

  showBrowser(status) {
    this.headless = status;
  }

  getProxy() {

    if (this.Location != "NULL") {
      return `--proxy-server=${this.Location.proxyServer}`
    } else {
      return ``;
    }

  }

  parseSetCookieHeader(cookiesHeader) {
    return cookiesHeader.split(/,(?=\s*[a-zA-Z0-9_\-]+=)/g).map(cookie => {
      let parts = cookie.split(';').map(part => part.trim());
      let pair = parts[0].split('=');
      let cookieObject = {
        name: pair[0],
        value: pair[1],
      };

      parts.slice(1).forEach(part => {
        let [key, value] = part.split('=');
        key = key.trim().toLowerCase();
        value = value ? value.trim() : true;
        switch (key) {
          case 'expires':
            cookieObject.expires = new Date(value).getTime() / 1000; // convert to UNIX timestamp
            break;
          case 'max-age':
            cookieObject.expires = Date.now() / 1000 + parseInt(value);
            break;
          case 'domain':
            cookieObject.domain = value;
            break;
          case 'path':
            cookieObject.path = value;
            break;
          case 'secure':
            cookieObject.secure = true;
            break;
          case 'httponly':
            cookieObject.httpOnly = true;
            break;
          case 'samesite':
            cookieObject.sameSite = value;
            break;
          default:
            // Any other cookie attributes that may need handling
            break;
        }
      });

      return cookieObject;
    });
  }

  async launchNow(botConfiguration) {
    try {
      // Launch the browser here (chrome)
      this.chromeBrowser = await bot.launch(botConfiguration);
    } catch (e) {
      console.log("Couldn't launch because of ::==> ", e);
      await this.sleep(2000);
      this.launchNow(); // Ensure `this` is used to refer to the method within the class
    }
  }

  async startLife(Execpath = executablePath(), free = true) {

    if (Execpath == null) {
      Execpath = executablePath();
    }
    // get the proxy details
    let username = this.Location.proxyUsername;
    let password = this.Location.proxyPassword;

    let bWidth = this.Device.resolution.width;
    let bHeight = this.Device.resolution.height;

    if (this.Device.userAgent.includes("iPhone")) {


      this.mobileType = "iPhone";
      bHeight += 150;
      bWidth += 150;


    } else if (this.Device.userAgent.includes("Android")) {

      this.mobileType = "Android";
      bHeight += 150;
      bWidth += 150;
    }
    else {
      console.log("This isnt a Mobile device...")
    }

    // Load the bot configurations
    const botConfiguration = {
      headless: this.headless,
      devtools: false,
      //userDataDir: path.resolve(__dirname, "../BEHAVIOR MODEL/mimick"),
      //executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",//Execpath,
      executablePath: Execpath,
      ignoreDefaultArgs: ['--enable-automation'],
      ignoreHTTPSErrors: true,
      defaultViewport: this.Device.resolution,
      args: [this.getProxy(), `--window-size=${bWidth},${bHeight}`, '--no-sandbox', '--disable-setuid-sandbox', '--disable-features=WebRtcHideLocalIpsWithMdns',
        '--disable-webrtc-encryption',
        '--disable-webrtc-multiple-routes',
      //`--disable-extensions-except=${BypasserExtension}`,
      //`--load-extension=${BypasserExtension}`,
      `--user-agent=${this.Device.userAgent}`,
        `--enable-process-per-site-up-to-main-frame-threshold`,
        `--disable-blink-features=AutomationControlled`,
        `--test-type=gpu`
      ]
    };


    await this.launchNow(botConfiguration);

    let pages = await this.chromeBrowser.pages();
    this.chromeBrowserPage = pages[0];


    // Set the timezone to New York (Eastern Time)
    await this.chromeBrowserPage.emulateTimezone(this.Device.timeZone);
    if (this.Location != "NULL") {
      console.log(" Ip proxy time loll")
      // Authenticate our proxy with username and password defined above
      await this.chromeBrowserPage.authenticate({ username, password });
    } else {
      console.log("browsering from local network since no proxy detected")
    }
    // set the useragent
    await this.chromeBrowserPage.setUserAgent(this.Device.userAgent);

    if (this.Device.userAgent.includes("iPhone")) {

      console.log("This is an iPhone so shealth on")

      this.mobileType = "iPhone";


    } if (this.Device.userAgent.includes("Android")) {
      console.log("This is an Android so shealth on")

      this.mobileType = "Android";
    }
    else {
      console.log("This isnt mobile...")
    }

    await this.chromeBrowserPage.setViewport({
      width: this.Device.resolution.width,  // Example width
      height: this.Device.resolution.height,  // Example height
      isMobile: this.Device.isMobile,
      hasTouch: this.Device.hasTouch,  // Often used with isMobile to simulate touch
      deviceScaleFactor: 1.0  // Example device scale factor (e.g., for retina screens)
    });




    this.botName_first_Launch_log = `bot: ${this.Account.fullname}  has started life on ${this.Device.deviceName} tunneling through ${this.Location.proxyServer} proxy!. Timezone is at ${this.Device.timeZone} and so the current time on " ${this.Account.fullname} " machine is ${this.getCurrentDateTimeInTimezone(this.Device.timeZone)}`;

    // Now we have successfully launched the browser, we would instantiate the executables with the chromeBrowserPage object
    this.browser = new browser(this);
    this.free_loader = new free_loader(this);
    this.primary_pro = new primary_pro(this);
    this.secondary_pro = new secondary_pro(this);
    this.GPT_PRO = new GPT_PRO(this);

    // Listen for frame navigate and trigger a local storage import if it hasnt been done already
    this.chromeBrowserPage.on('framenavigated', async frame => {
      const newUrl = frame.url();
      if (newUrl.trim().length > 13 && newUrl != "about:blank") {

        // start a state monitoring for this domain
        this.browser.importLocalStorages(newUrl);

      }
    });

    await this.chromeBrowserPage.setRequestInterception(true);

    // Handle all intercepted requests
    this.chromeBrowserPage.on('request', interceptedRequest => {
      // Continue each intercepted request
      interceptedRequest.continue();
    });

    this.chromeBrowserPage.on('response', async (response) => {

      if (response.status() === 407) {
        console.log("Proxy authentication required. Check your proxy settings.");
        await this.chromeBrowserPage.goto("http://localhost:3000/onboard/botNetwork-issues.html", { waitUntil: 'domcontentloaded' })
        await this.sleep(9000);
        process.exit();
      }

      const cookiesHeader = response.headers()['set-cookie'];
      if (cookiesHeader) {
        // Extract cookies from response
        const url = new URL(response.url());
        const domain = url.hostname;
        // Handling multiple cookies in the header
        const cookies = await this.browser.dumpCookie();
        try {
          const localStorage = await this.browser.dumpLocalStorage();

          console.log("local:::: ")
          // Send cookies to an endpoint
          await this.browser.send_Origin_Cookie(domain, { cookie: cookies, localStorage: localStorage });

        } catch (e) {
          console.log(color.red(`couldnt send cookie for origin: ${domain} ===> ${e}`))
        }
      }
    });

    try {

      // install mouse tracker
      await this.browser.installMouseHelper();
      // bypas Cdp
      await this.browser.cdpBypass();

      // humanly decline pop notifications
      // Handle pop-ups, alerts, and other dialogs
      this.chromeBrowserPage.on('dialog', async dialog => {
        console.log(`Dialog of type ${dialog.type()} appeared`);
        const delay = 1000 + Math.random() * 2000; // 2 to 5 seconds
        await this.sleep(delay);
        await dialog.dismiss(); // Automatically dismiss the dialog after delay
      });

      this.chromeBrowserPage.on('popup', async popup => {
        const popupUrl = popup.url();
        console.log(`Intercepted popup with URL: ${popupUrl}`);
        await popup.close();
        await this.chromeBrowserPage.goto(popupUrl);
    });

      if ((this.mobileType == "iPhone")) {
        await this.browser.iphoneBypass();
      }
      else if ((this.mobileType == "Android")) {
        await this.browser.androidBypass();
      }

    } catch (e) {
      console.log("couldnt visit okecbot bot because of :: ", e)
      await this.chromeBrowserPage.goto("http://localhost:3000/onboard/botNetwork-issues.html", { waitUntil: 'domcontentloaded' })
      await this.sleep(9000);
      process.exit();
      //wait 15seconds before exiting
    }



  }

  sleep(ms) {
    // Majority of our activities such as pinging a bot or waiting for a process requires a delay.
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async logOffHuman() {
    await this.chromeBrowser.close();
  }



}
