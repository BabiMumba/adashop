// This component would focused on  human activities 

const { createCursor } = require("ghost-cursor");
const path = require('path');
const fs = require("fs");
const { title } = require("process");
const { error } = require("console");
const { json } = require("express");
const OpenAI = require("openai");
const axios = require('axios').default;
const { color, log, red, green, cyan, cyanBright } = require('console-log-colors');
module.exports = class HumanBehavior {

    //behavior en français signifie comportement
    //donc cette classe est une classe qui permet de simuler le comportement humain sur le web
    constructor(personality_Object) {
        this.personality_Object = personality_Object;
        this.webPage = this.personality_Object.chromeBrowserPage;
        this.cursor = createCursor(this.webPage)

        this.botName_instance = personality_Object;
        this.color = color;
        this.apiKeyInfo = {};

        this.botLocalStorage = {};

        // track the localStorages
        this.stateClearance = new Set();

        this.botVisited = new Set();

        this.botName = this.botName_instance.Account.fullname;

        this.bot_State_Switch = "OFF";
        this.mouseX = 0;
        this.mouseY = 0;

        //this.loadExecAccess();
    }

    async clickLinkByBaseUrl(page, baseUrl) {
        const result = await page.evaluate((baseUrl) => {
            // Create a regex to match links that start with the base URL
            const regex = new RegExp(`^${baseUrl}`);

            // Search for all links that match the regex in the entire document
            const links = Array.from(document.querySelectorAll('a')).filter(a => regex.test(a.href));

            if (links.length > 0) {
                // If multiple links are found, pick a random one
                const randomLink = links[Math.floor(Math.random() * links.length)];
                randomLink.click();
                return "success";
            } else {
                return "failed";
            }
        }, baseUrl);


        try {
            // Wait for potential navigation after the key press
            await this.webPage.waitForNavigation({ waitUntil: 'networkidle0', timeout: 5000 });
        } catch (e) {

        }

        return result;
    }

    async clickLinkInIframeBySrc(page, iframeSrcBase, hrefToMatch) {
        const processIframes = async (iframes, context) => {
            for (let iframe of iframes) {
                const src = await context.evaluate(iframe => iframe.src, iframe);
                if (src.startsWith(iframeSrcBase)) {
                    const frame = await iframe.contentFrame();
                    if (frame) {
                        let links = await frame.$$('a[href^="' + hrefToMatch + '"]');
                        links = this.shuffle(links); // Shuffle the array of links
    
                        for (let link of links) {
                            const boundingBox = await link.boundingBox();
                            const x = boundingBox.x + Math.random() * boundingBox.width;
                            const y = boundingBox.y + Math.random() * boundingBox.height;
    
                            console.log(`Clicking at coordinates (${x}, ${y}) in iframe with src: ${src}`);
                            await page.mouse.click(x, y);
    
                            try {
                                await page.waitForNavigation({ timeout: 5000 });
                                console.log('Navigation triggered');
                                return 'Navigation triggered';
                            } catch (error) {
                                await this.pick_Interaction_with_page(this.time_On_Page_From_Range(" '2' to '5' seconds"));
                                console.log('No navigation triggered, moving to next link');
                            }
                        }
    
                        // Recursively process nested iframes within the current iframe
                        const nestedIframes = await frame.$$('iframe');
                        const result = await processIframes(nestedIframes, frame);
                        if (result === 'Navigation triggered') {
                            return result;
                        }
                    }
                }
            }
    
            return 'No navigation triggered in any iframe';
        };
    
        const iframes = await page.$$('iframe');
        return await processIframes(iframes, page);
    }
    
    shuffle(array) {
        // Shuffle array using Fisher-Yates algorithm
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
    
    
    
    


    async loadExecAccess() {

        this.apiKeyInfo = await this.retreiveInfo();
        let apiKey_Endpoint = `https://okecbot.com/api/index.php?getEaccess&key=${this.apiKeyInfo.apiKey}`;

        let res = {};

        try {

            await axios.get(apiKey_Endpoint).then(response => {
                res = response.data;
            })

        } catch (e) {
            //console.log("Couldnt retrieve the users Eaccess!")
            throw new Error("Couldnt retrieve the users Eaccess!")
        }

        if (res.Eaccess >= 0) {
            return parseInt(res.Eaccess);
        } else {
            throw new Error("Couldnt retrieve the users Eaccess! @@@@@@22")
        }
    }

    async loadBotState(name) {
        // firstyly get the state

        let res = null;


        res = await this.getBotState(name);

        if (res.state) {

            try {
                let state = res.state;

                if (state.length == 1) {
                    console.log("This is the processed cookie and not fresh!!!")
                    for (let i = 0; i < state.length; i++) {
                        await this.webPage.setCookie(...state[0])
                    }
                    console.log("===> remade, this is not fresh from server")

                } else {
                    // this is fresh from the server because it has lots of length and the local system cookie hasnt reset it
                    console.log(" This is fresh from server", " fresh ;length ==> ", state.length)
                    let allCookies = []; // to simulate all cookies like local dump
                    for (var h = 0; h < state.length; h++) {
                        for (let i = 0; i < state[h].length; i++) {
                            allCookies.push(state[h][i])
                        }
                    }

                    await this.webPage.setCookie(...allCookies) // now we set
                }


                // loop through the local storage array, each index has an object in which the key is the origin and the value is the local storage stringified 
                for (let i = 0; i < Object.keys(res.localStorage).length; i++) {
                    let origin = Object.keys(res.localStorage)[i];

                    try {
                        this.botLocalStorage[origin] = JSON.parse(res.localStorage[origin]);
                        console.log("Origin ==> ", origin, " Now has its botState set!")
                    } catch (e) {
                        console.log("failed to parse localstorage for origin::: ::", origin)
                    }

                }

                console.log("All stated loaded successfully")
            } catch (e) {
                console.log("Couldnt load botstate terrible error from okecbot response", e, res)
            }
        } else if (res.virgin) {


            console.log(`Hi, ${this.apiKeyInfo.owner} , BOT STATE FOR :::+> <h3 style="color:green;"> ${this.botName} </h3>, IS VIRGIN, NO SAVED FINGER PRINTS`);

        } else {
            //await this.popError({ timer: 5, title: `VIRGIN BOT STATE`, message: `Major gbese. check your API key maybe it been changed from serve` });

            console.log("Major gbese. check your API key maybe it been changed from server")
        }

        //await this.webPage.reload(); #Because a task would carry on no need to reload page

    }

    async directVisit(url) {

        // visit a website directly
        try {

            await this.webPage.goto(url, { waitUntil: 'domcontentloaded' })
        } catch (e) {
            await this.sleep(1000)
            await this.popError({ timer: 15, title: "Link Not Accessible", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}, When I tried visiting the link ( ${url} ) it returned an error. My guess is that your link is either incorrect or the proxy server I am using has been banned from accessing the link` })
            throw new Error("Failed to visit the link.");
        }


    }

    async retreiveInfo() {

        let inFo = path.join(__dirname, "..", "..", "website", "login", "key.json");
        let data = fs.readFileSync(inFo, "utf-8");
        let proccessedData = JSON.parse(data)
        return proccessedData;

    }

    async importLocalStorages(currentOrigin) {

        let origin = new URL(currentOrigin);
        currentOrigin = origin.hostname;

        // This method loads local storages when ever a frame navigate has been done

        // we want to set the Cookie, only and only if that domain has not been visited on this instance
        if (!this.botVisited.has(currentOrigin)) {
            console.log("We have never visited here!, so we would find a local storage received for this url and try to set it on current bot state ")

            if (this.botLocalStorage[currentOrigin]) {

                console.log(`bot state for ${currentOrigin} would be loaded from the local storage object, moving over to set it on current bot state`)

                try {

                    // Set the local storage
                    await this.webPage.evaluate(localStorageData => {
                        for (const key in localStorageData) {
                            localStorage.setItem(key, localStorageData[key]);
                        }
                    }, this.botLocalStorage[currentOrigin]);


                    this.botVisited.add(currentOrigin) // add to the visited log
                    console.log("Local storage was appended successfully")

                } catch (e) {
                    console.log("couldnt set the local storage for this domain", currentOrigin)
                }

            } else {
                console.log(`No local storage found for the origin ${currentOrigin} ::: `)
            }

        } else {
            console.log(`local storage was not loaded because it already has been loaded before on this url ${currentOrigin}`)
        }

        this.stateClearance.add(currentOrigin)


    }

    async getBotState(name) {
        // This method would return the saved for the primary domain of the url from okecbot server

        //Get the bot owner's name
        this.apiKeyInfo = await this.retreiveInfo();
        // build the endPoint
        //axios to the endPoint requesting for the bot cookies
        /*
            Args:
                botName:: personality_Object.botName
                apiKey:: apiKeyInfo.apiKey

        */
        let okecbot_Cookie_Endpoint = `http://localhost:3000/getBotState`;
        console.log(okecbot_Cookie_Endpoint)
        let cookie = [];
        await axios.post(okecbot_Cookie_Endpoint, {
            "botName": name
        }).then(response => {
            cookie = response.data;
        })

        if ((cookie.status) && (cookie.status == "success")) {
            let domainCookie = [];
            for (let i = 0; i < cookie.state.length; i++) {
                domainCookie.push(JSON.parse(cookie.state[i]));
            }

            let domainLocalStorage = cookie.localStorage;

            return {
                state: domainCookie,
                localStorage: domainLocalStorage
            }



        } else if ((cookie.status) && (cookie.status == "virgin")) {
            return {
                virgin: true,
                feedback: cookie.body
            };
        } else {
            return {
                gbese: true,
                feedback: cookie.body
            }
        }


    }

    //cette fonction permet de recuperer les cookies de la page
    //car le cookie est un element important pour la navigation sur le web
    async dumpCookie() {
        const cookies = await this.webPage.cookies();
        return cookies;
    }

    //dumpLocalStorage permet de recuperer les informations stockées dans le local storage
    //local storage est un espace de stockage qui permet de stocker des informations sur le navigateur du client tel que les préférences, les données de session, etc.
    //il est important de le recuperer pour une navigation fluide
    async dumpLocalStorage() {

        // This method returns the localStorage data of the current context

        try {
            // Get localStorage data
            const localStorageData = await this.webPage.evaluate(() => {
                const data = {};
                for (let i = 0; i < localStorage.length; i++) {
                    const key = localStorage.key(i);
                    const value = localStorage.getItem(key);
                    data[key] = value;
                }
                return data;
            });

            // Store the localStorage data in a file
            const localStorageDataJSON = localStorageData;
            return localStorageDataJSON;
        } catch (e) {
            return {};
        }
    }

    //getOrigin permet de recuperer l'origine de la page actuelle
    async getOrigin() {
        try {
            await this.webPage.waitForNavigation({ timeout: 3000 })
        } catch (e) {

        }

        // This method returns the current url the bot is currently on
        let url = await this.webPage.evaluate(() => window.location.href);
        return this.getPrimaryDomain(url);

    }

    async send_Origin_Cookie(origin, object) {

        if(this.personality_Object.noBotState && this.personality_Object.noBotState == true){
            return "noBot state Mode";
        }

        if (!this.stateClearance.has(origin)) {
            console.log(` ${origin} : : ===>> `, color.red("We dont have the clearance yet to update servers, we would wait till clearance"))
        }


        // This method would update okecbot server with the cookie of the primary domain from url currently on on
        //Get the bot owner's name
        this.apiKeyInfo = await this.retreiveInfo();
        // build the endPoint
        //axios to the endPoint requesting for the bot cookies
        /*
            Args:
                primaryDomain::: origin
                botName:: personality_Object.botName
                apiKey:: apiKeyInfo.apiKey
 
                cookies::
                localStorage::
 
        */
        let okecbot_Cookie_Endpoint = `https://okecbot.com/api/index.php?setState&botName=${this.personality_Object.botName}&key=${this.apiKeyInfo.apiKey}&origin=${origin}`;

        let cookies = object.cookie;
        let localStorage = object.localStorage;

        let state = JSON.stringify({
            botName: this.personality_Object.botName,
            origin: origin,
            cookies: cookies,
            localStorage: localStorage
        })


        await axios.post(okecbot_Cookie_Endpoint, state);

        // The bot state sent to the local server is encased in an array. but the one sent to live server isnt encased
        // we would encase it before sending to local server


        state = JSON.parse(state);

        // the above sends only the cookie of current page instead of all. below will send all instead
        // Fetch all cookies for the current context
        const client = await this.webPage.target().createCDPSession();
        const allCookiesResponse = await client.send('Network.getAllCookies');
        const allCookies = allCookiesResponse.cookies;

        state["cookies"] = [allCookies];


        // save a local copy on this okecbot seesion so when browsers are respawned they wouldnt be outdated 
        await axios.post("http://localhost:3000/updateBotState", state).then(() => {
            console.log("updated local server with newest state")
        });

        console.log(`bot: ${this.personality_Object.botName} state for the origin ${origin} has been saved on okecbot server`)
        return state;

    }

    getPrimaryDomain(url) {
        const parsedUrl = new URL(url);
        return parsedUrl.hostname;

    }

    async hideMouseHelper() {
        try {
            await this.webPage.evaluate(() => {
                const box = document.querySelector('puppeteer-mouse-pointer');
                if (box) {
                    box.style.display = 'none';
                }
            });
        } catch (e) {
            console.log("Couldn't hide mouse tracker.");
        }
    }

    async showMouseHelper() {
        try {
            await this.webPage.evaluate(() => {
                const box = document.querySelector('puppeteer-mouse-pointer');
                if (box) {
                    box.style.display = 'block';
                }
            });
        } catch (e) {
            console.log("Couldn't show mouse tracker.");
        }
    }

    async installMouseHelper() {
        const iconUrl = 'http://localhost:3000/images/okecbot-bounce.png';

        try {

            await this.webPage.evaluateOnNewDocument((iconUrl) => {
                // Install mouse helper only for the top-level frame.
                if (window !== window.parent)
                    return;

                window.addEventListener('DOMContentLoaded', () => {
                    const box = document.createElement('puppeteer-mouse-pointer');
                    const styleElement = document.createElement('style');
                    styleElement.innerHTML = `
              puppeteer-mouse-pointer {
                pointer-events: none;
                position: absolute;
                top: 0;
                z-index: 10000;
                left: 0;
                width: 40px;
                height: 40px;
                background: url('${iconUrl}');
                background-size: contain;
                border: none;
                margin: 0;
                padding: 0;
                transition: background .2s;
              }
              puppeteer-mouse-pointer.button-1 {
                transition: none;
                background: url('${iconUrl}');
                background-size: contain;
              }
              puppeteer-mouse-pointer.button-2 {
                transition: none;
              }
              puppeteer-mouse-pointer.button-3 {
                transition: none;
              }
              puppeteer-mouse-pointer.button-4 {
                transition: none;
              }
              puppeteer-mouse-pointer.button-5 {
                transition: none;
              }
            `;
                    document.head.appendChild(styleElement);
                    document.body.appendChild(box);
                    document.addEventListener('mousemove', event => {
                        box.style.left = event.pageX + 'px';
                        box.style.top = event.pageY + 'px';
                        updateButtons(event.buttons);
                    }, true);
                    document.addEventListener('mousedown', event => {
                        updateButtons(event.buttons);
                        box.classList.add('button-' + event.which);
                    }, true);
                    document.addEventListener('mouseup', event => {
                        updateButtons(event.buttons);
                        box.classList.remove('button-' + event.which);
                    }, true);

                    function updateButtons(buttons) {
                        for (let i = 0; i < 5; i++)
                            box.classList.toggle('button-' + i, buttons & (1 << i));
                    }
                }, false);
            }, iconUrl);

        } catch (e) {
            console.log("Couldnt install mouse tracker so we would retry again.")
            await this.installMouseHelper()
        }
    }


    // Click an element given its selector
    async click_on_element(selector) {
        try {
            const element = await this.webPage.$(selector);
            const currentURL = this.webPage.url();
            await this.cursor.click(selector);

            // Wait for navigation only if the URL changes
            await this.webPage.waitForNavigation({
                waitUntil: 'networkidle0',
                timeout: 5000 // Adjust the timeout as needed
            }).catch(() => {
                // No navigation happened, or navigation timeout occurred
                console.log("Navigation did not happen or timed out.");
            });

            // Check if the URL has changed
            if (this.webPage.url() === currentURL) {
                console.log("No navigation occurred.");
            } else {
                console.log("Navigation occurred.");
            }
        } catch (e) {
            console.log(e);
        }
    }

    async click_with_xpath(xpath) {
        try {
            const currentURL = this.webPage.url();

            // Find the element using XPath
            const [element] = await this.webPage.$x(xpath);

            // Check if the element exists
            if (!element) {
                throw new Error(`Element not found for XPath: ${xpath}`);
            }

            // Perform click using Puppeteer's built-in click method
            await Promise.all([
                this.webPage.waitForNavigation({
                    waitUntil: 'networkidle0',
                    timeout: 5000 // Adjust the timeout as needed
                }).catch(() => {
                    // No navigation happened, or navigation timeout occurred
                    console.log("Navigation did not happen or timed out.");
                }),
                element.click()
            ]);

            // Check if the URL has changed
            if (this.webPage.url() === currentURL) {
                console.log("No navigation occurred.");
            } else {
                console.log("Navigation occurred.");
            }
        } catch (e) {
            console.log(e);
        }
    }
    async enterKeyMobile() {
        try {
            const currentURL = this.webPage.url();

            // Perform click using Puppeteer's built-in click method
            await Promise.all([
                this.webPage.waitForNavigation({
                    waitUntil: 'networkidle0',
                    timeout: 5000 // Adjust the timeout as needed
                }).catch(() => {
                    // No navigation happened, or navigation timeout occurred
                    console.log("Navigation did not happen or timed out.");
                }),

                // Press the "Enter" key
                this.webPage.keyboard.press('Enter')
            ]);

            // Check if the URL has changed
            if (this.webPage.url() === currentURL) {
                console.log("No navigation occurred.");
            } else {
                console.log("Navigation occurred.");
            }
        } catch (e) {
            console.log(e);
        }
    }

    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    async clickRandomlyUntilNavigationWithNextButton(duration = 120, maxNextPages = 2) {
        let currentPage = 1;
        const startTime = Date.now();
        let clicked = false;
        let currentURL = this.webPage.url();
        const container = await this.webPage.$(`body`);

        if (!container) {
            console.error(`Container with ID "body" not found.`);
            return;
        }

        const elements = await container.$$('a');
        const lookAroundDuration = this.getRandomInt(Math.floor(duration * 0.25), Math.floor(duration * 0.50)) * 1000;
        const endTime = startTime + lookAroundDuration;
        let potentialCoords = [];

        for (const element of elements) {
            if (Date.now() >= endTime) break;

            try {
                const box = await element.boundingBox();
                if (box) {
                    const x = box.x + box.width / 2;
                    const y = box.y + box.height / 2;
                    await this.webPage.mouse.move(x, y, { steps: 10 });
                    this.mouseX = x;
                    this.mouseY = y;
                    await this.webPage.waitForTimeout(this.getRandomInt(1000, 3000));
                    potentialCoords.push({ x, y });
                }
            } catch (e) {
                console.error("Error during gathering coordinates:", e);
            }
        }

        const navigateToNextPage = async () => {
            try {
                const nextButton = await this.webPage.$x('a[aria-label="Next page"]');
                if (nextButton) {
                    console.log("Attempting to go to the next page...");
                    await nextButton.click();
                    await this.webPage.waitForNavigation({
                        waitUntil: 'networkidle0',
                        timeout: 5000
                    });
                    console.log("Navigation to next page occurred.");
                    currentPage += 1;
                    return true;
                } else {
                    console.log("Next page button not found.");
                    return false;
                }
            } catch (e) {
                console.error("Error navigating to the next page:", e);
                return false;
            }
        };

        const remainingTime = duration * 1000 - lookAroundDuration;
        const clickEndTime = Date.now() + remainingTime;

        potentialCoords = this.shuffleArray(potentialCoords)

        while (Date.now() < clickEndTime && !clicked) {
            for (const coord of potentialCoords) {
                if (Date.now() >= clickEndTime) break;

                try {
                    await this.webPage.mouse.click(coord.x, coord.y, { delay: this.getRandomInt(100, 300) });
                    await this.webPage.waitForNavigation({ waitUntil: 'networkidle0', timeout: 5000 }).catch(() => {
                        console.log("Navigation did not happen or timed out.");
                    });

                    if (this.webPage.url() !== currentURL) {
                        console.log("Navigation occurred.");
                        clicked = true;
                        break;
                    } else {
                        console.log("No navigation occurred.");
                        await this.pick_Interaction_with_page(this.time_On_Page_From_Range(" '1' to '3' seconds"));
                    }
                } catch (e) {
                    console.error("Error during clicking:", e);
                }
            }

            if (!clicked && currentPage <= maxNextPages && (Date.now() - startTime) / 1000 > 15 * currentPage) {
                if (Math.random() > 0.5) {
                    const navigated = await navigateToNextPage();
                    if (navigated) {
                        currentURL = this.webPage.url();
                    }
                }
            }
        }

        if (!clicked) {
            console.error("Failed to find or click on a result within the time limit.");
        }
    }

    //cdpBypass evades detections that Puppeteer is being used
    //cette fonction permet d'éviter les détections que Puppeteer est utilisé en modifiant les propriétés du navigateur
    //c'est une fonction asynchrone qui prend en paramètre une page web
    //elle retourne une promesse
    async cdpBypass() {
        await this.webPage.evaluateOnNewDocument(() => {
            // Some website detect google chrome developer tab being open so we hide that detection here
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'devtools' ? Promise.resolve({ state: 'denied' }) : originalQuery(parameters)
            );

            // Overwrite the `console` functions if they are monitored
            const noop = () => { };
            console.log = noop;
            console.debug = noop;
            console.warn = noop;
            console.error = noop;
            console.info = noop;

            if (navigator.webdriver === false) {
                // Post Chrome 89.0.4339.0 and already good
            } else if (navigator.webdriver === undefined) {
                // Pre Chrome 89.0.4339.0 and already good
            } else {
                // Pre Chrome 88.0.4291.0 and needs patching
                delete Object.getPrototypeOf(navigator).webdriver
            }
        });
    }

    async macBypass() {
        // This method evades detections that puppeteer is not a real iPhone device

        let device = this.personality_Object.Device.userAgent;
        await this.webPage.evaluateOnNewDocument((device) => {
            WebGLRenderingContext.prototype.getParameter = function (origFn) {
                const paramMap = {
                    0x9245: "Google Inc. (Apple)",  // UNMASKED_VENDOR_WEBGL
                    0x9246: "Apple GPU",   // UNMASKED_RENDERER_WEBGL
                };
                return function (parameter) {
                    return paramMap[parameter] || origFn.call(this, parameter);
                };
            }(WebGLRenderingContext.prototype.getParameter);

            WebGL2RenderingContext.prototype.getParameter = function (origFn) {
                const paramMap = {
                    0x9245: "Google Inc. (Apple)",  // UNMASKED_VENDOR_WEBGL
                    0x9246: "Apple GPU",   // UNMASKED_RENDERER_WEBGL
                };
                return function (parameter) {
                    return paramMap[parameter] || origFn.call(this, parameter);
                };
            }(WebGL2RenderingContext.prototype.getParameter);

            const modifyNavigator = (originalNavigator, device) => {
                const override = {
                    plugins: originalNavigator.plugins,
                    platform: 'iPhone',
                    vendor: 'Apple Computer, Inc.',
                    userAgent: device,
                    plugins: originalNavigator.plugins

                };

                const handler = {
                    get: function (target, prop) {
                        if (override.hasOwnProperty(prop)) {
                            return override[prop];
                        }
                        return Reflect.get(target, prop);
                    }
                };

                const proxyNavigator = new Proxy(originalNavigator, handler);
                Object.defineProperty(globalThis, 'navigator', {
                    value: proxyNavigator,
                    writable: false,
                    configurable: false,
                    enumerable: true
                });
            };

            modifyNavigator(navigator, device);

        }, device);




    }
    async iphoneBypass() {
        // This method evades detections that puppeteer is not a real iPhone device
        let device = this.personality_Object.Device.userAgent;
        await this.webPage.evaluateOnNewDocument((device) => {
            WebGLRenderingContext.prototype.getParameter = function (origFn) {
                const paramMap = {
                    0x9245: "Apple Inc.",  // UNMASKED_VENDOR_WEBGL
                    0x9246: "Apple GPU",   // UNMASKED_RENDERER_WEBGL
                };
                return function (parameter) {
                    return paramMap[parameter] || origFn.call(this, parameter);
                };
            }(WebGLRenderingContext.prototype.getParameter);

            WebGL2RenderingContext.prototype.getParameter = function (origFn) {
                const paramMap = {
                    0x9245: "Apple Inc.",  // UNMASKED_VENDOR_WEBGL
                    0x9246: "Apple GPU",   // UNMASKED_RENDERER_WEBGL
                };
                return function (parameter) {
                    return paramMap[parameter] || origFn.call(this, parameter);
                };
            }(WebGL2RenderingContext.prototype.getParameter);

            const modifyNavigator = (originalNavigator, device) => {
                const override = {
                    plugins: originalNavigator.plugins,
                    platform: 'iPhone',
                    vendor: 'Apple Computer, Inc.',
                    userAgent: device,
                    plugins: originalNavigator.plugins

                };

                const handler = {
                    get: function (target, prop) {
                        if (override.hasOwnProperty(prop)) {
                            return override[prop];
                        }
                        return Reflect.get(target, prop);
                    }
                };

                const proxyNavigator = new Proxy(originalNavigator, handler);
                Object.defineProperty(globalThis, 'navigator', {
                    value: proxyNavigator,
                    writable: false,
                    configurable: false,
                    enumerable: true
                });
            };

            modifyNavigator(navigator, device);

        }, device);




    }

    async androidBypass() {
        // This method evades detections that puppeteer is not a real iPhone device

        await this.webPage.evaluateOnNewDocument(() => {
            WebGLRenderingContext.prototype.getParameter = function (origFn) {
                const paramMap = {
                    0x9245: "ARM",  // UNMASKED_VENDOR_WEBGL
                    0x9246: "Mali-G71",   // UNMASKED_RENDERER_WEBGL
                };
                return function (parameter) {
                    return paramMap[parameter] || origFn.call(this, parameter);
                };
            }(WebGLRenderingContext.prototype.getParameter);

            WebGL2RenderingContext.prototype.getParameter = function (origFn) {
                const paramMap = {
                    0x9245: "ARM",  // UNMASKED_VENDOR_WEBGL
                    0x9246: "Mali-G71",   // UNMASKED_RENDERER_WEBGL
                };
                return function (parameter) {
                    return paramMap[parameter] || origFn.call(this, parameter);
                };
            }(WebGL2RenderingContext.prototype.getParameter);

        });




    }


    async click_at_current_cursor() {
        // Randomly click at the current cursor point
        if (Math.random() > 0.5) {
            try {
                console.log("about clicking current cursor")
                // Simulate mouse down and up to click at the current position
                await this.webPage.mouse.click(this.mouseX, this.mouseY, { delay: this.getRandomInt(100, 300) });
                // await this.webPage.mouse.down({ x: this.mouseX, y: this.mouseY });
                // await this.webPage.mouse.up({ x: this.mouseX, y: this.mouseY });
                console.log("Clicked at the current cursor point:", { x: this.mouseX, y: this.mouseY });
            } catch (e) {
                console.log(e);
            }
        } else {
            console.log("No click performed.");
        }
    }

    async resetHomeCoordinate(xpath) {
        try {
            // Find the element using XPath
            const [element] = await this.webPage.$x(xpath);
            if (!element) {
                throw new Error(`Element not found for XPath: ${xpath}`);
            }

            // Get the bounding box of the element
            const box = await element.boundingBox();
            if (!box) {
                throw new Error(`Element bounding box not found for XPath: ${xpath}`);
            }

            // Calculate the element's vertical position and the window's height
            const elementY = box.y;
            const windowHeight = await this.webPage.evaluate(() => window.innerHeight);

            // Calculate the middle position of the element
            const middleY = elementY + box.height / 2 - windowHeight / 2;

            // Randomized step size for more human-like movement
            let currentY = await this.webPage.evaluate(() => window.scrollY);
            const stepSize = 10 + Math.random() * 20;
            const steps = Math.abs(currentY - middleY) / stepSize;
            const direction = currentY < middleY ? 1 : -1;

            // Scroll in steps
            for (let i = 0; i < steps; i++) {
                currentY += direction * stepSize;
                await this.webPage.evaluate(y => window.scrollTo(0, y), currentY);
                await this.webPage.waitForTimeout(30 + Math.random() * 20);  // Randomized delay
            }

            // Final scroll to the exact position
            await this.webPage.evaluate(y => window.scrollTo(0, y), middleY);

            // Pause for a moment after scrolling to mimic human behavior
            await this.webPage.waitForTimeout(500 + Math.random() * 500);
        } catch (e) {
            console.log(e);
        }
    }


    async click_with_human_like_movement(xpath) {
        try {
            // Reset home coordinate before clicking
            await this.resetHomeCoordinate(xpath);

            // Find the element using XPath
            const [element] = await this.webPage.$x(xpath);
            if (!element) {
                throw new Error(`Element not found for XPath: ${xpath}`);
            }

            // Get the bounding box of the element
            const box = await element.boundingBox();
            if (!box) {
                throw new Error(`Element bounding box not found for XPath: ${xpath}`);
            }

            // Calculate a random point within the element
            const x = box.x + Math.random() * box.width;
            const y = box.y + Math.random() * box.height;

            // Move mouse to the element's position
            await this.webPage.mouse.move(x, y, { steps: 10 });
            this.mouseX = x;
            this.mouseY = y;
            await this.webPage.mouse.down();
            await this.webPage.mouse.up();

            // Random delay to simulate human interaction
            await this.webPage.waitForTimeout(Math.random() * 1000);

            // Wait for navigation if the element triggers a page change
            const currentURL = this.webPage.url();
            await this.webPage.waitForNavigation({
                waitUntil: 'networkidle0',
                timeout: 5000
            }).catch(() => {
                console.log("Navigation did not happen or timed out.");
            });

            // Check if the URL has changed
            if (this.webPage.url() === currentURL) {
                console.log("No navigation occurred.");
            } else {
                console.log("Navigation occurred.");
            }
        } catch (e) {
            console.log(e);
        }
    }

    extractXpath(inputString, navigator = false) {
        const regex = /"([^"]*)"/g;
        const xpaths = [];
        let match;

        while ((match = regex.exec(inputString)) !== null) {
            xpaths.push(match[1]);
        }

        if (navigator) {
            return xpaths[0]; // navigators dont need the kind of nesting xpath that visit_website uses so it returns just one
        }

        return xpaths;
    }

    // Fill an input field with specified text
    async fillInput(selector, text) {
        await this.webPage.type(selector, text);
    }

    // Hover over an element given its selector
    async hoverElement(selector) {
        const element = await this.webPage.$(selector);
        if (element) {
            await element.hover();
        }
    }

    async injectLaserScanner(page) {
        // Define the CSS for the laser scanner
        const scannerCSS = `
            <style>
                #laserScanner {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100vw;
                    height: 50px;
                    background-color: darkblue;
                    color:#fff;
                    line-height:50px;
                    font-size:20px;
                    text-align: center;
                    z-index: 10000;
                    animation: moveScanner 5s linear infinite;
                }
                @keyframes moveScanner {
                    0% { top: 0; }
                    100% { top: 100vh; }
                }
            </style>
        `;

        // Define the JavaScript to start the animation
        const scannerJS = `
            const laserScanner = document.createElement('div');
            laserScanner.id = 'laserScanner';
            laserScanner.innerHTML = "Okecbot AI is scanning Webpage";
            document.body.appendChild(laserScanner);
        `;

        await page.evaluate((css, js) => {
            document.head.insertAdjacentHTML('beforeend', css);
            eval(js);
        }, scannerCSS, scannerJS);

    }

    async hideLaserScanner(page) {
        const hideJS = `
            (function() {
                const scanner = document.getElementById('laserScanner');
                if (scanner) {
                    scanner.style.display = 'none';
                }
            })();
        `;
        await page.evaluate(hideJS);
    }

    async showLaserScanner(page) {
        const showJS = `
            (function() {
                const scanner = document.getElementById('laserScanner');
                if (scanner) {
                    scanner.style.display = 'block';
                }
            })();
        `;
        await page.evaluate(showJS);
    }

    // Take a screenshot of the current web page view
    async takeScreenshot(filename = null) {
        if (filename == null) {
            const timestamp = this.generateTimestamp();
            filename = `AI-VISION/screenshot_${timestamp}.png`
            await this.webPage.screenshot({ path: filename });
        }

        if (filename == "base64") {
            return await this.webPage.screenshot({ encoding: 'base64' });
        }
    }

    async gridClickCordinate(dimensions, AI_grids) {
        let horizontalGrid = AI_grids.horizontalGrid;
        let verticalGrid = AI_grids.verticalGrid;
        /*
            This method returns the cell to click on based off the dimension of the page and the AI response
            From the 
        */

        const cellWidth = dimensions.width / 12;
        const cellHeight = dimensions.height / 12;

        const clickX = (horizontalGrid - 1) * cellWidth + cellWidth;
        const clickY = (verticalGrid - 1) * cellHeight + cellHeight;

        return { x: clickX, y: clickY };
    }

    async gpt_Scanner(meta, freshScan) {

        try {

            //firstly get a base64 encode of the image snapshotted!

            //first hide okeccbobot
            await this.hideMouseHelper();
            await this.sleep(2000)
            let imageEncoded = await this.takeScreenshot("base64");
            let apiKey = await this.retreiveInfo();
            await this.sleep(1000)
            /*
             secondly we would start a loop transition/animation to simulate a scanner on the webPage,
             the scanner would be a line (border-line 5px dark blue) 
             moving from top to bottom, left to right. This would loop untill stopped
             like a resident eveil laser scanner kind of effect
             */

            //start scanner
            if (freshScan) {
                this.injectLaserScanner(this.webPage)
            } else {
                this.showLaserScanner(this.webPage)
            }
            /*
             Thirdly, while the scan effect is still going on (mimicking AI page scan)
             We would post the encoded64bit Image to okecbot AI endpoint using the APikey of the user
             If the user has Tokens left on our server, The image would be analyzed and the response
             returned.
             */


            let feedback = {};

            // get the image dimesions
            const sharp = require('sharp');
            let img = Buffer.from(imageEncoded, "base64");
            let image = await sharp(img).metadata();
            feedback["dimensions"] = { width: image.width, height: image.height };

            await axios.post(`http://okecbot.com:3003/scanImage`, {
                apiKey: apiKey.apiKey,
                meta: meta,
                base64Image: imageEncoded
            }, {
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 120000 // Set timeout to 60 seconds
            }).then(async res => {
                feedback["res"] = res.data;
            }
            ).catch((e) => {

                this.popError({ timer: 15, title: "AI error", message: `I am bot: ${this.personality_Object.botName}:::, I scanned this page but I wasnt getting a suitable response from okecbot server. please check out with support` })
                feedback["res"] = {
                    message: "Insufficient token balance or Access denied to okecbot GPT. contact support if this persist"
                };
            })

            await this.hideLaserScanner(this.webPage); // remove laser scanner

            // add the mouse tracker again
            await this.showMouseHelper();

            //console.log(color.green(JSON.stringify(feedback)))

            return feedback

        } catch (e) {
            console.log(color.red(e))
        }

    }

    // Navigate back to the previous page
    async goBack() {
        await this.webPage.goBack();
    }

    // Navigate forward (if there was a previous backward navigation)
    async goForward() {
        await this.webPage.goForward();
    }

    // Reload the current page
    async reloadPage() {
        await this.webPage.reload();
    }

    // Close the current tab or page
    async closeTab() {
        await this.webPage.close();
    }

    extractNumbersFromString(str) {
        // Regular expression to match numbers in the format "'number' to 'number'"
        const regex = /'(\d+)' to '(\d+)' seconds/g;

        // Array to store extracted numbers
        const numbers = [];

        // Executing the regular expression on the string
        let match = regex.exec(str);

        // If there is a match
        if (match) {
            // Extract the first and second numbers
            numbers.push(parseInt(match[1])); // First number at index 0
            numbers.push(parseInt(match[2])); // Second number at index 1
        }

        return numbers;
    }

    // Generate a timestamp string
    generateTimestamp() {
        const now = new Date();
        return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}-${String(now.getSeconds()).padStart(2, '0')}`;
    }

    time_On_Page_From_Range(duration) {
        /*
            This method would receive a minimum and maximum time on page  but it is in minutes.
            We would first convert it to miliseconds.
            Then we would generate a random number between the minimum and maximum time from the miliseconds converted.
            Then we would return the random number.
        */

        let time = this.extractNumbersFromString(duration);

        let minimum_Time_On_Page_In_Seconds = time[0] * 1000
        let maximum_Time_On_Page_In_Seconds = time[1] * 1000;
        let random_Number_Between_Minimum_And_Maximum = this.getRandomInt(minimum_Time_On_Page_In_Seconds, maximum_Time_On_Page_In_Seconds);
        return random_Number_Between_Minimum_And_Maximum;

    }

    async hideLoader() {


        await this.sleep(1500);

        await this.webPage.evaluate(() => {
            try {
                let pop = document.getElementById("popLoader");
                pop.remove();
            } catch (e) {
                console.log("couldnt hide loader")
            }
        });

        await this.sleep(1500);
    }

    async popLoader(info) {
        // This method when called would append an error modal stating the error occurred on a web page
        // The method would also throw an error after 30sec 

        await this.webPage.evaluate(info => {


            let overlay = `
                <div id="popLoader" style="transition: opacity .15s linear; position: fixed;  background:rgba(0,150,25,0.8);  top: 0;    right: 0;    bottom: 0;    left: 0;    z-index: 999999;    display: block;  outline: 0; overflow-x: hidden;    overflow-y: auto; ">
                <div  style="transform: translate(0,0); transition: transform .3s ease-out,-webkit-transform .3s ease-out; width: 80%; min-height: calc(90% - (1.5rem * 2)); margin: 1.75rem auto; display: flex; align-items: center; position: relative; pointer-events: none; align-items: center; ">
                    <div style="color:black; position: relative; display: flex; flex-direction: column; width: 100%; pointer-events: auto; background-color: #fff; background-clip: padding-box; border: 1px solid rgba(0,0,0,.2); border-radius: .3rem; outline: 0;  ">
                        <div style="display: -ms-flexbox;    display: flex;    -ms-flex-align: start;    align-items: flex-start;    -ms-flex-pack: justify;    justify-content: space-between;    padding: 1rem;    border-bottom: 1px solid #e9ecef;   border-top-left-radius: .3rem;    border-top-right-radius: .3rem;  background: linear-gradient(180deg, #112a42 0%, #53565d 90.29%, #424248 196.99%) !important;    color: white !important;">
                            <div  style="margin-bottom: 0; font-size:18px !important; line-height: 1.5;"> <center> <img style="width:45px;" src="https://okecbot.com/images/Okecbot-loader.png" width="45" /> </center> <p> </p> ${info.title} </div>
                        </div>
                        <center> <h1 style="font-size:20px;" id="loader" > <img src="http://localhost:3000/images/processing.gif" style="width:80px;"  </h1> </center>
                        <div style="max-height: 450px; overflow: scroll; font-size:14px; color:black; overflow-x: hidden; padding: 1rem; flex: 1 1 auto; position: relative; display: block; "> ${info.message} </div>
        
                    </div>
                </div>
            </div>
                `;
            document.body.innerHTML += overlay;


        }, info)



        return info.message;

    }

    async popInfo(info) {
        // This method when called would append an error modal stating the error occurred on a web page
        // The method would also throw an error after 30sec 

        await this.webPage.evaluate(info => {

            let Okectimer = info.timer;


            let timeInt = setInterval(() => {

                let timer = document.getElementById("timer");
                timer.innerHTML = Okectimer;
                // reduce the timer by 1;
                --Okectimer;

                if (Okectimer < 0) {
                    clearInterval(timeInt)
                    let pop = document.getElementById("popInfo");
                    pop.remove();
                }

            }, 1000)


            var popInfo = document.getElementById("popInfo");
            if (popInfo) {
                popInfo.remove();
            }


            let overlay = `
                <div id="popInfo" style="transition: opacity .15s linear; position: fixed;  background:rgba(0,0,150,0.8);  top: 0;    right: 0;    bottom: 0;    left: 0;    z-index: 999999;    display: block;  outline: 0; overflow-x: hidden;    overflow-y: auto; ">
                <div  style="transform: translate(0,0); transition: transform .3s ease-out,-webkit-transform .3s ease-out; width: 80%; min-height: calc(90% - (1.5rem * 2)); margin: 1.75rem auto; display: flex; align-items: center; position: relative; pointer-events: none; align-items: center; ">
                    <div style="color:black; position: relative; display: flex; flex-direction: column; width: 100%; pointer-events: auto; background-color: #fff; background-clip: padding-box; border: 1px solid rgba(0,0,0,.2); border-radius: .3rem; outline: 0;  ">
                        <div style="display: -ms-flexbox;    display: flex;    -ms-flex-align: start;    align-items: flex-start;    -ms-flex-pack: justify;    justify-content: space-between;    padding: 1rem;    border-bottom: 1px solid #e9ecef;   border-top-left-radius: .3rem;    border-top-right-radius: .3rem;  background: linear-gradient(180deg, #112a42 0%, #53565d 90.29%, #424248 196.99%) !important;    color: white !important;">
                            <div  style="margin-bottom: 0; font-size:18px !important; line-height: 1.5;"> <center> <img style="width:45px;" src="https://okecbot.com/images/Okecbot-loader.png" width="45" /> </center> <p> </p> ${info.title} </div>
                        </div>
                        <center> <h1 style="font-size:20px;" id="timer" ></h1> </center>
                        <div style="max-height: 450px; overflow: scroll; font-size:14px; color:black; overflow-x: hidden; padding: 1rem; flex: 1 1 auto; position: relative; display: block; "> ${info.message} </div>
        
                    </div>
                </div>
            </div>
                `;
            document.body.innerHTML += overlay;


        }, info)



        await this.sleep(info.timer * 1000);

        return info.message;

    }

    async popFrame(info) {
        // This method when called would append an error modal stating the error occurred on a web page
        // The method would also throw an error after 30sec 

        try {

            await this.webPage.evaluate(info => {
                // Create an iframe for the overlay
                let iframe = document.createElement('iframe');
                iframe.id = 'popInfoIframe';
                iframe.style.position = 'fixed';
                iframe.style.top = '0';
                iframe.style.left = '0';
                iframe.style.width = '100%';
                iframe.style.height = '100%';
                iframe.style.zIndex = '999999';
                iframe.style.backgroundColor = 'rgba(0, 0, 150, 0.8)';
                document.body.appendChild(iframe);

                // Access the iframe's document
                let doc = iframe.contentWindow.document;

                // Create the overlay inside the iframe
                let overlay = `
                <div id="popInfo" style="transition: opacity .15s linear; position: fixed; width: 80%; min-height: calc(90% - (1.5rem * 2)); margin: 1.75rem auto; display: flex; align-items: center; justify-content: center;">
                    <div style="color:black; position: relative; display: flex; flex-direction: column; width: 100%; pointer-events: auto; background-color: #fff; background-clip: padding-box; border: 1px solid rgba(0,0,0,.2); border-radius: .3rem; outline: 0;">
                        <div style="display: flex; justify-content: space-between; padding: 1rem; border-bottom: 1px solid #e9ecef; border-top-left-radius: .3rem; border-top-right-radius: .3rem; background: linear-gradient(180deg, #112a42 0%, #53565d 90.29%, #424248 196.99%) !important; color: white !important;">
                            <div style="margin-bottom: 0; font-size:18px; line-height: 1.5;"> <center> <img style="width:45px;" src="https://okecbot.com/images/Okecbot-loader.png" width="45" /> </center> <p> </p> ${info.title} </div>
                        </div>
                        <center> <h1 style="font-size:20px;" id="timer" ></h1> </center>
                        <div style="max-height: 450px; overflow: scroll; font-size:14px; color:black; overflow-x: hidden; padding: 1rem; flex: 1 1 auto;"> ${info.message} </div>
                    </div>
                </div>
            `;
                doc.body.innerHTML = overlay;

                // Start the timer
                let Okectimer = info.timer;
                let timeInt = setInterval(() => {
                    let timer = doc.getElementById("timer");
                    timer.innerHTML = Okectimer;
                    // reduce the timer by 1;
                    --Okectimer;

                    if (Okectimer < 0) {
                        clearInterval(timeInt);
                        let pop = doc.getElementById("popInfo");
                        if (pop) {
                            pop.style.display = 'none';
                        }
                        iframe.remove();
                    }
                }, 1000);

            }, info);

            await this.sleep(info.timer * 1000);
            return info.message;

        }catch(e){
            console.log(this.color.red(e))
        }
    }


    async popError(info) {
        // This method when called would append an error modal stating the error occurred on a web page
        // The method would also throw an error after 30sec 

        await this.webPage.evaluate(info => {

            let Okectimer = info.timer;


            let timeInt = setInterval(() => {

                let timer = document.getElementById("timer");
                timer.innerHTML = Okectimer;
                // reduce the timer by 1;
                --Okectimer;

                if (Okectimer < 0) {
                    clearInterval(timeInt)
                    let pop = document.getElementById("popError");
                    pop.remove();
                }

            }, 1000)


            var popError = document.getElementById("popError");
            if (popError) {
                popError.remove();
            }



            let overlay = `
                <div  id="popError" style="transition: opacity .15s linear; position: fixed;  background:rgba(200,15,5,0.8);  top: 0;    right: 0;    bottom: 0;    left: 0;    z-index: 999999;    display: block;  outline: 0; overflow-x: hidden;    overflow-y: auto; ">
                <div  style="transform: translate(0,0); transition: transform .3s ease-out,-webkit-transform .3s ease-out; width: 80%; min-height: calc(90% - (1.5rem * 2)); margin: 1.75rem auto; display: flex; align-items: center; position: relative; pointer-events: none; align-items: center; ">
                    <div style=" color:black; position: relative; display: flex; flex-direction: column; width: 100%; pointer-events: auto; background-color: #fff; background-clip: padding-box; border: 1px solid rgba(0,0,0,.2); border-radius: .3rem; outline: 0;  ">
                        <div style="display: -ms-flexbox;    display: flex;    -ms-flex-align: start;    align-items: flex-start;    -ms-flex-pack: justify;    justify-content: space-between;    padding: 1rem;    border-bottom: 1px solid #e9ecef;   border-top-left-radius: .3rem;    border-top-right-radius: .3rem;  background: linear-gradient(180deg, #112a42 0%, #53565d 90.29%, #424248 196.99%) !important;    color: white !important;">
                        <div  style="margin-bottom: 0; font-size:18px !important; line-height: 1.5;"> <center> <img style="width:45px;" src="https://okecbot.com/images/Okecbot-loader.png" width="45" /> </center> <p> </p> ${info.title} </div>
                        </div>
                        <center> <h1 style="font-size:20px; color:black;" id="timer" ></h1> </center>
                        <div style="max-height: 450px; overflow: scroll; color:black; font-size:14px; overflow-x: hidden; padding: 1rem; flex: 1 1 auto; position: relative; display: block; "> ${info.message} </div>
        
                    </div>
                </div>
            </div>
                `;
            document.body.innerHTML += overlay;


        }, info)



        await this.sleep(info.timer * 1000);

        return info.message;

    }

    xpathToCssSelector(xpath) {
        // Split the XPath expression into individual segments
        const segments = xpath.split('/').filter(segment => segment.trim() !== '');

        // Initialize an empty array to store selectors
        const selectors = [];

        // Iterate over each segment and convert it into a CSS selector
        segments.forEach(segment => {
            // Extract the tag name from the segment
            const tagNameMatch = segment.match(/^(\w+)/);
            if (tagNameMatch) {
                const tagName = tagNameMatch[1];
                selectors.push(tagName);
            }
        });

        // Combine the selectors to form a CSS selector
        return selectors.join(' > ');
    }

    async interact_with_Page_Inconcern(time_On_Page) {
        return new Promise(async (resolve) => {

            try {

                /*
                    Using the time_On_Page parameter, this method interact with the page at random locations after a while it moves
                    into a direction a bit and then it randomly moves the curor to another location along with a new scroll position.
                */
                let maxHeight = await this.webPage.evaluate(() => document.documentElement.scrollHeight);
                let currentHeight = 0;
                const startTime = Date.now();

                // Initialize mouse position
                let currentMousePosition = { x: 0, y: 0 };

                // Continue the loop until the specified time on page has passed
                while (Date.now() - startTime < time_On_Page) {
                    // Get a random scroll length between 100 and 5000
                    let scrollLength = this.getRandomInt(100, 5000);

                    // Randomly decide the direction of the scroll (up or down)
                    let direction = Math.random() < 0.5 ? -1 : 1;

                    // Update the current height based on the scroll length and direction
                    currentHeight += scrollLength * direction;

                    // If the current height exceeds the maximum height of the page, set it to the maximum height
                    if (currentHeight > maxHeight) {
                        currentHeight = maxHeight;
                    }
                    // If the current height is less than 0, set it to 0
                    else if (currentHeight < 0) {
                        currentHeight = 0;
                    }

                    // Scroll to the current height
                    await this.webPage.evaluate(async (newHeight) => {
                        window.scrollTo(0, newHeight);
                    }, currentHeight);

                    // Get the width and height of the viewport
                    let viewportWidth = await this.webPage.evaluate(() => document.documentElement.clientWidth);
                    let viewportHeight = await this.webPage.evaluate(() => document.documentElement.clientHeight);

                    // Get a random position within the viewport for the mouse to move to
                    let randomX = this.getRandomInt(0, viewportWidth);
                    let randomY = this.getRandomInt(0, viewportHeight);

                    // Calculate the distance the mouse should move in each step
                    let distanceX = (randomX - currentMousePosition.x) / 100;
                    let distanceY = (randomY - currentMousePosition.y) / 100;

                    // Move the mouse in 100 small steps to create a smooth movement effect
                    for (let i = 0; i < 100; i++) {
                        let newX = currentMousePosition.x + distanceX * i;
                        let newY = currentMousePosition.y + distanceY * i;
                        await this.webPage.mouse.move(newX, newY);
                        this.mouseX = newX;
                        this.mouseY = newY;
                        await this.sleep(10); // Wait a bit between each movement
                    }

                    // Update the current mouse position to the new position
                    currentMousePosition = { x: randomX, y: randomY };

                    // Wait for a random delay between 500 and 3000 milliseconds
                    let delay = this.getRandomInt(500, 3000);
                    await this.sleep(delay);
                }

                resolve();

            } catch (e) {
                console.log("errorrr ", e)
                this.sleep(5000);
                try {

                    this.interact_with_Page_Inconcern(time_On_Page)
                } catch (e) {
                    console.log(e, "==>")
                }
            }
        });
    }

    async pick_Interaction_with_page(time_On_Page) {
        /*
            This method would randomly pick one of the interraction with the page
            This interraction would be concerned or inconcerned.
            This is to aid the bot to behave like a human.
        */

        let random_Number_Between_1_And_2 = this.getRandomInt(1, 2);
        if (random_Number_Between_1_And_2 == 1) {
            console.log("I am interacting inconcern")
            await this.interact_with_Page_Inconcern(time_On_Page);
        } else {
            console.log("I am concerned")
            await this.interact_with_Page_Concern(time_On_Page);
        }
    }


    async interact_with_Page_Concern(time_On_Page) {
        return new Promise(async (resolve) => {
            let maxHeight = await this.webPage.evaluate(() => document.documentElement.scrollHeight);
            let currentHeight = 0;
            const startTime = Date.now();

            // Initialize mouse position
            let currentMousePosition = { x: 0, y: 0 };

            while (Date.now() - startTime < time_On_Page) {
                let scrollLength = this.getRandomInt(100, 5000);
                let direction = Math.random() < 0.5 ? -1 : 1;
                currentHeight += scrollLength * direction;

                if (currentHeight > maxHeight) {
                    currentHeight = maxHeight;
                } else if (currentHeight < 0) {
                    currentHeight = 0;
                }

                await this.webPage.evaluate(async (newHeight) => {
                    window.scrollTo(0, newHeight);
                }, currentHeight);

                let viewportWidth = await this.webPage.evaluate(() => document.documentElement.clientWidth);
                let viewportHeight = await this.webPage.evaluate(() => document.documentElement.clientHeight);

                // Randomly select a mouse movement pattern
                let pattern = this.getRandomInt(1, 8);
                switch (pattern) {
                    /*
                        to beat bot detection systems, keep in mind that these systems often look for
                         patterns and repetition, so using a variety of patterns and introducing more 
                         randomness could potentially make the bot seem more human-like. However, 
                         sophisticated bot detection systems may use advanced techniques like machine 
                         learning to distinguish between human and bot behavior, 
                        and these might not be easily fooled by simple cursor movement patterns.
                    */
                    case 1: // Top to bottom
                        for (let i = 0; i <= 100; i++) {
                            let newX = currentMousePosition.x;
                            let newY = (viewportHeight / 4 / 100) * i; // Adjusted this line
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                        break;
                    case 2: // Left to right
                        for (let i = 0; i <= 100; i++) {
                            let newX = (viewportWidth / 4 / 100) * i; // Adjusted this line
                            let newY = currentMousePosition.y;
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                        break;
                    case 3: // Diagonal
                        for (let i = 0; i <= 100; i++) {
                            let newX = (viewportWidth / 4 / 100) * i; // Adjusted this line
                            let newY = (viewportHeight / 4 / 100) * i; // Adjusted this line
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                        break;
                    case 4: // Diagonal reversed
                        for (let i = 100; i >= 0; i--) {
                            let newX = (viewportWidth / 4 / 100) * i; // Adjusted this line
                            let newY = (viewportHeight / 4 / 100) * i; // Adjusted this line
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                    case 5: // Zigzag
                        for (let i = 0; i <= 100; i++) {
                            let newX = (viewportWidth / 4 / 100) * i;
                            let newY = (viewportHeight / 4 / 100) * (i % 2 === 0 ? i : 100 - i);
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                        break;
                    case 6: // Circular
                        let radius = Math.min(viewportWidth, viewportHeight) / 8;
                        for (let i = 0; i <= 100; i++) {
                            let angle = 2 * Math.PI * i / 100;
                            let newX = currentMousePosition.x + radius * Math.cos(angle);
                            let newY = currentMousePosition.y + radius * Math.sin(angle);
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                    case 7: // Random walk
                        let steps = 100;
                        for (let i = 0; i <= steps; i++) {
                            let direction = Math.random() * 2 * Math.PI;
                            let distance = Math.random() * viewportWidth / 4 / steps;
                            let newX = currentMousePosition.x + distance * Math.cos(direction);
                            let newY = currentMousePosition.y + distance * Math.sin(direction);
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                        break;
                    case 8: // Spiral
                        let rotations = 5;
                        for (let i = 0; i <= 100; i++) {
                            let angle = 2 * Math.PI * rotations * i / 100;
                            let radius = (viewportWidth / 4 / 100) * i;
                            let newX = currentMousePosition.x + radius * Math.cos(angle);
                            let newY = currentMousePosition.y + radius * Math.sin(angle);
                            await this.webPage.mouse.move(newX, newY);
                            this.mouseX = newX;
                            this.mouseY = newY;
                            await this.sleep(10);
                        }
                        break;
                }

                // Update current mouse position
                currentMousePosition = { x: viewportWidth, y: viewportHeight };

                let delay = this.getRandomInt(500, 3000);
                await this.sleep(delay);

                if (Math.random() < 0.2) {
                    let scrollUpLength = this.getRandomInt(100, 500);
                    currentHeight -= scrollUpLength;
                    if (currentHeight < 0) {
                        currentHeight = 0;
                    }
                    await this.webPage.evaluate(async (newHeight) => {
                        window.scrollTo(0, newHeight);
                    }, currentHeight);
                }
            }

            resolve();
        });
    }

    // Helper function: Get random number between min and max (inclusive)
    getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // Helper function: Sleep for a given duration
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async humanTyping(text, xpath, mode = "medium") {
        try {
            // Set typing speed based on the mode
            let typingSpeeds = {
                fast: [20, 80],
                medium: [80, 150],
                slow: [150, 250]
            };
            let [minSpeed, maxSpeed] = typingSpeeds[mode] || typingSpeeds["medium"];

            // Find the input field using XPath
            const [inputElement] = await this.webPage.$x(xpath);
            if (!inputElement) {
                throw new Error(`Element not found for XPath: ${xpath}`);
            }

            // Focus on the input field before typing
            await inputElement.focus();

            // Type each character of the text with a random delay between key presses
            for (let char of text) {
                await inputElement.type(char, { delay: this.getRandomInt(minSpeed, maxSpeed) });
            }

            // Optionally, add a final delay to mimic thinking after typing
            await this.sleep(this.getRandomInt(500, 1000));
        } catch (e) {
            console.log(`Error typing text "${text}" into element with XPath "${xpath}":`, e);
        }
    }

    // Method to simulate a pick type mode
    async pickTypeMode(text, xpath) {
        // Randomly select a typing mode
        let modes = ["fast", "medium", "slow"];
        let selectedMode = modes[this.getRandomInt(0, modes.length - 1)];

        console.log(`Selected typing mode: ${selectedMode}`);
        await this.humanTyping(text, xpath, selectedMode);
    }



    async generateTxt(prompt) {

        let apiKey = await this.retreiveInfo();

        let response = await axios.post(`http://okecbot.com:3003/genTXT`, {
            apiKey: apiKey.apiKey,
            prompt: prompt
        })

        return response.data
    }



}