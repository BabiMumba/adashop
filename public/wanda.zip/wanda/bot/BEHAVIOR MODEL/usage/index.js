const fs = require('fs').promises; // Use fs.promises for async file operations
const path = require('path');

module.exports = class control {

    constructor() {
    }

    async validateInput(obj) {
        /*
            This function first checks the tool pack and the tool selected;
            After which this function would loop through the required (primary) inputs
            to see if any was empty. if empty this function would return false
            and popUp the inputs that needs its value set. 
        */

        let position = null;

        // firstly lets get the tool Pack and tool used, then we can compare the data supplied with the required on 
        //control for tha tools
        Object.keys(obj)[0] == "mission" ? position = 1 : position = 0;
        let tool = Object.keys(obj)[position]

        /*
            We would be limiting the bot feature of this version to process only
            browser or This is because the other tools would be on a premium version
        */

        // controls 
        let controls = JSON.parse(await this.rtnControls());

        // now we know the tool lets move into getting the requirements and then loop against it
        let required = obj[tool].requirement;

        // now lets compare the ones filled 
        // Check if both objects have the same number of keys
        const userKeys = Object.keys(required);

        // lets loop through to find the index of the element tha matches this
        let requiredKeys = null;
        await new Promise ( resolve => {
            controls[tool].forEach( (element, index) => {
            if (element.name == obj[tool]["name"]) {
                requiredKeys = index;
                resolve();
            }
        }) });

        requiredKeys = Object.keys(controls[tool][requiredKeys].requirement);

        if (userKeys.length !== requiredKeys.length || !userKeys.every(key => requiredKeys.includes(key))) {
            return { status: false, message: "The submitted data does not match the required format." };
        }

        // // Check for null or empty values in userSubmitted
        const missingOrEmptyKeys = userKeys.filter(key => obj[tool]["requirement"][key] == null || obj[tool]["requirement"][key] === '');

        if (missingOrEmptyKeys.length > 0) {
            return { status: false, message: `The following data are missing or empty: ${missingOrEmptyKeys.join(', ')}` };
        }


        return { status: true, message: "All data were filled and validated" };

    }


    processRequest(req) {
        // this method will analyse the request and reply back with an adequate response

        let data = null;
        return new Promise(async (resolve, reject) => {

            console.log(`  This is our request: `, req)

            if (req.mission == "controls-info") {
                console.log(":Control informations requested")
                data = await this.rtnControls()
                resolve(data)
            }
            if (req.mission == "validate-input") {
                console.log(":Informations received for validation");
                data = await this.validateInput(req);
                resolve(data)
            }

            reject({ status: "failed", error:" You did not specify an existing command" });
        });
    };

    async rtnControls() {

        const filePath = path.join(__dirname, 'control.json');
        return (await fs.readFile(filePath, 'utf8'));

    }


}
