const actions = require('../../actions')
//module.exports = 
module.exports = class browser extends actions {

    /*
        As the name suggests, this class is used to interact with the browser.
    */

    constructor(personality_Object) {
        //we have a section for the personality object, this is where we would store the personality of the bot.
        super(personality_Object);
    }




    async visit_website(primary_Action_To_Execute, secondary_Action_To_Execute) {

        /*
            This method would be able to visit a website, move around and interact with it.
            The primary_Action_To_Execute parameter is the first action that the bot will execute.
            It has 3 mandatory keys that must be provided (inside the primary action object):
                KEY ONE:: => url: The url of the website to visit.
                KEY TWO:: => duration: A string containing the duration of activity.

            The secondary_Action_To_Execute parameter is the second action that the bot will execute.
            This action is xpaths to click on along side the time to spend doing the clicking.
            It has 3  keys that must be provided (inside the primary action object):
                KEY ONE:: => xpath: The  xpath a string containing xpaths to be clicked on
                KEY TWO:: => duration:  A string containing the duration of activity.
        */


        try { //primary

            //Get the bot owner's name
            this.apiKeyInfo = await this.retreiveInfo();

            console.log(`Hi, ${this.apiKeyInfo.owner}, I would be performing the received primary task now`, primary_Action_To_Execute)

            // await this.setSiteCookie();
            // // show that we would be retrieving cookies from okecbot server
            // let cookie = await this.getSiteCookie(primary_Action_To_Execute.url);

            // if (cookie != null) {
            //     let cookies = JSON.parse(cookie.cookies)
            //     await this.webPage.setCookie(...cookies)
            // }


            let time_On_Page = await this.time_On_Page_From_Range(primary_Action_To_Execute.duration);
            await this.popInfo({ timer: 10, title: "Mimicking Human Interraction", message: `Hi, ${this.apiKeyInfo.owner} ,  I am bot: ${this.personality_Object.botName} and I would be visiting this link (${primary_Action_To_Execute.url}). When I successfully load the link, I would mimick a human interraction pattern & interract with the link for ${Math.round(time_On_Page / 1000)} seconds` })
            await this.directVisit(primary_Action_To_Execute.url);
            await this.pick_Interaction_with_page(time_On_Page)
            await this.popInfo({ timer: 10, title: "Primary Task Completed", message: `Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} and I just completed the primary task, moving over to check if there is a secondary task to execute, OVER and OUT` });
            await this.sleep(2000)

            if (secondary_Action_To_Execute != null && secondary_Action_To_Execute.xpath.trim().length > 1 && secondary_Action_To_Execute.duration.length > 1) {
                try { //secondary 
                    console.log("entering the secondary land")

                    let xpath = this.extractXpath(secondary_Action_To_Execute.xpath);

                    for (let path of xpath) {

                        try {
                            let xpathExist = await this.webPage.$x(path)

                            let selectorOfXpath = this.xpathToCssSelector(path);

                            if (xpathExist.length > 0) {

                                let time_On_Page = await this.time_On_Page_From_Range(secondary_Action_To_Execute.duration);
                                await this.popInfo({ timer: 10, title: "Mimicking Human Interraction", message: `I am bot: ${this.personality_Object.botName} and I would click on ( ${selectorOfXpath} ) :: and I will mimick human behavior after clicking for ${Math.round(time_On_Page / 1000)} seconds` })
                                await this.sleep(this.time_On_Page_From_Range(" '2' to '5' seconds")) // wait a bit before resuming interraction again
                                await this.click_on_element(selectorOfXpath);

                                //lets assume all navigation is settled below

                                await this.pick_Interaction_with_page(time_On_Page)
                                await this.sleep(this.time_On_Page_From_Range(" '2' to '5' seconds")) // wait a bit before resuming interraction again

                            } else {
                                // pop up the error here stating it doesnt exit and be on a timer after which we exist task
                                throw new Error(` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} I couldnt find the item you want me to click on (${selectorOfXpath}). I will be aborting in.`)
                                break;

                            }


                        } catch (error) {

                            await this.popError({ timer: 10, title: "Error encountered", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} I couldnt find the item you want me to click on, probably incompatible Xpath. I would be exiting this secondary task. OVER AND OUT` })
                            throw new Error();
                        }


                    };

                    await this.popInfo({ timer: 10, title: "Executed task successfully", message: `I am bot: ${this.personality_Object.botName} and I just executed the primary and secondary task successfully, I would be exiting so other task can be executed. OVER AND OUT` })
                    return ` bot: ${this.personality_Object.botName} executed the primary and secondary action successfully, I would resolve now so other task can be executed. OVER AND OUT`



                } catch (e) {
                    throw new Error({ timer: 10, title: "An error occured", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}, I couldnt execute the Secondary task, I would have to abort this task ` })
                }
            } else {
                await this.sleep(2000)
                await this.popInfo({ timer: 10, title: "No Secondary Task", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}. There was no secondary task to execute, I will be exiting. OVER AND OUT` })
                return ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} I couldnt find a the item you want me to click on`;
            }



        } catch (e) {
            await this.sleep(2000)
            await this.popError(e)
            return ` bot: ${this.personality_Object.botName} couldnt execute the Primary task, aborting now; ${e} `
        }

    }


    async navigate_web(primary_Action_To_Execute, secondary_Action_To_Execute) {

        // This particular method would make navigating across pages easy.

        /*
            The primary_Action_To_Execute parameter is the first action that the bot will execute.
            It has 3 mandatory keys that must be provided (inside the primary action object):
                KEY ONE:: => url: The url of the website to visit.
                KEY TWO:: => duration: A string containing the duration of activity.

            The secondary_Action_To_Execute parameter is the an array of object which are xpath, action, duration that will be executed.
                ARRAY:: =>  {
                    xpath: The  xpath a string containing xpaths to be clicked on
                    action: This is an object with 2 keys: action_type and action_prompt
                    duration:  A string containing the duration of activity.
        */

        console.log(" we would be navigating the task");



        if (primary_Action_To_Execute != null) {
            try { //primary

                //Get the bot owner's name
                this.apiKeyInfo = await this.retreiveInfo();

                console.log(`Hi, ${this.apiKeyInfo.owner}, I would be performing the received primary task now`, primary_Action_To_Execute)


                let time_On_Page = await this.time_On_Page_From_Range(primary_Action_To_Execute.duration);
                await this.popFrame({ timer: 10, title: "Mimicking Human Interraction", message: `Hi, ${this.apiKeyInfo.owner} ,  I am bot: ${this.personality_Object.botName} and I would be visiting this link (${primary_Action_To_Execute.url}). When I successfully load the link, I would mimick a human interraction pattern & interract with the link for ${Math.round(time_On_Page / 1000)} seconds` })
                await this.directVisit(primary_Action_To_Execute.url);
                await this.pick_Interaction_with_page(time_On_Page)
                await this.sleep(2000)
            } catch (e) {
                await this.popFrame({ timer: 10, title: "Error Exiting Task", message: `Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} and I couldnt execute the primary task assigned` });
                await this.sleep(2000)
            }
        }




        if (secondary_Action_To_Execute != null && secondary_Action_To_Execute.length > 0) {

            try { //secondary 
                console.log("entering the secondary task", secondary_Action_To_Execute)

                for (let i = 0; i < secondary_Action_To_Execute.length; i++) {

                    let secondTask = secondary_Action_To_Execute[i];

                    console.log("SEc task", secondTask)

                    let path = this.extractXpath(secondTask.xpath, true);

                    try {
                        let xpathExist = await this.webPage.$x(path)

                        if (xpathExist.length > 0) {

                            let time_On_Page = await this.time_On_Page_From_Range(secondTask.duration);
                            await this.popFrame({ timer: 3, title: "Mimicking Human Interraction", message: `I am bot: ${this.personality_Object.botName} and I would click on ( ${path} ) :: and I will mimick human behavior after clicking for ${Math.round(time_On_Page / 1000)} seconds` })
                            await this.sleep(this.time_On_Page_From_Range(" '2' to '5' seconds")) // wait a bit before resuming interraction again
                            await this.click_with_xpath(path);

                            //lets assume all navigation is settled below

                            await this.sleep(this.time_On_Page_From_Range(" '2' to '5' seconds")) // wait a bit before resuming interraction again

                        } else {
                            // pop up the error here stating it doesnt exit and be on a timer after which we exist task
                            throw new Error(` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} I couldnt find the item you want me to click on (${path}). I will be aborting in.`)
                            break;

                        }


                    } catch (error) {

                        console.log(" ERROOR ", error)
                        await this.popFrame({ timer: 10, title: "Error encountered", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} I couldnt find the item you want me to click on, probably incompatible Xpath. I would be exiting this secondary task. OVER AND OUT` })
                        throw new Error();
                    }



                    await this.pick_Interaction_with_page(this.time_On_Page_From_Range(" '2' to '5' seconds"))

                } // ends loop for the secondary tasks

                await this.popFrame({ timer: 10, title: "Executed task successfully", message: `I am bot: ${this.personality_Object.botName} and I just executed the primary and secondary task successfully, I would be exiting so other task can be executed. OVER AND OUT` })
                return ` bot: ${this.personality_Object.botName} executed the primary and secondary action successfully, I would resolve now so other task can be executed. OVER AND OUT`

            } catch (e) {
                throw new Error({ timer: 10, title: "An error occured", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName}, I couldnt execute the Secondary task, I would have to abort this task ` })
            }
        }

    }


}// ends exports
