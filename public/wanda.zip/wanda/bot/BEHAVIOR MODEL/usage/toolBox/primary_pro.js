const actions = require('../../actions')
//module.exports = 
module.exports = class browser extends actions {

    /*
        As the name suggests, this class is used to interact with the browser.
    */

    constructor(personality_Object) {
        //we have a section for the personality object, this is where we would store the personality of the bot.
        super(personality_Object);
    }



    async navigate_primary(primary_Action_To_Execute, secondary_Action_To_Execute) {

        // reject if user doesnt have Eaccess
        // let Eaccess = await this.loadExecAccess();
        // if (Eaccess < 1) {
        //     console.log(this.color.red("You dont haVe access to execute this task!  ur Access::: =>>", Eaccess))
        //     await this.popError({ timer: 300, title: "Primary PRO Required", message: `I am bot: ${this.personality_Object.botName}::: , upgrade to a minimum of Primary PRO and try again [::ACCESS 1 needed, What was found was Access => ${Eaccess} ]` });
        //     return "Access Denied";
        // }
        // This particular method would make navigating across pages easy.

        /*
            The primary_Action_To_Execute parameter is the first action that the bot will execute.
            It has 3 mandatory keys that must be provided (inside the primary action object):
                KEY ONE:: => url: The url of the website to visit.
                KEY TWO:: => duration: A string containing the duration of activity.

            The secondary_Action_To_Execute parameter is the an array of object which are xpath, action, duration that will be executed.
                ARRAY:: =>  {
                    xpath: The  xpath a string containing xpaths to be clicked on
                    action: This is an object with 2 keys: action_type and action_prompt
                    duration:  A string containing the duration of activity.
        */

        console.log(" we would be navigating the task");



        if (primary_Action_To_Execute != null) {
            try { //primary

                //Get the bot owner's name
                this.apiKeyInfo = await this.retreiveInfo();

                console.log(`Hi, ${this.apiKeyInfo.owner}, I would be performing the received primary task now`, primary_Action_To_Execute)


                let time_On_Page = await this.time_On_Page_From_Range(primary_Action_To_Execute.duration);
                await this.popFrame({ timer: 5, title: "Mimicking Human Interraction", message: `Hi, ${this.apiKeyInfo.owner} ,  I am bot: ${this.personality_Object.botName} and I would be visiting this link (${primary_Action_To_Execute.url}). When I successfully load the link, I would mimick a human interraction pattern & interract with the link for ${Math.round(time_On_Page / 1000)} seconds` })
                await this.directVisit(primary_Action_To_Execute.url);
                await this.pick_Interaction_with_page(time_On_Page)
                await this.sleep(2000)
            } catch (e) {
                await this.popFrame({ timer: 10, title: "Error Exiting Task", message: `Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} and I couldnt execute the primary task assigned` });
                await this.sleep(2000)
            }
        }



        if (secondary_Action_To_Execute != null && secondary_Action_To_Execute.length > 0) {

            try { //secondary 
                console.log("entering the secondary task", secondary_Action_To_Execute)

                for (let i = 0; i < secondary_Action_To_Execute.length; i++) {

                    let secondTask = secondary_Action_To_Execute[i];

                    if (secondTask.task == "click_xpath") {

                        console.log("We are made to click an xpath ::", secondTask)

                        let path = secondTask.xpath;

                        try {
                            let time_On_Page = await this.time_On_Page_From_Range(secondTask.duration);
                            let xpathExist = await this.webPage.$x(path) // if xpath doesnt exit this would cause a break;
                            if (xpathExist.length < 1) throw new Error()
                            await this.click_with_xpath(path); // click on it
                            console.log(this.color.green("clicked"))

                            //lets assume all navigation is settled below
                            await this.pick_Interaction_with_page(time_On_Page)

                        } catch (error) {

                            console.log(" ERROOR ", error)
                            await this.popFrame({ timer: 5, title: "Error encountered", message: ` Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} I couldnt find the item you want me to click on, probably incompatible Xpath. I would be exiting this secondary task. OVER AND OUT` })
                            throw new Error("We couldnt find or click xpath");
                        }

                    }


                } // ends loop for the secondary tasks

                await this.popFrame({ timer: 10, title: "Executed task successfully", message: `I am bot: ${this.personality_Object.botName} and I just executed the primary and secondary task successfully, I would be exiting so other task can be executed. OVER AND OUT` })
                return ` bot: ${this.personality_Object.botName} executed the primary and secondary action successfully, I would resolve now so other task can be executed. OVER AND OUT`

            } catch (e) {
                throw new Error(e)
            }
        }

    }


}// ends exports
