const actions = require('../../actions')
//module.exports = 
module.exports = class browser extends actions {

    /*
        As the name suggests, this class is used to interact with the browser.
    */

    constructor(personality_Object) {
        //we have a section for the personality object, this is where we would store the personality of the bot.
        super(personality_Object);
    }
    async navigate_free(primary_Action_To_Execute) {

        // This particular method would make navigating across pages easy.

        /*
            The primary_Action_To_Execute parameter is the first action that the bot will execute.
            It has 3 mandatory keys that must be provided (inside the primary action object):
                KEY ONE:: => url: The url of the website to visit.
                KEY TWO:: => duration: A string containing the duration of activity.

            The secondary_Action_To_Execute parameter is the an array of object which are xpath, action, duration that will be executed.
                ARRAY:: =>  {
                    xpath: The  xpath a string containing xpaths to be clicked on
                    action: This is an object with 2 keys: action_type and action_prompt
                    duration:  A string containing the duration of activity.
        */

        console.log(" we would be navigating the task");



        if (primary_Action_To_Execute != null) {
            try { //primary

                //Get the bot owner's name
                this.apiKeyInfo = await this.retreiveInfo();

                console.log(`Hi, ${this.apiKeyInfo.owner}, I would be performing the received primary task now`, primary_Action_To_Execute)


                let time_On_Page = await this.time_On_Page_From_Range(primary_Action_To_Execute.duration);
                await this.popFrame({ timer: 5, title: "Mimicking Human Interraction", message: `Hi, ${this.apiKeyInfo.owner} ,  I am bot: ${this.personality_Object.botName} and I would be visiting this link (${primary_Action_To_Execute.url}). When I successfully load the link, I would mimick a human interraction pattern & interract with the link for ${Math.round(time_On_Page / 1000)} seconds` })
                await this.directVisit(primary_Action_To_Execute.url);
                await this.pick_Interaction_with_page(time_On_Page)
                await this.sleep(2000)
            } catch (e) {
                await this.popFrame({ timer: 10, title: "Error Exiting Task", message: `Hi, ${this.apiKeyInfo.owner} , I am bot: ${this.personality_Object.botName} and I couldnt execute the primary task assigned` });
                await this.sleep(2000)
            }finally{
                return "Task executed"
            }
        }


    }


}// ends exports
